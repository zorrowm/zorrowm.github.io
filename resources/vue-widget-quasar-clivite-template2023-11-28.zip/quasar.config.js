/* eslint-env node */

/*
 * This file runs in a Node context (it's NOT transpiled by Babel), so use only
 * the ES6 features that are supported by your Node version. https://node.green/
 */

// Configuration for your app
// https://v2.quasar.dev/quasar-cli-vite/quasar-config-js

const { configure } = require('quasar/wrappers');
const path = require('path');
//将驼峰转换为-
function getKebabCase(str) {
  var arr = str.split('');
  //使用循环遍历字符串
  str = arr.map(function (item) {
    if (item.toUpperCase() === item) {
      //使用toUpperCase()方法检测当前字符是否为大写
      return '-' + item.toLowerCase();
      //大写就在前面加上-，并用toLowerCase()将当前字符转为小写
    } else {
      return item;
    }
  });
  return str.join('');
}
//定义@Opentiny UI组件
const tinyResolver = {
  type: 'component',
  resolve: (name) => {
    if (name.startsWith('Tiny')) {
      const partialName = name.slice(4);
      const compName = getKebabCase(partialName);
      return {
        name: 'default',
        from: `@opentiny/vue${compName}/lib/index`,
      };
    }
  },
};
//定义vite插件
const getVitePlugins = (ctx) => {
  const defaultPlugins = [
    ['@vitejs/plugin-vue-jsx', {}],
    ['unplugin-vue-define-options/vite', {}],
  ];
  if (ctx.dev) {
    defaultPlugins.push(['vite-plugin-fs', {}]);
    //跳转根据页面查看VUE代码
    //https://www.npmjs.com/package/vite-plugin-vue-inspector
    defaultPlugins.push(['vite-plugin-vue-inspector',{
      enabled: false,
      toggleButtonVisibility: 'active',
      toggleButtonPos: 'bottom-right'
    }]);
  }
  if (ctx.prod) {
    const prodArray = [
      [
        'unplugin-vue-components/vite',
        {
          resolvers: [
            //动态引入ElementPlus组件 https://www.npmjs.com/package/unplugin-vue-components
            // require('unplugin-vue-components/resolvers').ElementPlusResolver(),
            tinyResolver, //opentiny组件
          ],
        },
      ],
      [
        'rollup-plugin-visualizer',
        {
          open: true,
          gzipSize: true,
          brotliSize: true,
        },
      ],
    ];
    defaultPlugins.push(...prodArray);
  }
  return defaultPlugins;
};
module.exports = configure(function (ctx) {
  return {
    eslint: {
      //fix: true,
      // include: [],
      // exclude: [],
      // rawOptions: {},
      warnings: true,
      errors: true,
    },

    // https://v2.quasar.dev/quasar-cli-vite/prefetch-feature
    // preFetch: true,

    // app boot file (/src/boot)
    // --> boot files are part of "main.js"
    // https://v2.quasar.dev/quasar-cli-vite/boot-files
    boot: ['initXframe', 'directives'],

    // https://v2.quasar.dev/quasar-cli-vite/quasar-config-js#css
    css: [
      //主题样式
      'theme.css',
      //全局样式
      'app.scss',
      //引入模块CSS
      '~xframelib/dist/index.css',
      //引入floating-vue通用tooltip
      '~floating-vue/dist/style.css',
      //进度条样式
      '~nprogress/css/nprogress.css',
    ],

    // https://github.com/quasarframework/quasar/tree/dev/extras
    extras: [
      //安装webfont字体图标库，https://www.quasar-cn.cn/options/installing-icon-libraries
      // 'ionicons-v4',
      // 'mdi-v5',
      // 'fontawesome-v6',
      // 'eva-icons',
      // 'themify',
      // 'line-awesome',
      // 'roboto-font-latin-ext', // this or either 'roboto-font', NEVER both!
      // 'roboto-font', // optional, you are not bound to it
      'material-icons-outlined',
      'material-icons', // optional, you are not bound to it
    ],

    // Full list of options: https://v2.quasar.dev/quasar-cli-vite/quasar-config-js#build
    build: {
      target: {
        browser: ['es2019', 'edge88', 'firefox78', 'chrome87', 'safari13.1'],
        node: 'node16',
      },
      vueRouterMode: 'hash', // available values: 'hash', 'history'
      // vueRouterBase,
      // vueDevtools,
      // vueOptionsAPI: false,

      // rebuildCache: true, // rebuilds Vite/linter/etc cache on startup

      // publicPath: '/',
      // analyze: true,
      //自定义的全局环境变量
      //env: {},
      //rawDefine: {},
      // ignorePublicFolder: true,
      // minify: false,
      //https://github.com/quasarframework/quasar/blob/9ae61a95b7dcf2d1e3d42bd737fcd0537ddf656f/app-vite/lib/config-tools.js#L136
            //是否要开启 模块预加载补丁 polyfill，开启后为所有脚本都注入模块补丁。默认情况下，不开启 polyfill
      modulePreload:{
        polyfill:false
      },
      // distDir

      // extendViteConf (viteConf) {},
      // viteVuePluginOptions: {},
      // alias: {
      //   '@': path.join(__dirname, './src'),
      // },

      vitePlugins: getVitePlugins(ctx),
      extendViteConf(viteConf) {
        // viteConf.resolve.alias = [
        //   {
        //     find: '@',
        //     replacement: path.resolve(__dirname, './src'),
        //   },
        // ];
        //
        if (ctx.dev) {
          // viteConf.plugins.push(require('vite-plugin-fs').default());
        }
        if (ctx.prod) {
          //是否抛弃console.log
          viteConf.esbuild = { drop: ['console', 'debugger'] };
          viteConf.build.rollupOptions = {
            external: ['/img'],
            output: {
              manualChunks(id) {
                if (id.includes('/node_modules/')) {
                  // 设置需要独立打包的npm包
                  const expansions = [
                    'axios',
                    'xframelib',
                    'mapbox-gl',
                    'ol',
                    // 'echarts',
                    // 'lodash-es',
                    '@hprose',
                    'xgis-ol',
                    'vue-router',
                    '@iconify/vue',
                  ];
                  const c = expansions.find((exp) =>
                    id.includes(`/node_modules/${exp}`)
                  );
                  if (c) {
                    return `${c}-exp`;
                  } else {
                    return 'vendor';
                  }
                }
              },
            },
          };
          viteConf.css = {
            loaderOptions: {
              sass: {
                sassOptions: {
                  quietDeps: true,
                },
              },
            },
          };
        }
      },
    },

    // Full list of options: https://v2.quasar.dev/quasar-cli-vite/quasar-config-js#devServer
    devServer: {
      // https: true
      open: true, // opens browser window automatically
    },

    // https://v2.quasar.dev/quasar-cli-vite/quasar-config-js#framework
    framework: {
      config: {},

      // iconSet: 'material-icons', // Quasar icon set
      lang: 'zh-CN', // Quasar language pack'en-US'

      cssAddon: true, //断点，实现跨端、响应式
      // For special cases outside of where the auto-import strategy can have an impact
      // (like functional components as one of the examples),
      // you can manually specify Quasar components/directives to be available everywhere:
      //
      // components: [],
      // directives: [],

      // Quasar plugins
      plugins: ['Dialog', 'AppFullscreen', 'Loading', 'Notify'],
    },

    animations: 'all', // --- includes all animations
    // https://v2.quasar.dev/options/animations
    // animations: [],

    // https://v2.quasar.dev/quasar-cli-vite/quasar-config-js#sourcefiles
    // sourceFiles: {
    //   rootComponent: 'src/App.vue',
    //   router: 'src/router/index',
    //   store: 'src/store/index',
    //   registerServiceWorker: 'src-pwa/register-service-worker',
    //   serviceWorker: 'src-pwa/custom-service-worker',
    //   pwaManifestFile: 'src-pwa/manifest.json',
    //   electronMain: 'src-electron/electron-main',
    //   electronPreload: 'src-electron/electron-preload'
    // },

    // https://v2.quasar.dev/quasar-cli-vite/developing-ssr/configuring-ssr
    ssr: {
      // ssrPwaHtmlFilename: 'offline.html', // do NOT use index.html as name!
      // will mess up SSR

      // extendSSRWebserverConf (esbuildConf) {},
      // extendPackageJson (json) {},

      pwa: false,

      // manualStoreHydration: true,
      // manualPostHydrationTrigger: true,

      prodPort: 3000, // The default port that the production server should use
      // (gets superseded if process.env.PORT is specified at runtime)

      middlewares: [
        'render', // keep this as last one
      ],
    },

    // https://v2.quasar.dev/quasar-cli-vite/developing-pwa/configuring-pwa
    pwa: {
      workboxMode: 'generateSW', // or 'injectManifest'
      injectPwaMetaTags: true,
      swFilename: 'sw.js',
      manifestFilename: 'manifest.json',
      useCredentialsForManifestTag: false,
      // useFilenameHashes: true,
      // extendGenerateSWOptions (cfg) {}
      // extendInjectManifestOptions (cfg) {},
      // extendManifestJson (json) {}
      // extendPWACustomSWConf (esbuildConf) {}
    },

    // Full list of options: https://v2.quasar.dev/quasar-cli-vite/developing-cordova-apps/configuring-cordova
    cordova: {
      // noIosLegacyBuildFlag: true, // uncomment only if you know what you are doing
    },

    // Full list of options: https://v2.quasar.dev/quasar-cli-vite/developing-capacitor-apps/configuring-capacitor
    capacitor: {
      hideSplashscreen: true,
    },

    // Full list of options: https://v2.quasar.dev/quasar-cli-vite/developing-electron-apps/configuring-electron
    electron: {
      // extendElectronMainConf (esbuildConf)
      // extendElectronPreloadConf (esbuildConf)

      inspectPort: 5858,

      bundler: 'packager', // 'packager' or 'builder'

      packager: {
        // https://github.com/electron-userland/electron-packager/blob/master/docs/api.md#options
        // OS X / Mac App Store
        // appBundleId: '',
        // appCategoryType: '',
        // osxSign: '',
        // protocol: 'myapp://path',
        // Windows only
        // win32metadata: { ... }
      },

      builder: {
        // https://www.electron.build/configuration/configuration

        appId: 'vue-widget-quasar-template',
      },
    },

    // Full list of options: https://v2.quasar.dev/quasar-cli-vite/developing-browser-extensions/configuring-bex
    bex: {
      contentScripts: ['my-content-script'],

      // extendBexScriptsConf (esbuildConf) {}
      // extendBexManifestJson (json) {}
    },
  };
});
