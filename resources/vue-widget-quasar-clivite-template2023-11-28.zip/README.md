# Quasar App (vue-widget-quasar-clivite-template)

vue widget quasar template project

## 主要技术

vue3
quasar-cli
vite
@opentiny
widget

### 更改记录

初始版本：解决依赖 vite 插件和 build 问题
