<template>
  <div class="row">
    <div class="col-11 row justify-end items-center">
     <PageMenu :data="menuList"/>
    </div>
    <div class="col-1 justify-end q-pa-md">
      <div class="q-gutter-sm row items-center no-wrap">
        <q-btn
          class="lt-sm"
          dense
          flat
          round
          icon="menu"
          @click="toggleRightDrawer"
        />
        <q-btn dense flat href="https://github.com" target="_blank">
          <Icon icon="fa-github" />
          <q-tooltip>github </q-tooltip>
        </q-btn>
        <span>
          <Icon
            v-if="showCollapseIcon"
            :icon="
              leftCollapsed
                ? 'ant-design:menu-unfold-outlined'
                : 'ant-design:menu-fold-outlined'
            "
            @click="toggleCollapse"
          />
        </span>
        <FullScreen
          v-if="showFullScreen && $q.screen.gt.sm"
          :target="fullScreenElem"
        />
      </div>
    </div>
  </div>
  <q-layout v-if="$q.screen.lt.sm" view="hHH lpR fFf">
    <q-drawer v-model="rightDrawerOpen" side="right" bordered>
      <!-- drawer content -->
      <q-btn dense flat round icon="menu" @click="toggleRightDrawer" />
      <SideMenuBar :top-menu-children="topMenuChildren"> </SideMenuBar>
    </q-drawer>
  </q-layout>
</template>

<script lang="ts" setup>
import FullScreen from 'components/FullScreen.vue';
import SideMenuBar from 'components/Menu/SideMenuBar/index.vue';
import { storeToRefs } from 'pinia';
import { useQuasar } from 'quasar';
import  PageMenu  from 'src/components/Quasar/PageMenu/index.vue';
import {EnumPageMenu,IPageMenu} from 'src/components/Quasar/PageMenu/IPageMenu';
import productRoute from 'src/router/product/index';
import { appStore, userStore } from 'src/stores';
import LayoutTool from 'src/utils/layoutTool';
import { doLoadModal } from 'src/utils/WidgetsTool';
import { computed, reactive, ref,  } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { Global } from 'xframelib';
const menuList=[
  {
    label:'首页',
    icon:'ant-design:home-outlined',
    kind:EnumPageMenu.Route,
    path:'/product/index',
  },
  {
    label:'帝测时空云平台',
    kind:EnumPageMenu.Route,
    path:'/product/productPage',
  },
  {
    label:'解决方案',
    children:[
      {
        label:'智慧农业',
        kind:EnumPageMenu.URL,
        path:'https://www.baidu.com',
      },
      {
        label:'智慧水利',
        kind:EnumPageMenu.Route,
        path:'/river',
      },
      {
        label:'智慧物流',
        kind:EnumPageMenu.URL,
        path:'https://www.126.com'
      }
    ]
  },
  {
    label:'项目案例',
    children:[
      {
        label:'农业项目',
        kind:EnumPageMenu.URL,
        path:'https://www.baidu.com',
      },
      {
        label:'水利项目',
        kind:EnumPageMenu.Route,
        path:'/river',
      }
    ]
  },
  {
    label:'API示例',
    kind:EnumPageMenu.Route,
    path:'/product/apiexamples',
  },
  {
    label:'联系我们',
    kind:EnumPageMenu.URL,
    path:'/product/contract',
  },
];
const rightDrawerOpen = ref(false);
    const isShow = ref(false);
    const $q = useQuasar();
    const siteTitle = ref(Global.Config.UI?.SiteTitle);
    const appState = appStore();
    const userState = userStore();
    const { leftCollapsed } = storeToRefs(appState);
    //居中显示标题
    const iscenterTitle = ref(appState.headerSetting.centerTitle);
    //全屏图标
    const showFullScreen = ref(appState.headerSetting.showFullScreen);
    const showCollapseIcon = ref(appState.headerSetting.showCollapseIcon);

    function toggleCollapse() {
      appState.toggleCollapse();
    }
    const state = reactive({
      //头部高度
      headerHeight: LayoutTool.getHeaderHeight(),
    });
    const fullScreenElem = ref(window.document.documentElement);
    const route = useRoute();
    // 退出登录
    const doLogout = () => {
      $q.dialog({
        //dark: true,
        title: '退出',
        message: '您确定要退出登录吗？',
        cancel: true,
        // persistent: true
      })
        .onOk(() => {
          //退出登录
          userState.clear();
          Global.Message?.msg('成功退出登录');
          // 移除标签页
          // localStorage.removeItem(TABS_ROUTES)
          window.open(window.location.pathname, '_self');
        })
        .onCancel(() => {
          // console.log('>>>> Cancel')
        });
    };

    const isNOLogin = computed(() => !Global.Config.UI?.IsNoLogin);
    //修改密码框
    function showUserModal() {
      const rowData = undefined;
      const modalData = {
        modalID: 'changeMyPWD',
        extraData: {
          title: '修改密码',
        },
        width: 500,
        rowData,
      };
      doLoadModal(modalData);
    }
    const router = useRouter();
    function routerPush(val) {
      switch (val) {
        case '0':
          router.push('/index');
          break;
        case '2':
          router.push('/productPage');
          break;
        case '4':
          // router.push({path:'/apiexamples',query:{index:0}})
          router.push('/apiexamples');
          break;
        case '5':
          router.push('/wsntest');
          break;
      }
    }
    const topMenuChildren = computed(() => {
      const rightRoutes = productRoute.children;
      if (!rightRoutes) {
        Global.Message?.warn('无法获取路由列表！');
        return [];
      }
      return rightRoutes;
    });
    function toggleRightDrawer()
    {
      console.log('TODO:打开右侧抽屉控件')
    }
</script>
