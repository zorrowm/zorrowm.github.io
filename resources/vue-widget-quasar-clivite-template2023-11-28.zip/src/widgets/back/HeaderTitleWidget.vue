<template>
  <div class="right-options fr">
    <div class="q-gutter-sm row items-center no-wrap">
      <q-btn dense flat href="https://github.com" target="_blank">
        <Icon icon="fa-github" />
        <q-tooltip>github </q-tooltip>
      </q-btn>
      <span>
        <Icon
          v-if="showCollapseIcon"
          :icon="
            leftCollapsed
              ? 'ant-design:menu-unfold-outlined'
              : 'ant-design:menu-fold-outlined'
          "
          @click="toggleCollapse"
        />
      </span>
      <FullScreen
        v-if="showFullScreen && $q.screen.gt.sm"
        :target="fullScreenElem"
      />
      <DarkMode />
      <q-btn v-if="isNOLogin" round flat>
        <q-avatar color="primary" text-color="white">
          {{ userState.name }}
        </q-avatar>
        <q-menu>
          <q-list dense>
            <q-item>
              <q-item-section>
                <div>角色：<br /><strong>1111</strong></div>
              </q-item-section>
            </q-item>
            <q-separator />
            <q-item clickable class="outlist">
              <q-item-section @click="showUserModal">
                <div>
                  <Icon icon="ant-design:info-circle-outlined" />
                  <span> 修改密码</span>
                </div>
              </q-item-section>
            </q-item>
            <q-separator />

            <q-item clickable class="outlist">
              <q-item-section @click="doLogout">
                <div>
                  <Icon icon="ant-design:logout-outlined" />
                  <span>退出登录</span>
                </div>
              </q-item-section>
            </q-item>
          </q-list>
        </q-menu>
        <!-- <q-tooltip>角色:{{ userState.DefaultMaxRole }}</q-tooltip> -->
      </q-btn>
    </div>
  </div>
</template>

<script lang="ts">
import FullScreen from 'components/FullScreen.vue';
import DarkMode from 'components/Quasar/Toolbar/DarkMode.vue';
import { storeToRefs } from 'pinia';
import { useQuasar } from 'quasar';
import { appStore, userStore } from 'src/stores';
import LayoutTool from 'src/utils/layoutTool';
import { doLoadModal } from 'src/utils/WidgetsTool';
import { computed, defineComponent, reactive, ref, toRefs } from 'vue';
import { useRoute } from 'vue-router';
import { Global } from 'xframelib';

export default defineComponent({
  name: 'HeaderTitleWidget',
  components: { FullScreen, DarkMode },
  setup() {
    const $q = useQuasar();
    const siteTitle = ref(Global.Config.UI?.SiteTitle);
    const appState = appStore();
    const userState = userStore();
    const { leftCollapsed } = storeToRefs(appState);
    //居中显示标题
    const iscenterTitle = ref(appState.headerSetting.centerTitle);
    //全屏图标
    const showFullScreen = ref(appState.headerSetting.showFullScreen);
    const showCollapseIcon = ref(appState.headerSetting.showCollapseIcon);

    function toggleCollapse() {
      appState.toggleCollapse();
    }
    const roleRef = computed(() => {
      return userState.name + '[' + userState.DefaultMaxRole + ']';
    });
    const state = reactive({
      //头部高度
      headerHeight: LayoutTool.getHeaderHeight(),
    });
    const fullScreenElem = ref(window.document.documentElement);
    const route = useRoute();
    // 退出登录
    const doLogout = () => {
      $q.dialog({
        //dark: true,
        title: '退出',
        message: '您确定要退出登录吗？',
        cancel: true,
        // persistent: true
      })
        .onOk(() => {
          //退出登录
          userState.clear();
          Global.Message?.msg('成功退出登录');
          // 移除标签页
          // localStorage.removeItem(TABS_ROUTES)
          window.open(window.location.pathname, '_self');
        })
        .onCancel(() => {
          // console.log('>>>> Cancel')
        });
    };

    const isNOLogin = computed(() => !Global.Config.UI?.IsNoLogin);
    //修改密码框
    function showUserModal() {
      const rowData = undefined;
      const modalData = {
        modalID: 'changeMyPWD',
        extraData: {
          title: '修改密码',
        },
        width: 500,
        rowData,
      };
      doLoadModal(modalData);
    }

    return {
      ...toRefs(state),
      doLogout,
      route,
      isNOLogin,
      fullScreenElem,
      roleRef,
      showUserModal,
      leftCollapsed,
      toggleCollapse,
      siteTitle,
      iscenterTitle,
      showFullScreen,
      showCollapseIcon,
      userStore,
    };
  },
});
</script>

<style lang="scss" scoped>
.right-options {
  // display: flex;
  // align-items: center;
  // justify-content: space-between;
  width: 140px;
  // height: var(--header-top-height);
  // padding-right: 20px;
  // line-height: var(--header-top-height);
  height: var(--header-top-height);
  line-height: var(--header-top-height);
  background-color: var(--header-logo-bgcolor);
}

.outlist {
  position: relative;
  line-height: 25px;
  margin-top: 5px;

  a {
    display: flex;
    width: 85px;
    align-items: center;
    justify-content: space-evenly;
    vertical-align: middle;

    &:hover:before,
    &:hover:after {
      width: 100%;
      transition: 800ms ease all;
    }
  }

  a:before,
  a:after {
    content: '';
    position: absolute;
    bottom: 0;
    right: 0;
    height: 1px;
    width: 0;
    background: #028da9;
    transition: 400ms ease all;
  }
}
</style>
