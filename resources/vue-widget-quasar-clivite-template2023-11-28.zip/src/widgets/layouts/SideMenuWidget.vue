<template>
  <!-- <q-layout class="sideMenuDiv">
    <q-drawer v-model="leftDrawerOpen" show-if-above side="left" bordered>
      <side-menu
        style=" height: 100%; margin-top: 50px; width:200px;"
        layout-name="BackLayout"
      />
    </q-drawer>
  </q-layout> -->
  <side-menu layout-name="BackLayout"  style="height:100%; width:100%;" />
</template>

<script lang="ts">
import SideMenu from 'components/Menu/LeftMenu/BaseMenu.vue';
import { storeToRefs } from 'pinia';
import { appStore } from 'src/stores';
import { defineComponent, ref } from 'vue';
export default defineComponent({
  name: 'SideMenuWidget',
  components: { SideMenu }, // MainMenu
  setup() {
    const appState = appStore();
    const { leftCollapsed } = storeToRefs(appState);
    const collapsedWidth = ref(appState.menuSetting?.minWidth);
    const sideWidth = ref(appState.menuSetting?.menuWidth);
    const leftDrawerOpen = ref<boolean>(true);
    return {
      leftCollapsed,
      sideWidth,
      collapsedWidth,
      leftDrawerOpen,
    };
  },
});
</script>
<style lang="scss">
.sideMenuDiv {
  height: 100% !important;
  // min-height: 100% !important ;
  //calc(100vh - var(--header-top-height))
  // background-color: var(--sider-panel-bg-color);
  overflow-x: hidden;
  overflow-y: auto;
  border: 2px solid red;
}
</style>
