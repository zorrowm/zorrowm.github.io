<template>
  <ChildMenuBar :MenuData="childMenus" :LayoutID="layoutIDRef" class="currentChildMenu"/>
</template>

<script setup lang="ts">
import ChildMenuBar from 'src/components/WidgetMenuBar/index.vue';
import MenuSettings from 'src/settings/widgetMenuSetting/index.ts';
import { findMenuConfig } from 'src/widgets/WidgetUtils';
import { onMounted,ref } from 'vue';
const childMenus = ref([]);
//修改以下变量
const layoutIDRef=ref('bigScreenLayout');
const menuItemPath='linkMenuWidget';
onMounted(()=>{
  const targetMenu = findMenuConfig(MenuSettings, menuItemPath);
  if (targetMenu) {
    childMenus.value.push(...targetMenu.children);
  }
})
</script>

<style lang="scss" scoped>
.currentChildMenu
{
  position:absolute;
  top:100px;
  right:10px;
  flex-direction:column;
  height:180px;
  background-color:transparent;
  :deep(.menuBar)
  {
    background-color:transparent;
  }
  :deep(.menuBarItem)
  {
    background-color:#fff;
    // border-radius: 30%;
    width: 30px;
    height:30px;
  }
  :deep(.active)
  {
    background-color:#00aaff !important;
  }
  :deep(.iconify)
    {
      width: 24px;
      height:24px;
    }
}

</style>
