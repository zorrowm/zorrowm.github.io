<template>
  <ChildMenuBar v-show="isShow" :MenuData="childMenus" :LayoutID="layoutIDRef" class="currentChildMenu"/>
</template>

<script setup lang="ts">
import ChildMenuBar from 'src/components/WidgetMenuBar/index.vue';
import MenuSettings from 'src/settings/widgetMenuSetting/index.ts';
import { findMenuConfig } from 'src/widgets/WidgetUtils';
import { onMounted,ref } from 'vue';
const childMenus = ref([]);
//修改以下变量
const layoutIDRef=ref('bigScreenLayout');
const menuItemPath='flyMenuWidget';
onMounted(()=>{
  const targetMenu = findMenuConfig(MenuSettings, menuItemPath);
  if (targetMenu) {
    childMenus.value.push(...targetMenu.children);
  }
})
/**
 * 对外暴露接口
 */
 const isShow = ref(true);
function changeVisible(isVisible: boolean = false) {
  isShow.value = isVisible;
}
defineExpose({ changeVisible, isShow });
</script>

<style lang="scss" scoped>
.currentChildMenu
{
  position:absolute;
  top:110px;
  right:85px;
  // flex-direction:column;
  // width:280px;
  // height:40px;
  background-color:#00f;
  :deep(.menuBarItem)
  {
    background-color:#0f0;
    margin:5px;
  }
}

</style>
