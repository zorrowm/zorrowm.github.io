<template>
  <ChildMenuBar :MenuData="childMenus" :LayoutID="layoutIDRef" class="currentChildMenu"/>
</template>

<script setup lang="ts">
import ChildMenuBar from 'src/components/WidgetMenuBar/index.vue';
import MenuSettings from 'src/settings/widgetMenuSetting/index.ts';
import { findMenuConfig } from 'src/widgets/WidgetUtils';
import { onMounted,ref } from 'vue';
const childMenus = ref([]);
//修改以下变量
const layoutIDRef=ref('bigScreenLayout');
const menuItemPath='templateMenuWidget';
onMounted(()=>{
  const targetMenu = findMenuConfig(MenuSettings, menuItemPath);
  if (targetMenu) {
    childMenus.value.push(...targetMenu.children);
  }
})
</script>

<style lang="scss" scoped>
.currentChildMenu
{
  position:absolute;
  top:100px;
  right:10px;
  flex-direction:column;
  height:280px;
  background-color:#f00;
  :deep(.menuBarItem)
  {
    background-color:#fff;
    margin:5px;
  }
}

</style>
