<template>
  <div v-show="isShow" class="menuBarWidget">
    <WidgetMenuBar LayoutID="bigScreenLayout" iconColor="#333" iconSize="50"/>
  </div>
</template>

<script setup lang="ts">
 import WidgetMenuBar from 'src/components/WidgetMenuBar/index.vue';
import {ref} from 'vue';
/**
 * 对外暴露接口
 */
 const isShow = ref(true);
function changeVisible(isVisible: boolean = false) {
  isShow.value = isVisible;
}
defineExpose({ changeVisible, isShow });
</script>

<style lang="scss" scoped>
.menuBarWidget
{
  position: absolute;
  top:10px;
  right:10px;
  :deep(.menuBar)
  {
    width: 300px;
    background-color:transparent;
  }
  :deep(.menuBarItem)
  {
    background-color:#fff;
    border-radius: 50%;
    height: 40px;
    width: 40px;
  }
  :deep(.active)
  {
    background-color:#00aaff !important;
  }
  :deep(.iconify)
    {
      width: 24px;
      height:24px;
    }
}
</style>
