<template>
  <div class="mainHeader">
    <q-toolbar
      class="justify-between items-end"
      style="height: 100%; line-height: 100%"
    >
      <q-btn class="lt-md" flat dense round icon="menu" aria-label="目录">
        <q-menu>
          <q-list>
            <q-item>
              <q-item-section>
                <router-link to="/test">专题一</router-link>
              </q-item-section>
            </q-item>
            <q-item>
              <q-item-section>
                <q-item-label class="text-weight-medium"> MAX </q-item-label>
              </q-item-section>
            </q-item>

            <q-item>
              <q-item-section>
                <a aria-current="page" href="/demo1/index.html" target="_blank">
                  专题二
                </a>
              </q-item-section>
            </q-item>
            <q-item>
              <q-item-section>
                <router-link to="/test2">专题三</router-link>
              </q-item-section>
            </q-item>
          </q-list>
        </q-menu>
      </q-btn>
      <div class="gt-sm row col-3  q-gutter-x-sm">
        <div class="title">
          <router-link to="/test" style="color: white">专题一</router-link>
        </div>
        <div class="title">MAX</div>
        <div class="title">
          <a
            aria-current="page"
            href="/demo1/index.html"
            target="_blank"
            style="color: white"
          >
            专题二
          </a>
        </div>
        <div class="title">
          <router-link to="/test2" style="color: white">专题三</router-link>
        </div>
      </div>

      <div
        v-media="'titlefont.md titlefont2.lt.md'"
        class="absolute-center titleInfo"
      >
        {{ siteTitle }}
      </div>
      <q-space />
      <!-- <div class="gt-sm row col-3  q-gutter-x-sm">
        <div class="title">
          <router-link to="/test" style="color: white">专题一</router-link>
        </div>
        <div class="title">MAX</div>
        <div class="title">
          <a
            aria-current="page"
            href="/demo1/index.html"
            target="_blank"
            style="color: white"
          >
            专题二
          </a>
        </div>
        <div class="title">
          <router-link to="/test2" style="color: white">专题三</router-link>
        </div>
      </div> -->
      <div class="text-grey-1 q-gutter-x-sm">
        <FullScreen :target="fullScreenElem" color="#fff" />
        <span class="text-h6">
          {{ username }}
        </span>
        <span title="退出？" @click.prevent="doLogout">
          <Icon icon="ant-design:poweroff-outlined" />
        </span>
      </div>
    </q-toolbar>
  </div>
</template>

<script setup lang="ts">
import FullScreen from 'components/FullScreen.vue';
import { useQuasar } from 'quasar';
import { ref } from 'vue';
import { Global, logout } from 'xframelib';

const $q = useQuasar();
const siteTitle = ref(Global.Config.UI?.SiteTitle);
const username = ref('admin'); //Global.User?.name
const fullScreenElem = ref(window.document.documentElement);
// 退出登录
const doLogout = () => {
  $q.dialog({
    //dark: true,
    title: '退出登录',
    message: '您确定要退出登录吗？',
    cancel: true,
    // persistent: true
  })
    .onOk(() => {
      logout();
      Global.Message?.msg('成功退出登录');
      window.open(window.location.pathname, '_self');
    })
    .onCancel(() => {
      // console.log('>>>> Cancel')
    })
    .onDismiss(() => {
      // console.log('I am triggered on both OK and Cancel')
    });
};
</script>

<style lang="scss" scoped>
.iconify {
  color: #fff;
}
.mainHeader {
  width: 100%;
  height: var(--header-top-height);
  background-image: url('../img/home/titleBack.png');
  background-size: 100% 110%;
  background-repeat: no-repeat;
  text-align: center;
}
.header {
  width: 30%;
  height: 100%;
  line-height: 100%;
  display: flex;
  flex-direction: row;
  justify-content: center;
}
.titleInfo {
  color: #59c8ff;
  font-size: 30px;
  font-weight: 600;
}
.titlefont {
  font-size: 26px;
}
.titlefont2 {
  font-size: 18px;
}
.title {
  background-image: url('/img/home/titleContentBack.png');
  background-size: 100% 100%;
  background-repeat: no-repeat;
  line-height: 100%;
  background-position: center;
  color: white;
  height:28px;
  line-height: 28px;
}
</style>
