import {
  RouteMeta,
  RouteRecordName,
  RouteRecordRaw,
  RouteRecordRedirectOption,
} from 'vue-router';

export interface Route {
  name: string;
  path: string;
  redirect?: RouteRecordRedirectOption | undefined;
  component?: any;
  children?: Route[];
  meta?: RouteMeta;
  props?: boolean | Record<string, any> | ((to: any) => Record<string, any>);
}

export interface RouteData {
  title?: string;
  fullPath?: string;
  path?: string;
  icon?: string;
  keepAlive?: boolean;
  name: RouteRecordName | null | undefined;
}

export interface User {
  username: string;
  role: string;
}
