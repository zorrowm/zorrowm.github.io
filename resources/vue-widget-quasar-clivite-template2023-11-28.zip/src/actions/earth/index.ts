import { IWidgetMenu } from 'src/models';
import { Global } from 'xframelib';
const params = {
  skyVisible: true,
  timer: undefined //定时器
};
export function ControlSkyVisible(item: IWidgetMenu) {
  item.selected = !item.selected;
  // if (item.selected) {
  //   //设置中心点
  //   //设置初始位置
  //   Global.CesiumViewer?.camera.setView({
  //     // destination: Cesium.Cartesian3.fromDegrees(116.395645038, 39.9299857781, 100000)
  //     destination: Cesium.Camera.DEFAULT_VIEW_RECTANGLE
  //   });
  // }
  // Global.CesiumViewer.scene.skyBox.show = item.selected;
}

export function RemoveLayerItem(item: IWidgetMenu) {
  //Global.LayerManager.removeLayerItem('petrifiedLayer');
  Global.LayerManager.removeLayerItem('artificialLayer');
}

export function AddLayerItem(id:string,name:string,pkey:string) {
  console.log('我是添加节点，我执行了');
  // Global.LayerManager.addLayerItem(undefined, { id: 'test1', name: 'wmtest123' });
  // Global.LayerManager.addLayerItem({ id: 'test1', name: 'wsntest1111' });
  // Global.LayerManager.addLayerItem({ id: 'photo_temple', name: '布达拉宫test' },'photoLayer');
  // Global.LayerManager.addLayerItem({ id: 'futureLayer', name: '未来科学城test' },'whiteCityLayer');
  Global.LayerManager.addLayerItem({ id: id, name: name },pkey);
}
