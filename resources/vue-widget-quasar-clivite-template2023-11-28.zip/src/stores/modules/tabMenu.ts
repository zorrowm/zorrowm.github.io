import { defineStore } from 'pinia';
import { RouteData } from 'src/models/index';
import { getDefaultRouteBase } from 'src/permission/index';
import { getTabRouteData } from 'src/utils/sysTool';

export const tabMenuStore = defineStore('tabMenu', {
  state: () => ({
    tabMenus: [] as RouteData[] | undefined,
    currentTab: {},
  }),
  getters: {
    base(): RouteData | undefined {
      const tempRoute = getDefaultRouteBase();
      if (!tempRoute) {
        return undefined;
      }
      //console.log(tempRoute,'当前基础tempRoute')
      const routeData = getTabRouteData(tempRoute);
      //console.log(routeData,'当前基础Base')
      return routeData;
    },
  },
  actions: {
    AddTabMenu(tab?: any) {
      // pass it
      if (this.base && this.tabMenus) {
        if (this.tabMenus.length === 0) {
          this.tabMenus = this.tabMenus.concat([this.base]);
          this.currentTab = this.base;
        }
        if (tab) {
          const tabData = getTabRouteData(tab);
          if (!this.tabMenus.some((item) => item.name === tabData.name)) {
            this.tabMenus = this.tabMenus.concat([tabData]);
            this.currentTab = tabData;

          }
        }
      }
    },
    ChangeCurrentTab(tab) {
      this.currentTab = tab;
    },
    RemoveTab(tab) {
      const removeIndex = this.tabMenus.indexOf(tab);
      this.tabMenus = this.tabMenus.filter(
        (item) => item.fullPath !== tab.fullPath
      );
      this.currentTab = this.tabMenus[removeIndex - 1];
    },
    RemoveRightTab(tab) {
      const removeIndex = this.tabMenus.indexOf(tab);
      this.tabMenus = this.tabMenus.slice(0, removeIndex + 1);
    },
    RemoveLeftTab(tab) {
      const removeIndex = this.tabMenus.indexOf(tab);
      const rightMenu = this.tabMenus.slice(removeIndex);
      this.tabMenus = [this.base].concat(rightMenu);
    },
    DestroyTabMenu() {
      this.currentTab = '';
      this.tabMenus = [];
    },
  },
});
