const routes: Array<RouteRecordRaw> = [
  {
    path: 'http://www.baidu.com',
    name: 'http://www.baidu.com',
    component: {},
    meta: {
      index: 3,
      title: '百度',
      icon: 'ant-design:alipay-square-filled',
    },
  },
];

export default routes;
