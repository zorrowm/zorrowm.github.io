const routeName = 'home2';
const routes: Array<RouteRecordRaw> = [
  {
    path: 'home',
    name: routeName,
    meta: {
      index: 1,
      title: '首页2',
      icon: 'ant-design:home-outlined',
    },
    component: () => import('src/pages/aDefault/Dashboard.vue'), //
  },
];

export default routes;
