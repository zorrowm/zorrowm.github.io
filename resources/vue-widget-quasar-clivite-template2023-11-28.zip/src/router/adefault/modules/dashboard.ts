const routeName = 'dashboard2';

const routes: Array<RouteRecordRaw> = [
  {
    path: 'dashboard',
    name: routeName,
    redirect: '/default/dashboard/welcome',
    meta: {
      index: 2,
      title: '仪表盘',
      icon: 'ant-design:bank-outlined',
    },
    children: [
      {
        path: '/default/dashboard/welcome',
        name: `${routeName}-welcome`,
        meta: {
          title: '欢迎',
          icon: 'ant-design:global-outlined',
        },
        component: () => import('pages/back/welcome/index.vue'),
      },
    ],
  },
];

export default routes;
