import { getRouteURL } from 'src/utils/sysTool';
import { RouteRecordRaw } from 'vue-router';

import backroutes from './modules/index';

const defaultRoute: RouteRecordRaw = {
  path: '/default',
  name: 'DefaultLayout',
  component: () => import('src/layouts/adefault/defaultLayout.vue'),
  redirect: getRouteURL(backroutes[0]?.path, '/default'),
  children: backroutes,
  // children: [{ path: '', component: () => import('pages/IndexPage.vue') }],
};

export default defaultRoute;
