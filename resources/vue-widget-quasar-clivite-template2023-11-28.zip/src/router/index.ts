import { route } from 'quasar/wrappers';
import { EmitLoadingInfo } from 'src/events/index';
//默认路由结构
import aDefault from 'src/router/adefault/index';
import backLayout from 'src/router/back';
import bigScreenLayout from 'src/router/bigScreen/index';
import examples from 'src/router/examples/index';
//添加路由模块
import mainLayout from 'src/router/main/index';
import portalLayoutRoute from 'src/router/portal/index';
import productLayoutRoute from 'src/router/product/index';
import system from 'src/router/system/index';
import {
  createMemoryHistory,
  createRouter,
  createWebHashHistory,
  createWebHistory,
  RouteRecordRaw,
} from 'vue-router';
import { Global } from 'xframelib';

import { createRouterGuards } from './router-guards';

// import sideBarLayout from 'src/router/sideBar/index';

EmitLoadingInfo('Router路由');
// 当前业务视图路由，用于动态获取业务路由
export const bussinessRoutes: Array<RouteRecordRaw> = [
  aDefault,
  mainLayout,
  backLayout,
  bigScreenLayout,
]; //
//用于初始化，只加载系统的路由
//IsNoLogin: true, 无需登录时，初始化全部路由
export const common: Array<RouteRecordRaw> = [portalLayoutRoute,productLayoutRoute,...system, examples];
export const systemRoutes: Array<RouteRecordRaw> = Global.Config.UI.IsNoLogin
  ? [ ...bussinessRoutes,...common]
  : common; //[...common, ...bussinessRoutes]; //[mainLayout, backLayout, ...common];//全部路由

//  console.log(Global.Config.UI.IsNoLogin, common, systemRoutes, '44444444444');
export default route(function (/* { store, ssrContext } */) {
  const createHistory = process.env.SERVER
    ? createMemoryHistory
    : process.env.VUE_ROUTER_MODE === 'history'
    ? createWebHistory
    : createWebHashHistory;

  const Router = createRouter({
    scrollBehavior: () => ({ left: 0, top: 0 }),

    //系统路由
    routes: systemRoutes,

    // Leave this as is and make changes in quasar.conf.js instead!
    // quasar.conf.js -> build -> vueRouterMode
    // quasar.conf.js -> build -> publicPath
    history: createHistory(process.env.VUE_ROUTER_BASE),
  });
  // 创建路由守卫
  if (!Global.Config.UI?.IsNoLogin) createRouterGuards(Router);
  return Router;
});
