import { getRouteURL } from 'src/utils/sysTool';

import portalroutes from './modules/index';
const path = '/';
const portalRoute = {
  path,
  name: 'Portal',
  component: () => import('layouts/portal/index.vue'),
  redirect: getRouteURL(portalroutes[0]?.path, path),
  meta: {
    title: '',
    hidden: true,
    isSystem: true,
  },
  children: portalroutes,
};

export default portalRoute;
