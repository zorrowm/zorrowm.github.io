import { recursiveRoutes } from 'src/utils/sysTool';
import { RouteRecordRaw } from 'vue-router';
const components = import.meta.glob('./*.ts', { eager: true });
const menuCofig: Array<RouteRecordRaw> = recursiveRoutes(components);
export default menuCofig;
