import { getRouteURL } from 'src/utils/sysTool';

import productroutes from './modules/index';
const path = '/product';
const productRoute = {
  path,
  name: 'Product',
  component: () => import('layouts/product/productLayout.vue'),
  redirect: getRouteURL(productroutes[0]?.path, path),
  meta: {
    title: '',
    hidden: true,
    isSystem: true,
  },
  children: productroutes,
};

export default productRoute;
