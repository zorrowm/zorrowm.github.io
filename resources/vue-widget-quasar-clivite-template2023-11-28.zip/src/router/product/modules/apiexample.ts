import { RouteRecordRaw } from 'vue-router';
const routes: Array<RouteRecordRaw> = [
  {
    path: 'apiexamples',
    name: 'apiexamples',
    component: () => import('pages/product/apiexamples/index.vue'),
    meta: {
      index: 4,
      title: '查询-api示例',
      hidden: true,
      isSystem: true,
    },
  },
  // {
  //   path: '/examplesPlayer',
  //   name: 'examplesPlayer',
  //   component: () => import('pages/product/apiexamples/components/examplesPlayer.vue'),
  //   meta: {
  //     index: 4,
  //     title: '查询-api示例详情页',
  //     hidden: true,
  //     isSystem: true,
  //   },
  // },
];

export default routes;
