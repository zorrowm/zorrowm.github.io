import { RouteRecordRaw } from 'vue-router';
const routes: Array<RouteRecordRaw> = [
  {
    path: 'productPage',
    name: 'productPage',
    component: () => import('pages/product/productPage/index.vue'),
    meta: {
      index: 2,
      title: '查询-产品宣传',
      hidden: true,
      isSystem: true,
    },
  },
  {
    path: '/image',
    name: 'imagePage',
    component: () => import('pages/product/image/index.vue'),
    meta: {
      index: 3,
      title: '影像',
      hidden: true,
      isSystem: true,
    },
  },
];

export default routes;
