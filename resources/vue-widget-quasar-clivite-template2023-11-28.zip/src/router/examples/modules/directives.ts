const directiveExamples = [
  {
  path: 'vmedia',
  name: 'vmedia',
  meta: {
    title: '自适应样式',
    hidden: true,
  },
  component: () => import('src/examples/Directive/Vmedia.vue'),
},
{
  path: 'vwow',
  name: 'vwow',
  meta: {
    title: '动画加载',
    hidden: true,
  },
  component: () => import('src/examples/Directive/Vwow.vue'),
}
];

export default directiveExamples;
