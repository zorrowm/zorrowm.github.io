 const xwindow = {
  path: 'xwindow',
  name: 'xwindow',
  meta: {
    title: '可移动窗体',
    hidden: true,
  },
  component: () => import('src/examples/XWindow/index.vue'),
};


export default [xwindow];
