export const largeDisplay = {
  path: 'large-display',
  name: 'LargeDisplay',
  meta: {
    title: '单大屏',
    hidden: true,
  },
  component: () => import('src/examples/LargeDisplay/pages/large-display.vue'),
};

/**
 * 滚屏加载页面
 * （使用动画）
 */
const scrollPage={
  path: 'scroll-page',
  name: 'scroll-page',
  meta: {
    title: '滚动动态加载页面',
    hidden: true,
  },
  component: () => import('src/examples/ScrollPage/index.vue'),
}

export default [largeDisplay,scrollPage];
