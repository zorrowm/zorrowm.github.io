import { getRouteURL } from 'src/utils/sysTool';
import { RouteRecordRaw } from 'vue-router';

import backroutes from './modules/index';

const defaultRoute: RouteRecordRaw = {
  path: '/examples',
  name: 'examples',
  component: () => import('components/RouterTransition/index.vue'),
  redirect: getRouteURL(backroutes[0]?.path, '/examples'),
  children: backroutes,
};

export default defaultRoute;
