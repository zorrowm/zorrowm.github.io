/*
 * @Author: zorrowm zorrowm@126.com
 * @Date: 2023-05-08 09:04:28
 * @LastEditors: zorrowm zorrowm@126.com
 * @LastEditTime: 2023-06-03 09:15:27
 * @FilePath: \Feido三维开发模板\src\directives\index.ts
 * @Description:
 *
 * Copyright (c) 2023 by zorrowm , All Rights Reserved.
 */
//https://floating-vue.starpad.dev/guide/directive
import { VClosePopper,VTooltip } from 'floating-vue';
import type { App } from 'vue';

import { setupDragDirective } from './dragDirective';
import { setupmediaDirective } from './mediaDirective';
// import {setupLoadingDirective} from './loading';
import { setupRepeatDirective } from './repeatClick';
import { setupWowDirective } from './wowDirective';

export function setupGlobDirectives(app: App) {
  setupDragDirective(app);
  // setupLoadingDirective(app);
  setupWowDirective(app);
  setupRepeatDirective(app);
  setupmediaDirective(app);
  //指令
  app.directive('tooltip', VTooltip);
  app.directive('close-popper', VClosePopper);
}
