//表格的相关事件
export default {
  RefeshTable: 'RefeshTable', //刷新表格
};
