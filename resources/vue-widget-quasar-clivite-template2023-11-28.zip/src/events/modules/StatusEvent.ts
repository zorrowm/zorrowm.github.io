//状态栏消息
export default {
  SatusMessage: 'statusmessage', //状态栏消息
  LoadingMessage: 'loadingMessage', //初始化加载消息
};
