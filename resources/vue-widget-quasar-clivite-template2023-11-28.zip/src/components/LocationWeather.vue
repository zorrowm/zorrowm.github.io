<template>
  <div class="row justify-center q-gutter-x-md">
    <span v-if="currentPosition" class="row items-center"><Icon icon="ic:baseline-location-on"/>{{currentPosition.city+' '+ currentPosition.addr }}</span>
  <div v-if="weatherNow" class="row items-center q-gutter-x-sm">
   <i-icon :name="weatherNow?.icon" :size="24"></i-icon>
   <span>{{ weatherNow?.text }}</span>
   <span>{{ weatherNow?.temp }}°</span>
   <span>{{ weatherNow?.windDir }}</span>
   <span>{{ weatherNow?.windScale }}级</span>
   <!-- <span>体感温度{{ weatherNow?.feelsLike }}°</span> -->
  </div>

  </div>
</template>

<script setup lang="ts">
//https://www.npmjs.com/package/iweather_icons
import { icon as IIcon } from 'iweather_icons';
import {getAddressInfo} from 'src/netAPI/QQLocation';
import {getWeatherNow,IWeatherNow} from 'src/netAPI/QWeather';
import {onMounted,ref} from 'vue';

const currentPosition=ref();
const weatherNow=ref<IWeatherNow>();
onMounted(async ()=>{
      //定位坐标
   const cityInfo=await getAddressInfo();
   if(cityInfo)
   {
     currentPosition.value=cityInfo;
    // console.log(cityInfo,'位置信息****')
     const res=await getWeatherNow(cityInfo.lng,cityInfo.lat);
     if(res)
     {
      weatherNow.value=res;
      // console.log(res,'天气信息****')
     }
   }
})
</script>

<style scoped>

</style>
