<template>
  <q-dialog v-model="visibleRef">
    <q-card :style="cardStyle">
      <q-card-section class="row items-center q-pb-none">
        <div class="text-h6">{{ titleRef }}</div>
        <q-space />
        <q-btn v-close-popup icon="close" flat round dense />
      </q-card-section>

      <q-card-section>
        <component
          :is="content"
          v-if="visibleRef"
          :extra="extra"
          :data="dataRef"
        ></component>
      </q-card-section>
      <q-separator v-if="footerRef" />
      <q-card-actions v-if="footerRef" align="right">
        <q-btn
          v-close-popup
          flat
          label="取消"
          color="primary"
          @click="handleCancel"
        />
        <q-btn
          v-close-popup
          flat
          label="确定"
          color="primary"
          @click="handleOk"
        />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>
<script lang="ts">
import { EmitMsg, OffEventHandler,OnEventHandler } from 'src/events';
import WidgetsEvent from 'src/events/modules/WidgetsEvent';
import { IExtraProperty } from 'src/models/IModalModels';
import {
  computed,
  defineComponent,
  onMounted,
  onUnmounted,
  ref,
  watch,
} from 'vue';
import { bool, number, object, oneOfType } from 'vue-types';
import { Global } from 'xframelib';

export default defineComponent({
  name: 'ModalContainer',
  props: {
    width: number().def(400),
    visible: bool().def(false),
    content: object<any>(),
    //支持数据为多类型
    data: oneOfType([String, Number, Boolean, Array, Object]),
    extra: object<IExtraProperty>(),
  },
  setup(props) {
    const visibleRef = ref<boolean>(props.visible);
    const dataRef = ref(props.data);
    watch(
      () => props.visible,
      (newVal, oldVal) => {
        visibleRef.value = newVal;
        if (props.visible)
          //必须的
          dataRef.value = props.data;
      }
    );
    //解决：不可见时仍旧传值
    watch(
      () => props.data,
      () => {
        if (visibleRef.value) {
          dataRef.value = props.data;
        }
      }
    );
    //标题
    const titleRef = computed(() => {
      if (props.extra?.title) return props.extra?.title;
      else if (props.content) return props.content.title;
      else return '对话框';
    });

    //底部按钮栏
    const footerRef = computed(() => {
      if (props.extra?.footer) return props.extra?.footer;
      else return undefined;
    });

    //确定
    const handleOk = (e: MouseEvent) => {
      const formChild = props.content;
      if (formChild) {
        if (formChild.validateForm) {
          formChild
            .validateForm()
            .then((res) => {
              //校验成功
              visibleRef.value = false;
              EmitMsg(formChild.name, true);
            })
            .catch((ex) => {
              Global.Message?.err('表单校验失败！');
            });
        } else {
          visibleRef.value = false;
          EmitMsg(formChild.name, true);
        }
      }
    };
    //取消
    const handleCancel = (e: MouseEvent) => {
      visibleRef.value = false;
      if (props.content) EmitMsg(props.content.name, false);
    };

    function closeModal(data) {
      visibleRef.value = false;
    }
    onMounted(() => {
      OnEventHandler(WidgetsEvent.ModalContainerWidget_CloseModal, closeModal);
    });
    onUnmounted(() => {
      OffEventHandler(WidgetsEvent.ModalContainerWidget_CloseModal, closeModal);
    });

    const cardStyle = computed(() => {
      return `width: ${props.width}px; max-width: 80vw`;
    });
    return {
      dataRef,
      visibleRef,
      handleOk,
      titleRef,
      footerRef,
      handleCancel,
      cardStyle,
    };
  },
});
</script>
