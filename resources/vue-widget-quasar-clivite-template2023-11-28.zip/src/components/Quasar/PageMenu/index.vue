<template>
  <div class="row gt-xs q-py-md q-gutter-xs">
    <template v-for="(item,index) in dataRef" :key="item.label" >
    <q-btn-dropdown
      v-if="item.children"
      v-model:model-value="item.state"
      transition-show="flip-right"
      transition-hide="flip-left"
      flat
      :label="item.label"
      :class="getSelectedStyle(item)"
      @mouseover="setShowState(item,true)"
      >
      <q-list
        style="min-width: 100px"
        @mouseover="setShowState(item,true)"
        @mouseleave="setShowState(item,false)"
      >
      <template v-for="(it,ii) in item.children" :key="it.label">
        <q-item
         v-close-popup clickable :class="getSelectedStyle(it)" @click="menuClickHandler(it)">
          <q-item-section >{{ it.label }}</q-item-section>
        </q-item>
        <q-separator />
      </template>
      </q-list>
    </q-btn-dropdown>
    <q-btn
     v-else color="black"  flat :label="item.label"
    :class="getSelectedStyle(item)"
    @click="menuClickHandler(item)"
    @mouseover="setShowState(item,false)"
    />
    </template>
  </div>
</template>

<script setup lang="ts">
import {OpenURL} from 'src/utils/urlUtils';
import {ref} from 'vue';
import { useRoute,useRouter } from 'vue-router';
import { Global } from 'xframelib';

import { EnumPageMenu,IPageMenu } from './IPageMenu';

const props=defineProps({
data:{
type:Array<IPageMenu>,
required:true,
}
})
const dataRef=ref(props.data);
const router=useRouter();
const route=useRoute();
function getSelectedStyle(item)
{
if(item.children)
{
let exisit=false;
item.children.forEach(it => {
  if(it.path===route.path)
  {
    exisit=true;
    return;
  }
});
if(exisit)
{
  return ' pagemenuActive';
}

}
else{
if(item.path===route.path)
return 'pagemenuActive';
}
return '';
}

const currentItem=ref<any>();
function setShowState(item:any,value:boolen)
{
const key=item.label;
if(!currentItem.value)
{
currentItem.value=item;
item.state=value;
return;
}
else
{
if(currentItem.value.label!=key)
{
  currentItem.value.state=false;
}
currentItem.value=item;
item.state=value;
}
}
function menuClickHandler(menuItem:IPageMenu)
{
if(!menuItem||menuItem.children)
return;
if(menuItem.path)
{
switch(menuItem.kind)
{
  case undefined:
  case EnumPageMenu.Route:

    if(menuItem.blank)
    {
      OpenURL(router,menuItem.path,{});
    }
    else
    {
      router.push({
        path:menuItem.path
      })
    }
    break;
  case EnumPageMenu.URL:
    window.open(menuItem.path, '_blank');
    break;
  case EnumPageMenu.Action:
    Global.EventBus.emit('IPageMenu.Action',menuItem);
    break;
  case EnumPageMenu.Widget:
    Global.EventBus.emit('LayoutLoadWidget',menuItem);
    break;
}
}


}
</script>

<style lang="scss">
.pagemenuActive
{
background-color:#eee;
}
</style>
