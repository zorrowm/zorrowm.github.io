/**
 * 菜单类型
 */
export enum EnumPageMenu
{
  Widget,//Widget唯一ID
  Route,//跳转路由
  URL, //外部连接
  Action,//外部行为，事件
}
/**
 * 页面的上方的
 * 水平菜单
 */
export interface IPageMenu {
  id?:string;//id，唯一标识
  index?:number;//索引,排序

  label:string;//菜单标识，中文名
  icon?: string; //图标名
  kind?:EnumPageMenu;//菜单类型，默认为Route
  path?: string; //控件名、路由路径或URL路径
  blank?: boolean; //是否空白页打开，针对Route 和URL情况
  children?: Array<IPageMenu>;
  tag?: object; //传递的数据（备用），主要为action传参
}
