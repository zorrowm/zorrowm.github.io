<template>
  <div class="q-pa-md q-gutter-sm treePanel">
    <q-tree
      v-model:expanded="expanded"
      :nodes="QuasarTreeData"
      node-key="iD"
      dense
      default-expand-all
    >
      <template #default-header="prop">
        <div
          class="row no-wrap items-center rounded-borders"
          style="width: 100%"
        >
          <Icon
            v-if="prop.node.children"
            :icon="
              isExpanded(prop.node)
                ? 'ant-design:folder-open-outlined'
                : 'ant-design:folder-outlined'
            "
          />
          <div class="text-weight-bold text-white">{{ prop.node.name }}</div>
          <q-space />
          <div v-if="!prop.node.children" v-ripple>
            <Icon
              clickable
              class="q-mr-sm"
              :icon="
                prop.node.visiblity
                  ? 'ant-design:eye-filled'
                  : 'ant-design:eye-invisible-filled'
              "
              @click="doChangeVisible(prop.node)"
            />
            <Icon clickable icon="ic:baseline-my-location" @click="doLocate(prop.node)" />
          </div>
        </div>
      </template>
    </q-tree>
  </div>
</template>

<script setup lang="ts">
import { storeToRefs } from 'pinia';
import { aircityStore } from 'src/stores/FeiDo/aircity';
import { ref } from 'vue';

const acState = aircityStore();
const {QuasarTreeData} =storeToRefs(acState);
const expanded = ref(['ProjectTree_Root']); //

function isExpanded(node):boolean
{
  const idx=expanded.value.findIndex(p=>p===node.iD);
  return idx>=0;
}
/**
 * 定位图层
 * @param node
 */
function doLocate(node) {
  if(acState.IsOnReady)
  {
    __g.tileLayer.focus(node.iD);
  }
}
/**
 * 改变节点可见性
 * @param node
 */
function doChangeVisible(node)
{
  if(acState.IsOnReady)
  {
     node.visiblity=!node.visiblity;
     if(node.visiblity)
     {
      __g.infoTree.show(node.iD);
     }else
     __g.infoTree.hide(node.iD);
  }
}
</script>

<style scoped>
.iconify {
  color: #fff;
}
.treePanel {
  color: #fff;
  width: 300px;
  height: 500px;
}
.nodeitem {
  display: flex;
  justify-content: flex-start;
  align-items: center;
}
</style>
