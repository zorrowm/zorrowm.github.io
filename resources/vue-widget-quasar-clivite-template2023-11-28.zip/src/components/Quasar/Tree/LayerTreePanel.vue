<template>
  <WindowPanel
    title="图层管理"
    :isOpen="isOpen"
    :windowStyle="StyleRef"
    positionHint="2/10"
    :resizable="false"
    :isScrollable="true"
    :width="300"
    :style="height"
    class="layerTreePanel"
    :closeButton="true"
    @closebuttonclick="closeWindow"
  >
    <template #title>
      <span class="iconfont icon-a-Layermanagement_3"></span>
      <span style="margin-left: 10px">图层管理</span>
    </template>
    <q-toolbar class=" text-white windowToolbar">
      <q-btn flat round dense icon="assignment_ind" />
      <q-toolbar-title>
        Toolbar
      </q-toolbar-title>
      <q-btn flat round dense icon="apps" class="q-mr-xs" />
      <q-btn flat round dense icon="more_vert" />
    </q-toolbar>
    <div class="windowContent">
      <LayerTree />
    </div>

  </WindowPanel>
</template>

<script setup lang="ts">
import {onMounted,ref} from 'vue'
import {  StyleGrayblue,VWindow as WindowPanel } from 'xframelib';

import LayerTree from './LayerTree.vue';
const isOpen = ref(true);
const StyleRef = ref(StyleGrayblue);
function closeWindow() {
        if (isOpen.value) {
          // EmitMsg(SystemEvents.WidgetClosed, name);
          isOpen.value = false;
          console.log('发送消息', 'SystemEvents.WidgetClosed', isOpen.value);
        }
      }
      const height = ref('');
      onMounted(() => {
        const tmpHeight = document.body.clientHeight - 120;
        height.value = 'height:' + tmpHeight + 'px';
      });
</script>

<style lang="scss" scoped>
  .layerTreePanel {
    pointer-events: auto;
  }
  .windowContent
  {
    margin-top:0px;
    margin-left: -8px;
    width: calc(100% + 8px);
    height:calc(100% - 30px);
    overflow-x: hidden;
    overflow-y: auto;

  }
  .windowToolbar
  {
    margin: -8px 0px 0 -0px;
    width: 100%;
    min-height: 20px;
    padding: 0 5px;
    border-bottom: 1px solid #fff;
    z-index: 10;
  }
</style>
