import {ref} from 'vue';
/**
 * 菜单或分组对象
 */
export interface IExampleItem{
 name:string;//名称，唯一标识
 index?:number;//排序
 icon?:string;//图标名，或图片路径
 description?:string;//描述
 path?:string;//widget名称；代码片段名
 children?:Array<IExampleItem>;

 [prop:string]:any;//扩展属性
}

/**
 * 滚动事件名
 */
export const scrollToExampleItemEvent='scrollToExampleItem';

/**
 * 获取菜单对应条目数量
 * @param item
 * @returns
 */
// export function getMenuNum(item:IExampleItem)
// {
//   if(!isMenuGroup(item))
//   {
//     if(!item.children)
//     return 0
//     else
//     return item.children?.length;
//   }

//   else
//   {
//     let count=0;
//     item.children?.forEach(it => {
//       count+=getMenuNum(it);
//     });
//     return count;
//   }
// }


/**
 * 判断是否是菜单分组
 * @param item
 * @returns
 */
export function isMenuGroup(item:IExampleItem):boolean
{
  if(item.children&&item.children.length>0)
  {
    const it= item.children[0];
    if(it.path===undefined)
    return true;
  }
  return false;
}

//当前选中位置
export const currentMenuItem=ref('');
