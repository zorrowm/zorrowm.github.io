<template>

    <div  v-for="(item, index) in menuList" :key="index" class="base-menu-item">
     <template v-if="item.path===undefined">
      <!-- no children -->
      <q-item
        v-if="!isMenuGroup(item)"
        v-ripple
        :active="isActived(item)"
        clickable
        :inset-level="initLevel"
        active-class="baseItemActive"
        @click="handleMenuClick(item)"
      >
        <q-item-section avatar >
          <Icon :icon="item.icon"></Icon>
        </q-item-section>
        <q-item-section >
         <span>{{ getMenuLabel(item)}}</span>
        </q-item-section>
      </q-item>

      <!-- has children -->
      <q-expansion-item
       v-else
        :duration="duration"
        :default-opened="true"
        :header-inset-level="initLevel"
      >
        <template #header>
          <q-item-section avatar>
            <Icon :icon="item.icon"></Icon>
          </q-item-section>

          <q-item-section>{{ getMenuLabel(item)}} </q-item-section>
        </template>
        <!-- MenuItem initlevl + 0.2 ; concat parent path if router is existed -->
        <base-menu-item
          :menu-list="item.children"
          :init-level="initLevel + 0.2"
          :duration="duration"
        />
      </q-expansion-item>
    </template>
    </div>
</template>

<script lang="ts" setup>
import { Global } from 'xframelib';

import {currentMenuItem,IExampleItem,isMenuGroup,scrollToExampleItemEvent} from '../APIExampleHelper';
defineOptions({ name: 'BaseMenuItem' });

interface Props {
  menuList: IExampleItem[];
  initLevel?: number;
  duration?: number;
}

withDefaults(defineProps<Props>(), {
  menuList: () => [],
  initLevel: 0,
  duration: 150,
});

const handleMenuClick = ( item:IExampleItem) => {
  Global.EventBus.emit(scrollToExampleItemEvent,item.name);
};

function isActived(item):boolean
{
  return item.name===currentMenuItem.value;
}
function getMenuNum(item)
{
  if(!isMenuGroup(item))
  {
    if(!item.children)
    return 0
    else
    return item.children?.length;
  }
  else
  {
    let count=0;
    item.children?.forEach(it => {
      count+=getMenuNum(it);
    });
    return count;
  }
}

function  getMenuLabel(item)
{
  const count=getMenuNum(item);
  return `${item.name} (${count})`;
}

</script>

<style lang="scss" scoped>
.body--light {
  .base-menu-item {
    color: $ITEM_COLOR !important;

    .baseRootItemActive {
      color: $ACTIVE_COLOR !important;
    }

    .baseItemActive {
      color: $ACTIVE_COLOR !important;
      background: $ACTIVE_BACKGROUND;
      transition: all 0.618s;
      font-weight: bold;

      &:after {
        content: '';
        position: absolute;
        width: 3px;
        height: 100%;
        background: $ACTIVE_COLOR !important;
        top: 0;
        right: 0;
      }
    }
  }
}

.body--dark {
  .base-menu-item {
    color: $ITEM_COLOR_DARK !important;

    .baseRootItemActive {
      color: $ACTIVE_COLOR_DARK !important;
    }

    .baseItemActive {
      color: $ACTIVE_COLOR_DARK !important;
      background: $ACTIVE_BACKGROUND_DARK;
      transition: all 0.618s;
      font-weight: bold;

      &:after {
        content: '';
        position: absolute;
        width: 3px;
        height: 100%;
        background: $ACTIVE_COLOR_DARK !important;
        top: 0;
        right: 0;
      }
    }
  }
}
</style>
