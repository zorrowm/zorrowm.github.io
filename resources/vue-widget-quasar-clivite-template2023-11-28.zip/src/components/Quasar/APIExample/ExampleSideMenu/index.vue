<template>
  <q-scroll-area :thumb-style="thumbStyle">
    <q-list>
      <base-menu-item :menu-list="data" />
    </q-list>
  </q-scroll-area>
</template>

<script lang="ts" setup>
import {IExampleItem} from '../APIExampleHelper';
import BaseMenuItem from './BaseMenuItem.vue';

defineOptions({ name: 'ExampleSideMenu' });
defineProps({
  data: {
    type: Array<IExampleItem>,
    required: false,
    default: () => {
      return [];
    },
  },
});

const thumbStyle = {
  right: '1px',
  borderRadius: '5px',
  backgroundColor: '#616161',
  width: '5px',
};

</script>
