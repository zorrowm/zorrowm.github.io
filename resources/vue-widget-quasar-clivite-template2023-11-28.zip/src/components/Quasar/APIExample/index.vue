<template>
  <q-layout view="hHh lpR fFf" >
    <q-drawer
v-model="leftDrawerOpen"
     show-if-above side="left" bordered
     >
      <ExampleSideMenu :data="data" style="height: calc(100% - 50px);"> </ExampleSideMenu>
    </q-drawer>
    <q-page-container>
      <q-btn flat dense round aria-label="Menu" class="menuBtn" :icon="getRightIcon" @click="toggleLeftDrawer()"/>
      <ContentList :data="data" @contentItemClicked="doItemClickHandler"></ContentList>
    </q-page-container>
  </q-layout>
</template>

<script setup lang="ts">
import { computed,ref } from 'vue'

import {IExampleItem} from './APIExampleHelper';
import ContentList from './ExampleContent/ContentList.vue'
import ExampleSideMenu from './ExampleSideMenu/index.vue';

const emit = defineEmits(['contentItemClicked']);
 defineProps({
  data: {
    type: Array<IExampleItem>,
    required: true,
  },
});

const leftDrawerOpen = ref<boolean>(false);
const toggleLeftDrawer = () => {
  leftDrawerOpen.value = !leftDrawerOpen.value;
};

const getRightIcon = computed(() => {
  if (!leftDrawerOpen.value) {
    return 'menu';
  } else {
    return 'menu_open';
  }
});
function doItemClickHandler(it)
{
  emit('contentItemClicked',it);
}

</script>
<style lang="scss" scoped>
.menuBtn{
  float: left;
  top:-5px;
  left:5px;
  z-index: 100;
}
</style>
