<template>
  <div ref="contentExampleListContainerRef" class="contentExampleListContainer" >
    <content-item :content-list="data" @item-clicked="itemClickHandler"/>
  </div>
</template>
<script lang="ts" setup>
import { onMounted, onUnmounted, ref } from 'vue';
import { Global } from 'xframelib';

import {currentMenuItem,IExampleItem,scrollToExampleItemEvent} from '../APIExampleHelper';
import contentItem from './ContentItem.vue';

const emit = defineEmits(['contentItemClicked']);
 defineProps({
  data: {
    type: Array<IExampleItem>,
    required: true,
  },
});

const contentExampleListContainerRef=ref();
/**
 * 滚动到特定位置
 * @param name
 */
function scrollScreenTo(name:string){
  currentMenuItem.value=name;
  const target=document.getElementById(name);
  contentExampleListContainerRef.value?.scrollTo({
    top:target?.offsetTop,
    behavior: 'smooth'
  })
}
function itemClickHandler(it)
{
  emit('contentItemClicked',it);
}
onMounted(() => {
  Global.EventBus.on(scrollToExampleItemEvent, scrollScreenTo);
});
onUnmounted(() => {
  Global.EventBus.off(scrollToExampleItemEvent, scrollScreenTo);
});

</script>
<style>
.contentExampleListContainer {
  position: relative;
  overflow: auto;
  height: calc(100vh - var(--header-top-height));
}
.groupDescription {
  margin-top: 10px;
  width: 100%;
  background-color: #eee;
  border-left: solid 5px #666;
  color: #888;
  font-size: 14px;
  padding: 8px;
}
</style>
