<template>
  <div v-for="(item, index) in contentList" :key="index">
    <template v-if="!isMenuGroup(item)">
      <div :id="item.name" class="text-h5 text-weight-bold q-ma-lg">
        {{ item.name }}
        <div v-if="item.description" class="groupDescription shadow-2">
          {{ item.description }}
        </div>
      </div>
      <div class="row q-gutter-md">
        <div
          v-for="(chidrenItem, chidrenIndex) in item.children"
          :key="chidrenIndex"
        >
          <q-card @click="doCardClick(chidrenItem)">
            <q-card-section class="q-py-md">
              <img :src="chidrenItem.icon" />
            </q-card-section>
            <q-card-section>
              <div class="text-h6 text-weight-light q-pb-sm">
                {{ chidrenItem.name }}
              </div>
              <div
                v-if="chidrenItem.description"
                class="text-subtitle2 text-wrap"
                style="max-width: 400px"
              >
                {{ chidrenItem.description }}
              </div>
            </q-card-section>
          </q-card>
        </div>
      </div>
    </template>
    <template v-else>
      <div class="text-h4 text-weight-bold q-ma-md">
        {{ item.name }}
        <div v-if="item.description" class="groupDescription shadow-2">
          {{ item.description }}
        </div>
      </div>
      <q-separator size="3px" />
      <content-item :content-list="item.children" @itemClicked="doCardClick" />
    </template>
  </div>
</template>
<script lang="ts" setup>
import {IExampleItem,isMenuGroup} from '../APIExampleHelper';

defineProps({
  contentList: {
    type: Array<IExampleItem>,
    required: false,
    default: () => {
      return [];
    },
  },
});
const emit = defineEmits(['itemClicked']);

function doCardClick(item) {
  emit('itemClicked',item);
}

</script>
