<template>
  <div class="topBox">
    <span class="toptitle">{{ title }}</span>
    <span class="topright">
      <q-input
        v-model:value="searchValue"
        label="请输入关键字"
        style="width: 200px; margin-right: 30px"
        class="rightBoxItem"
        clearable
        @update:model-value="doClick('searchWord')"
      />
      <q-btn
        v-if="ifTask"
        color="primary"
        class="rightBoxItem"
        style="margin-right: 10px"
        @click="doClick('creatNew')"
      >
        <Icon icon="ant-design:plus-outlined" />
      </q-btn>
      <span v-if="ifTask" title="批量删除" @click="doClick('batchDelete')">
        <Icon icon="ant-design:delete-outlined" style="margin-right: 20px" />
      </span>
      <span title="刷新">
        <Icon icon="ant-design:sync-outlined" @click="doClick('refresh')" />
      </span>
    </span>
  </div>
</template>

<script lang="ts">
import { defineComponent, onMounted,reactive, toRefs } from 'vue';

export default defineComponent({
  name: 'topFunBar',
  props: {
    title: {
      type: String,
      default: '',
    },
    ifTask: {
      type: Boolean,
      default: true,
    },
  },
  setup(props, { emit }) {
    const state = reactive({
      searchValue: '',
    });
    //点击事件
    const doClick = (val: string) => {
      if (val === 'searchWord') {
        emit('topBarClick', val, state.searchValue);
      } else {
        emit('topBarClick', val);
      }
    };

    return {
      ...toRefs(state),
      doClick,
    };
  },
});
</script>
<style lang="scss" scoped>
.toptitle {
  font-weight: bold;
}

.topright {
  float: right;
}

.topBox {
  height: 50px;
  padding: 10px;
}
</style>
