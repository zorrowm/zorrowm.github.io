<template>
  <div class="fit">
    <base-skelton :show="loading" />
    <iframe
      v-show="!loading"
      ref="iframe"
      class="fit"
      style="border: none"
      :src="src"
    ></iframe>
  </div>
</template>

<script setup lang="ts">
import BaseSkelton from 'src/components/Skelton/BaseSkelton.vue';
import { onMounted,ref } from 'vue';

defineOptions({ name: 'IframeDIV' });
withDefaults(defineProps<{ src: string }>(), { src: '' });

const loading = ref<boolean>(false);
const iframe = ref<any>(null);

onMounted(() => {
  loading.value = true;
  if (iframe.value.attachEvent) {
    // IE
    iframe.value.attachEvent('onload', () => {
      loading.value = false;
    });
  } else {
    // not IE
    iframe.value.onload = () => {
      loading.value = false;
    };
  }
});
</script>

<style scoped></style>
