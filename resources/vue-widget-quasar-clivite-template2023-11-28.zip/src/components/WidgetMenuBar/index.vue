<template>
  <ul class="menuBar">
    <li v-for="(item, idx) in MenuData" :key="idx" :class="getClass(item)">
      <span :title="item.name" @click="itemClick(item)">
        <Icon v-if="item.icon" :icon="item.icon" :color="iconColor" />
        <template v-else>{{ item.name }}</template>
      </span>
    </li>
  </ul>
</template>

<script setup lang="ts">
import * as ActionTool from 'src/actions';
import { MenuItemEnum } from 'src/enums/menuEnum';
import type { IWidgetMenu } from 'src/models/IWidgetMenu';
import MenuSettings from 'src/settings/widgetMenuSetting/index';
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { Global, LayoutManager } from 'xframelib';

const props = defineProps({
  LayoutID: {
    type: String,
    default: 'default',
  },
  MenuData: {
    type: Array<IWidgetMenu>,
    default: MenuSettings,
  },
  iconColor:
  {
    type:String,
    default:'#f00'
  },
  itemSize:
  {
    type:String,
    default:'50px'
  }
});
const itemLength = ref(MenuSettings.length);
const router = useRouter();
const selectedMapList = new Map<string, boolean>();
const selectedMap = ref<Map<string, boolean>>(selectedMapList);
function itemClick(menuItem: IWidgetMenu) {
  switch (menuItem.type) {
    case MenuItemEnum.URL:
      window.open(menuItem.path, '_blank');
      break;
    case MenuItemEnum.Route:
      if (menuItem.blank) {
        if (menuItem.path) {
          let routeData = router.resolve({
            path: menuItem.path,
          });
          window.open(routeData.href, '_blank'); //新标签打开
        }
      } else {
        if (menuItem.path) router.push({ path: menuItem.path }); //本地跳转
      }
      break;
    case MenuItemEnum.Action:
      const method = menuItem.path;
      if (method && ActionTool[method]) ActionTool[method](menuItem);
      break;
    case MenuItemEnum.Widget:
      if (menuItem.path) {
        const layoutManager = Global.LayoutMap.get(props.LayoutID);
        if (!layoutManager) {
          Global.Message?.warn(`LayoutID:${props.LayoutID}的Manager不存在`);
          return;
        }
        //控制加载或可见性
        controlMenuWidget(layoutManager,menuItem);
        menuItem.selected = !menuItem.selected;
        //保存当前记录
        selectedMap.value.set(menuItem.name, menuItem.selected);
      } else {
        Global.Message?.warn(`加载${menuItem.name} Widget:缺少WidgetID!`);
      }
      break;
  }
}
function controlMenuWidget(
  layoutManager: LayoutManager,
  menuItem: IWidgetMenu
) {
  if (!menuItem.path) return;
  if (!menuItem.selected) {
    const isExist = layoutManager.isWidgetLoaded(menuItem.path);
    if (!isExist) {
      layoutManager.loadWidget(menuItem.path);
      Global.Logger().info('加载Widget：' + menuItem.path);
    } else {
      Global.Logger().info('显示widget: '+menuItem.path);
      layoutManager.changeWidgetVisible(menuItem.path, true);
    }
  } else {
    if (menuItem.unload) {
      Global.Logger().info('卸载widget: '+menuItem.path);
      layoutManager.unloadWidget(menuItem.path);
    }
    else {
      Global.Logger().info('隐藏widget: '+menuItem.path);
      layoutManager.changeWidgetVisible(menuItem.path, false);
    }
    //联动修改子菜单
    if(menuItem.children)
      {
        menuItem.children.forEach(childItem=>{
          if(childItem.selected)
          {
            Global.Logger().info(`递归控制${menuItem.path}的子Widget:`+childItem.path);
            controlMenuWidget(layoutManager,childItem);
            childItem.selected = !childItem.selected;
          }
        })
      }
  }
}

function getClass(item: IWidgetMenu) {
  if (selectedMap.value?.has(item.name) && selectedMap.value.get(item.name)) {
    return 'menuBarItem active';
  } else {
    return 'menuBarItem';
  }
}
</script>

<style lang="scss" scoped>
.menuBar {
  display: flex;
  flex-direction: row;
  justify-items: center;
  align-items: center;
  align-content: space-around;
  justify-content: space-around;
  width: calc(v-bind(itemSize + 10) * v-bind(itemLength));
  background-color: #fff;
  padding: 5px;
}
.menuBarItem {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-content: center;
  background-color: #aaa;
  border-radius: 10%;
  width: v-bind(itemSize);
  height: v-bind(itemSize);
  span {
    text-align: center;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  &:hover {
    background-color: #f00;
  }
}
.active {
  background-color: #00f !important;
}
</style>
