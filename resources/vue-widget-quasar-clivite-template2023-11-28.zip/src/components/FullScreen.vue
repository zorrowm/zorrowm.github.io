<template>
  <span @click="toggle">
    <Icon v-if="!isFullscreen" icon="ant-design:fullscreen-outlined"  :color="color"/>
    <Icon v-else icon="ant-design:fullscreen-exit-outlined" :color="color"/>
    <q-tooltip>
      {{ getTitle }}
    </q-tooltip>
  </span>
</template>
<script lang="ts">
import { computed, defineComponent, ref } from 'vue';
import { object,string } from 'vue-types';
import { H5Tool } from 'xframelib';
export default defineComponent({
  name: 'FullScreen', //FullscreenOutlined
  // components: {  },//Icon
  props: {
    target: object<any | Element>(),
    color:string()
  },
  setup(props) {
    function toggle() {
      if (isFullscreen.value) {
        H5Tool.exitFullScreen();
        isFullscreen.value = false;
      } else {
        H5Tool.requestFullScreen(props.target);
        isFullscreen.value = true;
      }
    }
    const isFullscreen = ref(false); //computed(() => H5Tool.isFullScreen());
    const getTitle = computed(() => {
      return isFullscreen.value ? '退出全屏' : '全屏';
    });
    return {
      getTitle,
      isFullscreen,
      toggle,
    };
  },
});
</script>
