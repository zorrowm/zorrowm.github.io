<template>
  <SuspenseWithError>
    <router-view v-slot="{ Component, route }">
      <keep-alive :include="keepAliveComponents">
          <component :is="Component" />
      </keep-alive>
    </router-view>
  </SuspenseWithError>
</template>

<script lang="ts" setup>
import { asyncRouteStore } from 'src/stores';
import { computed, onMounted } from 'vue';
import { Global } from 'xframelib';

import SuspenseWithError from './SuspenseWithError.vue';

defineOptions({ name: 'RouterTransition' });
// 需要缓存的路由组件
const keepAliveComponents = computed(
  () => asyncRouteStore()?.keepAliveComponents
);
onMounted(() => {
  Global.Loading('end');
});
</script>
