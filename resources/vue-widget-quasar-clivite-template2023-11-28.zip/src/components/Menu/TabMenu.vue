<template>
  <q-tabs
    v-if="!loginPage"
    dense
    inline-label
    outside-arrows
    mobile-arrows
    :class="darkThemeTab"
    style="width: 100%"
    align="left"
    swipeable
    :breakpoint="0"
  >
    <q-route-tab
      v-for="tab in tabMenus"
      :key="tab.path"
      tabMenuStore.selectRouteLabel
      exact
      replace
      :to="tab.fullPath"
      :name="tab.path"
    >
      <template #default>
        <Icon v-if="tab.icon" size="1.1rem" :icon="tab.icon" />
        <span class="tab-label">{{ selectRouteLabel(tab) }}</span>
        <q-icon
          v-if="tab.name !== defaultPage"
          class="tab-close"
          name="close"
          @click.prevent.stop="removeTab(tab)"
        />
        <q-menu touch-position context-menu>
          <q-list dense bordered separator class="bg-white text-dark">
            <q-item v-close-popup v-ripple clickable>
              <q-item-section @click="removeOtherTab(tab)">
                关闭其他
              </q-item-section>
            </q-item>
            <q-item v-close-popup v-ripple clickable>
              <q-item-section @click="removeRightTab(tab)">
                关闭右边
              </q-item-section>
            </q-item>
            <q-item v-close-popup v-ripple clickable>
              <q-item-section @click="removeLeftTab(tab)">
                关闭左边
              </q-item-section>
            </q-item>
            <q-item v-close-popup v-ripple clickable>
              <q-item-section @click="removeAllTab"> 关闭全部 </q-item-section>
            </q-item>
          </q-list>
        </q-menu>
      </template>
    </q-route-tab>
  </q-tabs>
</template>

<script lang="ts" setup>
import useTheme from 'src/composables/useTheme';
import { tabMenuStore } from 'src/stores';
import { computed, nextTick,onMounted, onUnmounted, ref, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';

const tabMenuState = tabMenuStore();
const { darkThemeTab } = useTheme();
const router = useRouter();
const route = useRoute();

const tabMenus = computed(() => tabMenuState.tabMenus);
const currentTab = computed(() => tabMenuState.currentTab);
const defaultPage = computed(() => tabMenuState.base?.name);

watch(route, () => {
  tabMenuState.AddTabMenu(Object.assign({}, route));
});
onMounted(() => {
  tabMenuState.AddTabMenu(Object.assign({}, route));
});
onUnmounted(() => {
  tabMenuState.DestroyTabMenu();
});
const loginPage = ref(false);

function selectRouteLabel(obj): string | undefined {
  return obj.title;
}
const removeTab = (tab) => {
  if (tab.path === currentTab.value?.path) {
    tabMenuState.RemoveTab(tab);
    nextTick(() => {
      router.push({ name: currentTab.value?.name });
    });
  } else {
    tabMenuState.RemoveTab(tab);
  }
};
const removeOtherTab = (tab) => {
  tabMenuState.DestroyTabMenu();
  tabMenuState.AddTabMenu(tab);
  // If the current active menu is not clicked, then jump to this menu
  if (tab.path !== route.path) {
    nextTick(() => {
      router.push({ path: tab.path });
    });
  }
};
const removeRightTab = (tab) => {
  tabMenuState.RemoveRightTab(tab);
  // If the current active menu is not clicked, then jump to this menu
  if (tab.path !== route.path) {
    nextTick(() => {
      router.push({ path: tab.path });
    });
  }
};
const removeLeftTab = (tab) => {
  tabMenuState.RemoveLeftTab(tab);
  // If the current active menu is not clicked, then jump to this menu
  if (tab.path !== route.path) {
    nextTick(() => {
      router.push({ path: tab.path });
    });
  }
};
const removeAllTab = () => {
  tabMenuState.DestroyTabMenu();
  tabMenuState.AddTabMenu();
  nextTick(() => {
    router.push({ path: '/' });
  });
};
</script>

<style lang="scss" scoped>
.tab-label {
  margin: 0 7px;
  white-space: nowrap;
  max-width: 150px;
  overflow: hidden;
  text-overflow: ellipsis;
}

.tab-close {
  display: inline-flex;
  font-size: 1rem;
  border-radius: 0.2rem;
  opacity: 0.5;
  transition: all 0.3s;

  &:hover {
    opacity: 1;
  }
}
</style>
