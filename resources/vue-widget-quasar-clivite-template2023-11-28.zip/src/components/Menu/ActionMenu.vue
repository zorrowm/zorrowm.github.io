<template>
  <div>
    <span v-for="(item, index) in defaultMenus" :key="index" :title="item.name">
      <Icon :icon="item.icon" class="operationIcon" @click="doClick(item)" />
    </span>

    <div v-if="hasAppendMenus">
      <Icon icon="ant-design:ellipsis-outlined" class="operationIcon" />
      <q-menu v-model="showing">
        <q-list style="min-width: 100px">
          <q-item
            v-for="(item, index) in appendMenus"
            :key="index"
            v-close-popup
            clickable
            @click="doClick(item)"
          >
            <q-item-section>
              <Icon :icon="item.icon" class="operationIcon" />
              {{ item.name }}
            </q-item-section>
          </q-item>
        </q-list>
      </q-menu>
    </div>
  </div>
</template>

<script lang="ts">
import { useQuasar } from 'quasar';
import { computed, defineComponent, ref } from 'vue';
import { any,array } from 'vue-types';
export default defineComponent({
  props: {
    defaultMenus: array<any>().def([]),
    appendMenus: array<any>().def([]),
    currentRow: any().def(null),
  },
  setup(props, { emit }) {
    const $q = useQuasar();
    const hasAppendMenus = computed(() => {
      return props.appendMenus.length > 0;
    });
    const doClick = (item: any) => {
      if (item.isdelete || item.value === 'delete') {
        $q.dialog({
          //dark: true,
          title: '删除',
          message: '确认删除该行数据？',
          cancel: true,
        }).onOk(() => {
          emit('doActionClick', item.value, props.currentRow);
        });
      } else emit('doActionClick', item.value, props.currentRow);
    };
    const showing = ref(false);
    return {
      doClick,
      hasAppendMenus,
      showing,
    };
  },
});
</script>

<style scoped lang="scss">
.operationIcon {
  cursor: pointer;
  color: #1890ff !important;
  margin-left: 5px;
}
:deep(.ant-popover-inner) {
  min-width: 140px;
}
</style>
