<template>
  <component
    :is="chooseComponent"
    :true-item="childrenItem"
    :init-level="initLevel"
  >
    <template
      v-if="childrenItem.children && childrenItem.children.length !== 0"
    >
      <SideMenuBarItem
        v-for="item in childrenItem.children"
        :key="item.path"
        :children-item="item"
        :init-level="initLevel + 0.3"
      />
    </template>
  </component>
</template>

<script setup>
import { computed, toRefs } from 'vue';

import ItemMultiple from './ItemMultiple.vue';
import ItemSingle from './ItemSingle.vue';

const props = defineProps({
  childrenItem: {
    default: function () {
      return {};
    },
    type: Object,
  },
  initLevel: {
    type: Number,
    default: 0,
  },
});
const { childrenItem, initLevel } = toRefs(props);

const chooseComponent = computed(() => {
  if (childrenItem.value.children && childrenItem.value.children.length !== 0) {
    return ItemMultiple;
  } else {
    return ItemSingle;
  }
});
</script>
