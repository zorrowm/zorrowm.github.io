<template>
  <q-item
    v-ripple
    clickable
    exact
    :inset-level="initLevel"
    :active="checkActive"
    :active-class="darkThemeSelect"
    @click="toPath(trueItem)"
  >
    <q-item-section avatar>
      <Icon :icon="trueItem.meta?.icon" />
    </q-item-section>
    <q-item-section style="margin-left: -10px">
      {{ trueItem.meta?.title }}
    </q-item-section>
  </q-item>
</template>

<script setup>
import useTheme from 'src/composables/useTheme';
import { computed, toRefs } from 'vue';
import { useRoute,useRouter } from 'vue-router';
import { H5Tool,isValidURL } from 'xframelib';

// const { selectOptionLabel } = useCommon()
const { darkThemeSelect } = useTheme();
const router = useRouter();
const route = useRoute();
const props = defineProps({
  trueItem: {
    default: function () {
      return {};
    },
    type: Object,
  },
  initLevel: {
    type: Number,
    default: 0,
  },
});
const { trueItem, initLevel } = toRefs(props);

const toPath = (item) => {
  // console.log(item,'item222222222222')
  if (item.path&&isValidURL(item.path)||item.link) {
    window.open(item.path);
  } else {
    router.push({ name: item.name });
  }
};

const checkActive = computed(() => {
  //比较名称
  if (route.name === trueItem.value.name) {
    return true;
  } else {
    return false;
  }
});
</script>

<style lang="scss" scoped>
.item-active-class {
  color: $primary;
  background: $primary;
}

.q-item {
  border-radius: 0 32px 32px 0;
}
</style>
