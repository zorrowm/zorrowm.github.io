<template>
  <q-scroll-area
    style="height: calc(100%)"
    :class="darkThemeSideBar[0] === 'class' ? darkThemeSideBar[1] : ''"
    :style="darkThemeSideBar[0] === 'style' ? darkThemeSideBar[1] : {}"
  >
    <slot />
    <q-list class="menu-list">
      <template v-for="(childrenItem, index) in topMenuChildren" :key="index">
        <SideMenuBarItem
          :children-item="childrenItem"
          :init-level="0"
          style="padding-left: "
        />
      </template>
    </q-list>
  </q-scroll-area>
</template>

<script setup>
import useTheme from 'src/composables/useTheme';
import { toRefs } from 'vue';
import { Global } from 'xframelib';

import SideMenuBarItem from './SideMenuBarItem.vue';

const { darkThemeSideBar } = useTheme();
const props = defineProps({
  topMenuChildren: {
    type: Object || Array,
    required: false,
    default: () => {
      return null;
    },
  },
});
const { topMenuChildren } = toRefs(props);
Global.Loading('SideMenuBar');
</script>

<style lang="scss" scoped>
.menu-list :v-deep(.q-item) {
  border-radius: 0 32px 32px 0;
  overflow: hidden;
}
</style>
