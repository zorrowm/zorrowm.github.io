<template>
  <q-scroll-area :thumb-style="thumbStyle">
    <q-list>
      <base-menu-item :my-router="router" />
    </q-list>
  </q-scroll-area>
</template>

<script lang="ts" setup>
import { getRightRoutes } from 'src/permission';
import {computed } from 'vue';

import BaseMenuItem from './BaseMenuItem.vue';

defineOptions({ name: 'BaseMenu' });
const props = defineProps({
  layoutName: {
    type: String,
    required: false,
    default: 'BackLayout',
  },
});
// layoutName:string().def('BackLayout')//布局的路由名
const thumbStyle = {
  right: '1px',
  borderRadius: '5px',
  backgroundColor: '#616161',
  width: '5px',
};

const router = computed(() => {
  const rightRoutes = getRightRoutes(); //getRoutes(bussinessRoutes);
  if (!rightRoutes) return [];
  const layoutRouterName=props.layoutName;
  const resultItems = rightRoutes.find(item => item.name === layoutRouterName)?.children; //routes.find((item) => item.name === "BackLayout")!.children;
      if (resultItems) {
        const lastResult = resultItems.sort((a, b) => {
          let indexA: number = 0;
          let indexB: number = 0;
          if (a.meta && a.meta.index != undefined) {
            indexA = Number(a.meta.index);
          }
          if (b.meta && b.meta.index != undefined) {
            indexB = Number(b.meta.index);
          }
          return indexA - indexB;
        });
        return lastResult;
      } else return resultItems;
});
</script>
