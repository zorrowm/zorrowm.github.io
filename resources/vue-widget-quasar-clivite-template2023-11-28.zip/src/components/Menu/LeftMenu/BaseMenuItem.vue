  <template>
  <div v-for="(item, index) in myRouter" :key="index">
    <div  v-if="item?.meta?.hidden != true" class="base-menu-item">
      <!-- no children  -->
      <q-item
        v-if="item&&!item.children"
        v-ripple
        :exact="item?.path === '/'"
        clickable
        :inset-level="initLevel"
        active-class="baseItemActive"
        :active="$route.fullPath === handleLink(basePath, item?.path)"
        @click="handleMenuClick(basePath, item?.path)"
      >
        <q-item-section avatar :style="getRightPostionStyle">
          <Icon :icon="item?.meta.icon"></Icon>
        </q-item-section>
        <q-item-section>
          {{ item.meta?.title }}
        </q-item-section>
        <q-item-section v-if="handleLink(basePath, item.path) === '#'" side>
          <q-icon name="fa-solid fa-up-right-from-square" size="10px" />
        </q-item-section>
      </q-item>

      <!-- has children -->
      <q-expansion-item
        v-else
        :class="baseItemClassWithNoChildren(item?.path)"
        :duration="duration"
        :default-opened="true"
        :header-inset-level="initLevel"
      >
        <template #header>
          <q-item-section avatar :style="getRightPostionStyle">
            <Icon :icon="item?.meta.icon"></Icon>
          </q-item-section>

          <q-item-section> {{ item?.meta?.title }} </q-item-section>
        </template>
        <!-- MenuItem initlevl + 0.2 ; concat parent path if router is existed -->
        <base-menu-item
           v-if="item&&item.children"
          :my-router="item?.children"
          :init-level="initLevel + 0.2"
          :base-path="basePath === '' ? item.path : basePath + '/' + item.path"
          :duration="duration"
        />
      </q-expansion-item>
    </div>
  </div>
  </template>



<script lang="ts" setup>
import { appStore } from 'src/stores/index';
import { computed } from 'vue';
import { useRoute, useRouter } from 'vue-router';
defineOptions({ name: 'BaseMenuItem' });

interface Props {
  myRouter: any[];
  initLevel?: number;
  duration?: number;
  basePath?: string;
}

withDefaults(defineProps<Props>(), {
  myRouter: () => [],
  initLevel: 0,
  duration: 150,
  basePath: '',
});
const appState = appStore();
const route = useRoute();
const router = useRouter();

const getRightPostionStyle = computed(() => {
  return appState.leftCollapsed ? '' : ''; //margin-left: -16px
});
const baseItemClassWithNoChildren = computed(() => {
  return (path: any) => {
    return route.fullPath.startsWith(path) ? 'baseRootItemActive' : '';
  };
});

const handleLink = (basePath: string, itemPath: string) => {
  const link = basePath === '' ? itemPath : basePath + '/' + itemPath;
  if (link.indexOf('http') !== -1) {
    return '#';
  }
  return link;
};

const handleMenuClick = (basePath: string, itemPath: string) => {
  const link = basePath === '' ? itemPath : basePath + '/' + itemPath;
  const i = link.indexOf('http');
  if (i !== -1) {
    const a = document.createElement('a');
    a.setAttribute('href', link.slice(i));
    a.setAttribute('target', '_blank');
    a.click();
    return false;
  }
  router.push(link);
};
</script>

<style lang="scss" scoped>
// $
.body--light {
  .base-menu-item {
    color: $ITEM_COLOR !important;

    .baseRootItemActive {
      color: $ACTIVE_COLOR !important;
    }

    .baseItemActive {
      color: $ACTIVE_COLOR !important;
      background: $ACTIVE_BACKGROUND;
      transition: all 0.618s;
      font-weight: bold;

      &:after {
        content: '';
        position: absolute;
        width: 3px;
        height: 100%;
        background: $ACTIVE_COLOR !important;
        top: 0;
        right: 0;
      }
    }
  }
}

.body--dark {
  .base-menu-item {
    color: $ITEM_COLOR_DARK !important;

    .baseRootItemActive {
      color: $ACTIVE_COLOR_DARK !important;
    }

    .baseItemActive {
      color: $ACTIVE_COLOR_DARK !important;
      background: $ACTIVE_BACKGROUND_DARK;
      transition: all 0.618s;
      font-weight: bold;

      &:after {
        content: '';
        position: absolute;
        width: 3px;
        height: 100%;
        background: $ACTIVE_COLOR_DARK !important;
        top: 0;
        right: 0;
      }
    }
  }
}
</style>
