import { Cookies,setCssVar, useQuasar } from 'quasar';
import { appStore } from 'src/stores';
import { computed } from 'vue';

interface IThemeStyle {
  primary?: string;
  secondary?: string;
  accent?: string;
  positive?: string;
  negative?: string;
  info?: string;
  warning?: string;
  light?: string;
  dark?: string;
}
export default function useTheme() {
  // Quasar Theme Color
  const ThemeStyleQuasar: IThemeStyle = {
    primary: '#1976D2',
    secondary: '#26A69A',
    accent: '#9C27B0',
    positive: '#21BA45',
    negative: '#C10015',
    info: '#31CCEC',
    warning: '#F2C037',
    light: '#FFFFFF',
    dark: '#1D1D1D',
  };
  // Element Theme Color
  const ThemeStyleElement: IThemeStyle = {
    primary: '#409EFF',
    secondary: '#26A69A',
    accent: '#9C27B0',
    positive: '#67C23A',
    negative: '#F56C6C',
    info: '#8896b3',
    warning: '#e6a23c',
    light: '#FFFFFF',
    dark: '#1D1D1D',
  };
  // Ant Design Theme Color
  const ThemeStyleAnt: IThemeStyle = {
    primary: '#1890ff',
    secondary: '#26A69A',
    accent: '#9C27B0',
    positive: '#52c41a',
    negative: '#f5222d',
    info: '#fafafa',
    warning: '#faad14',
    light: '#FFFFFF',
    dark: '#1D1D1D',
  };

  const themeStyleList = {
    'Quasar-Admin': ThemeStyleQuasar,
    Quasar: ThemeStyleQuasar,
    'Element Plus': ThemeStyleElement,
    'Ant Design Vue': ThemeStyleAnt,
  };

  const $q = useQuasar();
  const appState = appStore();

  const setThemeStyle = (themeName: string) => {
    const themeStyleObject: IThemeStyle = themeStyleList[themeName];
    for (const q in themeStyleObject) {
      setBrand(q, themeStyleObject[q]);
    }
    //存储
    appState.SetThemeStyle(themeName);
  };

  const setBrand = (type, color) => {
    Cookies.set('default-theme-' + type, color);
    setCssVar(type, color);
  };

  const themeStyle = computed(() => appState.GetThemeStyle());

  // eslint-disable-next-line vue/return-in-computed-property
  const darkTheme = computed(() => {
    if ($q.dark.isActive) {
      return 'bg-dark text-white';
    } else {
      if (themeStyle.value === 'Quasar-Admin') {
        return 'bg-grey-10 text-white';
      }
      if (themeStyle.value === 'Quasar') {
        return 'bg-primary text-white';
      }
      if (themeStyle.value === 'Element Plus') {
        return 'bg-primary text-white';
      }
      if (themeStyle.value === 'Ant Design Vue') {
        return 'bg-primary text-white';
      }
    }
  });
  // eslint-disable-next-line vue/return-in-computed-property
  const darkThemeLoginHelp = computed(() => {
    if ($q.dark.isActive) {
      return 'bg-dark text-white';
    } else {
      if (themeStyle.value === 'Quasar-Admin') {
        return 'text-dark';
      }
      if (themeStyle.value === 'Quasar') {
        return 'bg-primary text-white';
      }
      if (themeStyle.value === 'Element Plus') {
        return 'bg-primary text-white';
      }
      if (themeStyle.value === 'Ant Design Vue') {
        return 'bg-primary text-white';
      }
    }
  });
  // eslint-disable-next-line vue/return-in-computed-property
  const darkThemeLoginCard = computed(() => {
    if ($q.dark.isActive) {
      return 'bg-dark text-white';
    } else {
      if (themeStyle.value === 'Quasar-Admin') {
        return 'bg-white text-dark';
      }
      if (themeStyle.value === 'Quasar') {
        return 'bg-primary text-white';
      }
      if (themeStyle.value === 'Element Plus') {
        return 'bg-primary text-white';
      }
      if (themeStyle.value === 'Ant Design Vue') {
        return 'bg-primary text-white';
      }
    }
  });
  // eslint-disable-next-line vue/return-in-computed-property
  const darkThemeTab = computed(() => {
    if ($q.dark.isActive) {
      return 'bg-dark text-white';
    } else {
      if (themeStyle.value === 'Quasar-Admin') {
        return 'bg-white text-dark';
      }
      if (themeStyle.value === 'Quasar') {
        return 'bg-white text-primary';
      }
      if (themeStyle.value === 'Element Plus') {
        return 'bg-white text-primary';
      }
      if (themeStyle.value === 'Ant Design Vue') {
        return 'bg-white text-primary';
      }
    }
  });
  // eslint-disable-next-line vue/return-in-computed-property
  const darkThemeSideBar = computed(() => {
    if ($q.dark.isActive) {
      return ['class', 'bg-grey-10 text-white'];
    } else {
      if (themeStyle.value === 'Quasar-Admin') {
        return ['class', 'bg-grey-3 text-grey-10'];
      }
      if (themeStyle.value === 'Quasar') {
        return ['class', 'bg-white text-dark'];
      }
      if (themeStyle.value === 'Element Plus') {
        return ['style', { backgroundColor: '#545c64', color: 'white' }];
      }
      if (themeStyle.value === 'Ant Design Vue') {
        return ['style', { backgroundColor: '#001529', color: 'white' }];
      }
    }
  });
  // eslint-disable-next-line vue/return-in-computed-property
  const darkThemeSelect = computed(() => {
    if ($q.dark.isActive) {
      return 'bg-grey-10 text-white';
    } else {
      if (themeStyle.value === 'Quasar-Admin') {
        return 'bg-grey-5 text-grey-10';
      }
      if (themeStyle.value === 'Quasar') {
        return 'bg-primary text-white';
      }
      if (themeStyle.value === 'Element Plus') {
        return 'bg-#545c64 text-yellow';
      }
      if (themeStyle.value === 'Ant Design Vue') {
        return 'bg-primary text-white';
      }
    }
  });
  const darkThemeChart = computed(() => {
    if ($q.dark.isActive) {
      return 'dark';
    } else {
      return '';
    }
  });

  return {
    setThemeStyle,
    ThemeStyleQuasar,
    ThemeStyleElement,
    ThemeStyleAnt,
    darkTheme,
    darkThemeLoginHelp,
    darkThemeLoginCard,
    darkThemeTab,
    darkThemeSideBar,
    darkThemeSelect,
    darkThemeChart,
  };
}
