import { boot } from 'quasar/wrappers';
import { setupGlobDirectives } from 'src/directives/index';

export default boot(async ({ app }) => {
  setupGlobDirectives(app);
});
