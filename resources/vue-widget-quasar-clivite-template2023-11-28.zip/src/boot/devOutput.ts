import { boot } from 'quasar/wrappers';
import { getSystemPKG } from 'src/utils/sysTool';
// import { bussinessRoutes } from 'src/router';
// import functionList from 'src/settings/functionSetting';
// import widgetMenuConfig from 'src/settings/widgetMenuSetting';
// import widgetConfig from 'src/settings/widgetSetting';
import fs from 'vite-plugin-fs/browser';
import { exportSystemRights, ISysRightOptions } from 'xframelib';

export default boot(async () => {
  //如果是开发环境下，执行
  if (import.meta.env.DEV) {
    // Global.Logger().info('开发环境中……');
    const bRoutes = []; // [...bussinessRoutes];
    // translateTitle(bRoutes);
    const options: ISysRightOptions = {
      // bussinessRoutes: bRoutes,
      // widgetConfig,
      // functionList,
      // widgetMenuConfig,
      pkgObject: getSystemPKG(),
    };
    const data = exportSystemRights(options);
    fs.writeFile('public/MenuRoutes.json', JSON.stringify(data));
  }
});
