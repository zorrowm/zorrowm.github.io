/*
 * @Author: zorrowm zorrowm@126.com
 * @Date: 2023-05-08 09:04:28
 * @LastEditors: zorrowm zorrowm@126.com
 * @LastEditTime: 2023-05-19 14:15:44
 * @FilePath: \Feido三维开发模板\src\boot\initXframe.ts
 * @Description:
 *
 * Copyright (c) 2023 by zorrowm , All Rights Reserved.
 */
import { addAPIProvider, Icon } from '@iconify/vue';
import { createPinia } from 'pinia';
import { boot } from 'quasar/wrappers';
import { EmitLoadingInfo } from 'src/events/index';
import { message } from 'src/utils/MessageNotify';
//封装的消息提示
import { getSystemID, getSystemPKG } from 'src/utils/sysTool';
import { Global, init } from 'xframelib';
//floating-vue 用于浮动tooltip  https://floating-vue.starpad.dev/guide/installation
// import {Dropdown,Tooltip,Menu} from 'floating-vue'

function preInit() {
  if (window.global === undefined) {
    window.global = globalThis;
  }
  //系统ID,唯一标识
  const sysID = getSystemID();
  //分组名，工程名
  const sysGroup = getSystemPKG().name;
  init(message, sysID, sysGroup);
  //挂载进度通知方法
  Global.Loading = EmitLoadingInfo;
  //注册自己的IconAPIProvider
  if (Global.Config.ServiceURL.IconServiceURL)
    addAPIProvider('', {
      resources: [Global.Config.ServiceURL.IconServiceURL],
    });
  else {
    //离线使用图标：生效，IconServiceURL配置为空
    import('../components/IconOffline').then((it) => {
      it.default();
    });
  }
}

export default boot(({ app }) => {
  EmitLoadingInfo('XFramelib库');
  //初始化Xframelib
  preInit();
  // 创建pinia 实例
  const pinia = createPinia();
  // 挂载到 Vue 根实例上
  app.use(pinia);
  //注册全局组件
  app.component('Icon', Icon);
  // app.component('VDropdown', Dropdown);
  // app.component('VTooltip', Tooltip);
  // app.component('VMenu', Menu);

  //开发时,全局注册tiny组件
  if (import.meta.env.DEV) {
    // import('@opentiny/vue').then((it) => {
    //   const TinyVue = it.default;
    //   app.use(TinyVue);
    // });
  }
});
