import { date } from 'quasar';
import { RouteData } from 'src/models/index';
import { Router, RouteRecordRaw } from 'vue-router';
import { H5Tool } from 'xframelib';

import pkg from '../../package.json';

const { name, version } = pkg;
export const __APP_INFO__ = {
  pkg: { name, version },
  lastBuildTime: date.formatDate('YYYY-MM-DD HH:mm:ss'),
};
/**
 * 获取当前系统的ID
 * （从package获取）
 * @returns
 */
export function getSystemID(): string {
  const { pkg } = __APP_INFO__;
  const sysinfo = `${pkg.name}_${pkg.version}`;
  const systemID = H5Tool.MD5(sysinfo);
  return systemID;
}

export function getSystemPKG() {
  const { pkg } = __APP_INFO__;
  return pkg;
}

/**
 * 用于路由，获取完整的相对路由
 * @param childPath
 * @param path
 * @returns
 */
export function getRouteURL(childPath: string, path = '/') {
  if (!childPath) return undefined;
  if (childPath.startsWith('/')) {
    if (childPath.startsWith(path)) return childPath;
    else return `${path}${childPath}`;
  } else {
    if (path === '/') return `${path}${childPath}`;
    else return `${path}/${childPath}`;
  }
}
/**
 * 检查是否存在默认‘/’路由，并添加
 * @param router 路由
 * @param firstItem 默认权限的第一个
 */
export function checkAddDefaultRoute(
  router: Router,
  firstItem: RouteRecordRaw
) {
  const routes = router.getRoutes();
  const defaultPath = routes.find((p) => p.path === '/');
  if (!defaultPath) {
    router.addRoute({
      name: '/',
      path: '/',
      redirect: firstItem.path,
    });
  }
}

export function recursiveRoutes(
  components: Record<string, unknown>
): Array<RouteRecordRaw> {
  const menuCofig: Array<RouteRecordRaw> = [];
  let tmpMenuArray: Array<RouteRecordRaw> = [];
  // const components = import.meta.glob('./*.ts', { eager: true });
  Object.keys(components).forEach((path) => {
    const comp = components[path] as any;
    if (comp.default) tmpMenuArray.push(...comp.default);
  });
  tmpMenuArray = tmpMenuArray.sort((a, b) => {
    let indexA: number = 0;
    let indexB: number = 0;
    if (a.meta) {
      if (a.meta.index != undefined) indexA = Number(a.meta.index);
      else indexA = 100;
    }
    if (b.meta) {
      if (b.meta.index != undefined) indexB = Number(b.meta.index);
      else indexB = 100;
    }
    return indexA - indexB;
  });
  menuCofig.push(...tmpMenuArray);
  tmpMenuArray.length = 0;
  return menuCofig;
}

/**
 * 递归过滤其他的对象
 * @param components
 * @param orderIndex 是否需要排序
 * @returns
 */
export function globFilterObjects<T>(
  components: Record<string, unknown>,
  orderIndex: boolean = false
): Array<T> {
  const menuCofig: Array<T> = [];
  let tmpMenuArray: Array<T> = [];

  // const components = import.meta.glob('./*.ts', { eager: true });
  Object.keys(components).forEach((path) => {
    const comp = components[path] as any;
    if (comp.default) tmpMenuArray.push(...comp.default);
  });
  if (orderIndex) {
    tmpMenuArray = tmpMenuArray.sort((a, b) => {
      let indexA = 0;
      let indexB = 0;
      if (a.index != undefined) {
        indexA = Number(a.index);
      }
      if (b.index != undefined) {
        indexB = Number(b.index);
      }
      return indexA - indexB;
    });
  }

  menuCofig.push(...tmpMenuArray);
  tmpMenuArray.length = 0;
  return menuCofig;
}

/**
 * 根据路由路由配置记录，获取RouteData
 * @param configRouteItem 路由配置记录
 * @param startPath 起始路径
 * @returns
 */
export function getTabRouteData(
  configRouteItem: RouteRecordRaw,
  startPath: string = '/'
): RouteData {
  let fullPath = startPath;
  if (configRouteItem.redirect && configRouteItem.children) {
    if (!configRouteItem.path.startsWith(startPath)) {
      fullPath = startPath + configRouteItem.path;
    }
    else
    fullPath =configRouteItem.path;//修改BUG
    const firstChild = configRouteItem.children[0];
    return getTabRouteData(firstChild, fullPath);
  }
  if (!configRouteItem.path.startsWith(startPath)) {
    fullPath = `${startPath}/${configRouteItem.path}`;
  }
  else
    fullPath = configRouteItem.path;
  const resultData: RouteData = {
    title: configRouteItem.meta?.title as string,
    fullPath: fullPath,
    path: configRouteItem.path,
    icon: configRouteItem.meta?.icon as string,
    keepAlive: configRouteItem.meta?.keepAlive as boolean,
    name: configRouteItem.name,
  };
  return resultData;
}
