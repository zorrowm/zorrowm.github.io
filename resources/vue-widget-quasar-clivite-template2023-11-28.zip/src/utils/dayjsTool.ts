import { date } from 'quasar';

const DATE_TIME_FORMAT = 'YYYY-MM-DD HH:mm:ss';
const DATE_FORMAT = 'YYYY-MM-DD';

export function formatToDateTime(
  dateValue?: Date | number | string | undefined,
  format = DATE_TIME_FORMAT
): string {
  return date.formatDate(dateValue, format);
}

export function formatToDate(
  dateValue?: Date | number | string | undefined,
  format = DATE_FORMAT
): string {
  return date.formatDate(dateValue, format);
}

export const dayjsTool = date;
