<template>
  <ScrollSnapContainer :height="containerHeight">
    <VideoPanel v-wow="{ 'animation-name': 'slideInDown' }"> </VideoPanel>
    <CarouselPanel
      v-wow="{ 'animation-name': 'slideInLeft', 'animation-duration': '2s' }"
    >
    </CarouselPanel>
    <TabsPanel
      v-wow="{ 'animation-name': 'slideInRight', 'animation-duration': '2s' }"
    >
    </TabsPanel>
    <section
      v-wow="{ 'animation-name': 'slideInUp' }"
      class="scrollSection"
      style="background-color: #f00;  height: 400px;  width: 100%"
    ></section>
    <section
v-wow="{ 'animation-name': 'slideInLeft' }"
      class="scrollSection"
      style="background-color: #0f0; height: 400px; width: 100%"
    ></section>
    <section
v-wow="{ 'animation-name': 'slideInUp' }"
      class="scrollSection"
      style="background-color: #00f; height: 200px; width: 100%"
    ></section>
  </ScrollSnapContainer>
</template>

<script setup lang="ts">
import ScrollSnapContainer from 'components/ScrollSnapContainer/index.vue';
import LayoutTool from 'src/utils/layoutTool';
import { computed } from 'vue';

import CarouselPanel from './CarouselPanel.vue';
import TabsPanel from './TabsPanel.vue';
import VideoPanel from './VideoPanel.vue';
const containerHeight = computed(() => {
  return  document.body.clientHeight;//LayoutTool.getContentHeight();
});
// const sectionArray = [
//   // ()=>import('./VideoPanel.vue'),
//   () => import('./CarouselPanel.vue'),
//   () => import('./TabsPanel.vue'),
//   () => import('./MultigridEchartPanel.vue'),
// ];
</script>
