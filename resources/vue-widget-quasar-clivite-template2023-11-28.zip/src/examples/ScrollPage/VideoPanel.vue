<template>
  <section class="scrollSection">
    <div class="videoPanel" >
    <video class="video" loop="" muted="" autoplay src="/examples/57b1c10d-26b2-48e6-ba6f-703df6a01efd.mp4" poster="/examples/AA12PMfr.img" style="height:100%;width:100%; object-fit: cover;"></video>
    <div class="absolute-center vertical-middle">
        <!-- <div :class="$q.screen.lt.md?'text-h4':'text-h2'">时空影像云平台</div> -->
        <div v-media="'text-h2.gt.lg text-h4.md text-h6.sm test.sm'">时空影像云平台</div>
        <div class="text-subtitle1">高效的影像不切片服务快速发布平台，支持百PB级遥感卫星影像数据 极速分发、在线处理、实时更新、智能应用</div>
    </div>
    </div>
    <div class="q-px-md">
      <q-card square flat class="q-gutter-y-md q-mt-md">
        <div class="row justify-center">
          <q-card-section class="col-sm col-xs-12">
            <q-item-label class="text-body text-grey-6 text-center q-mb-sm"
            >我的待办
            </q-item-label>
            <q-item-label class="text-h5 text-center">{{ summaryData.waitDealTask }}个任务</q-item-label>
          </q-card-section>
          <q-separator vertical />
          <q-card-section class="col-sm col-xs-12">
            <q-item-label class="text-body text-grey-6 text-center q-mb-sm"
            >本周任务平均处理时间
            </q-item-label>
            <q-item-label class="text-h5 text-center">{{ summaryData.weekDealDuration }}分钟</q-item-label>
          </q-card-section>
          <q-separator vertical />
          <q-card-section class="col-sm col-xs-12">
            <q-item-label class="text-body text-grey-6 text-center q-mb-sm"
            >本周完成任务数
            </q-item-label>
            <q-item-label class="text-h5 text-center">{{summaryData.completeTask }}个任务</q-item-label>
          </q-card-section>
        </div>
      </q-card>
    </div>
  </section>

</template>

<script setup lang="ts">
import {ref} from 'vue';
 const summaryData =ref({
  waitDealTask: 8,
  weekDealDuration: 32,
  completeTask: 23
})
</script>

<style scoped>
.videoPanel
{
 position: relative;
 height:75%;
}
.test
{
  color:#f00;
}
</style>
