<template>
  <section class="scrollSection">
    <q-carousel
      v-model="slide"
      :autoplay="true"
      animated
      arrows
      navigation
      infinite
      style="height: 50%"
    >
      <q-carousel-slide
        :name="1"
        img-src="https://cdn.quasar.dev/img/mountains.jpg"
      />
      <q-carousel-slide
        :name="2"
        img-src="https://cdn.quasar.dev/img/parallax1.jpg"
      />
      <q-carousel-slide
        :name="3"
        img-src="https://cdn.quasar.dev/img/parallax2.jpg"
      />
      <q-carousel-slide
        :name="4"
        img-src="https://cdn.quasar.dev/img/quasar.jpg"
      />
    </q-carousel>
    <q-splitter   v-model="splitterModel" horizontal style="height: 40%">
      <template #before>
        <div
          class="q-pa-md q-mx-auto"
          style="
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
          "
        >
          <div class="text-h4 q-mb-md">产品优势</div>
          <div class="text-h6 q-ma-auto">
            百PB级遥感卫星影像数据 极速分发、在线处理、实时更新、智能应用
          </div>
        </div>
      </template>

      <template #after>
        <div class="q-pa-md q-gutter-md">
          <ul class="specialList text-h7">
            <li>
              <div class="spItem">
                <img src="/img/logo.png" width="32" alt="" srcset="" />
                <span>海量影像高效管理 / 快速发布</span>
              </div>
            </li>
            <li>
              <div class="spItem">
                <img src="/img/logo.png" width="32" alt="" srcset="" />
                <span>影像数据快捷应用与分析</span>
              </div>
            </li>
            <li>
              <div class="spItem">
                <img src="/img/logo.png" width="32" alt="" srcset="" />
                <span>快速构建业务应用系统</span>
              </div>
            </li>
            <li>
              <div class="spItem">
                <img src="/img/logo.png" width="32" alt="" srcset="" />
                <span>高可用 PaaS 级云平台</span>
              </div>
            </li>
          </ul>
        </div>
      </template>
    </q-splitter>
  </section>
</template>

<script>
import { ref } from 'vue';

export default {
  setup() {
    return {
      slide: ref(1),
      splitterModel: ref(55)
    };
  },
};
</script>
<style scoped>
.specialList {
  width: 100%;
  display: flex;
  justify-content: center;
  align-content: space-around;
}
.spItem {
  width: 250px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
</style>
