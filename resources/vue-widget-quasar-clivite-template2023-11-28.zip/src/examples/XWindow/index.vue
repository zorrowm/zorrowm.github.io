<template>

  <XWidgetWindow ref="xwidgetWindowRef" title="图层管理" :pid="widgetID" @loaded="onLoaded" @close="onClosed">
   <span style="font-size: 20px;">图层管理树</span>
  </XWidgetWindow>
  </template>

  <script setup lang="ts">
  import { IPanelData, XWindow as XWidgetWindow } from 'src/components/XWindow';
  import { defineProps, ref } from 'vue';
  const widgetID='layerTreeWidget';
  const xwidgetWindowRef=ref();

  function onClosed(panelData:IPanelData)
  {
    console.log('初始化完成',panelData);
    setTimeout(() => {
      if(xwidgetWindowRef.value)
      {
         xwidgetWindowRef.value.open();
         console.log('重新打开窗体')
      }

    }, 3000);
  }
  function onLoaded(panelData:IPanelData)
  {
    console.log('初始化完成',panelData);

  }
  </script>

  <style lang="scss" scoped>

  </style>
