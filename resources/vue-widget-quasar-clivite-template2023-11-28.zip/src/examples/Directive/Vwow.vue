<template>
  <div :style="{ overflow: 'auto', height: containerHeight + 'px' }">
    <VideoPanel v-wow="{ 'animation-name': 'slideInDown' }"> </VideoPanel>
    <div
      v-wow="{ 'animation-name': 'slideInUp' }"
      style="background-color: #f00; height: 400px; width: 100%"
    ></div>
    <div
      v-wow="{ 'animation-name': 'slideInLeft' }"
      style="background-color: #0f0; height: 400px; width: 100%"
    ></div>
    <div
      v-wow="{ 'animation-name': 'slideInUp' }"
      style="background-color: #00f; height: 400px; width: 100%"
    ></div>
    <CarouselPanel
      v-wow="{ 'animation-name': 'slideInLeft', 'animation-duration': '2s' }"
    >
    </CarouselPanel>
    <VideoPanel
      v-wow="{ 'animation-name': 'slideInRight', 'animation-duration': '2s' }"
    >
    </VideoPanel>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';

import CarouselPanel from '../ScrollPage/CarouselPanel.vue';
import VideoPanel from '../ScrollPage/VideoPanel.vue';
const containerHeight = computed(() => {
  return document.body.clientHeight;//LayoutTool.getContentHeight();
});
</script>
