<template>
 <div v-media="'text-h2.gt.lg text-h4.md text-h6.sm test.sm'">时空影像云平台</div>
</template>

<script setup lang="ts">

</script>

<style scoped>
.test
{
  color:#f00;
}
</style>
