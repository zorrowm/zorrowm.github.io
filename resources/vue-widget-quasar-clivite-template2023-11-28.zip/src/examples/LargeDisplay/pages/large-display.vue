<template>
  <div>
    <div class="dataScreen-container">
      <div ref="dataScreenRef" class="dataScreen">
        <div class="dataScreen-header">
          <div class="header-lf">
            <span class="header-screening" @click="toHome">Home</span>
          </div>
          <div class="header-ct">
            <div class="header-ct-title">
              <span>Visualization data display platform</span>
              <div class="header-ct-warning">
                Platform peak warning information (2 items)
              </div>
            </div>
          </div>
          <div class="header-rg">
            <span class="header-download">Reports</span>
            <span class="header-time">Current time: {{ time }}</span>
          </div>
        </div>
        <div class="dataScreen-main">
          <div class="dataScreen-lf">
            <div class="dataScreen-top">
              <div class="dataScreen-main-title">
                <span>Real-time visitor</span>
                <img src="./images/dataScreen-title.png" alt="" />
              </div>
              <!-- chart区域 -->
              <div class="dataScreen-main-chart">
                <RealTimeAccessChart ref="RealTimeAccessRef" />
              </div>
            </div>
            <div class="dataScreen-center">
              <div class="dataScreen-main-title">
                <span>Male to female ratio</span>
                <img src="./images/dataScreen-title.png" alt="" />
              </div>
              <!-- chart区域 -->
              <div class="dataScreen-main-chart">
                <MaleFemaleRatioChart ref="MaleFemaleRatioRef" />
              </div>
            </div>
            <div class="dataScreen-bottom">
              <div class="dataScreen-main-title">
                <span>Age Ratio</span>
                <img src="./images/dataScreen-title.png" alt="" />
              </div>
              <!-- chart区域 -->
              <div class="dataScreen-main-chart">
                <AgeRatioChart ref="AgeRatioRef" />
              </div>
            </div>
          </div>
          <div class="dataScreen-ct">
            <div class="dataScreen-map">
              <div class="dataScreen-map-title">passenger flow</div>
              <ChinaMapChart ref="MapchartRef" />
            </div>
            <div class="dataScreen-cb">
              <div class="dataScreen-main-title">
                <span>Visitor volume trend chart for the next 30 days</span>
                <img src="./images/dataScreen-title.png" alt="" />
              </div>
              <!-- chart区域 -->
              <div class="dataScreen-main-chart">
                <OverNext30Chart ref="OverNext30Ref" />
              </div>
            </div>
          </div>
          <div class="dataScreen-rg">
            <div class="dataScreen-top">
              <div class="dataScreen-main-title">
                <span>Popular scenic spots ranking</span>
                <img src="./images/dataScreen-title.png" alt="" />
              </div>
              <!-- chart区域 -->
              <div class="dataScreen-main-chart">
                <HotPlateChart ref="HotPlateRef" />
              </div>
            </div>
            <div class="dataScreen-center">
              <div class="dataScreen-main-title">
                <span>Annual Visitor Volume Comparison</span>
                <img src="./images/dataScreen-title.png" alt="" />
              </div>
              <!-- chart区域 -->
              <div class="dataScreen-main-chart">
                <AnnualUseChart ref="AnnualUseRef" />
              </div>
            </div>
            <div class="dataScreen-bottom">
              <div class="dataScreen-main-title">
                <span>Reservation Channel Statistics</span>
                <img src="./images/dataScreen-title.png" alt="" />
              </div>
              <!-- chart区域 -->
              <div class="dataScreen-main-chart">
                <PlatformSourceChart ref="PlatformSourceRef" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ECharts } from 'echarts';
import { onBeforeUnmount, onMounted, ref } from 'vue';

import { useTime } from '../utils/tools';
import AgeRatioChart from './components/ageRatioChart.vue';
import AnnualUseChart from './components/annualUseChart.vue';
import ChinaMapChart from './components/chinaMapChart.vue';
import HotPlateChart from './components/hotPlateChart.vue';
import MaleFemaleRatioChart from './components/maleFemaleRatioChart.vue';
import OverNext30Chart from './components/overNext30Chart.vue';
import PlatformSourceChart from './components/platformSourceChart.vue';
import RealTimeAccessChart from './components/realTimeAccessChart.vue';

defineOptions({name:'largeDisplayComponent'})

// 获取当前时间
const dataScreenRef=ref(null);
let timer: NodeJS.Timer | null = null;
let time = useTime().nowTime;

function toHome() {
    location.href = `${location.origin}#/dashboard`;
  }
  // 根据浏览器大小推断缩放比例
function  getScale(width = 1920, height = 1080) {
    let ww = window.innerWidth / width;
    let wh = window.innerHeight / height;
    return ww < wh ? ww : wh;
  }
function  resize() {
    if (dataScreenRef.value) {
      dataScreenRef.value.style.transform = `scale(${getScale()}) translate(-50%, -50%)`;
    }
    // 使用了 scale 的echarts其实不需要需要重新计算缩放比例
    // Object.values(dataScreen).forEach((chart) => {
    //   chart && chart.resize();
    // });
  }
  onMounted(()=>{
// 初始化时为外层盒子加上缩放属性，防止刷新界面时就已经缩放
if (dataScreenRef.value) {
      dataScreenRef.value.style.transform = `scale(${getScale()}) translate(-50%, -50%)`;
      dataScreenRef.value.style.width = '1920px';
      dataScreenRef.value.style.height = '1080px';
    }

    timer = setInterval(() => {
      time = useTime().nowTime;
    }, 1000);
    // 为浏览器绑定事件
    window.addEventListener('resize', resize);
  })

  onBeforeUnmount(()=>{
    window.removeEventListener('resize', resize);
    clearInterval(timer!);
  })

</script>

<style lang="scss" scoped>
@import './styles/large-display.scss';
</style>
