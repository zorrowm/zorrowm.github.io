<template>
  <ScaleContainer>
    <LayoutContainer
      :widgetConfig="configRef"
      :layoutID="layoutIDRef"
      @containerLoaded="loadedHandler"
    />
  </ScaleContainer>
</template>

<script lang="ts" setup>
import ScaleContainer from 'components/ScaleContainer/index.vue';
import { getRightWidgetConfig } from 'src/permission';
import { appStore } from 'src/stores';
import { onMounted, ref } from 'vue';
import { Global, H5Tool,LayoutContainer } from 'xframelib';

defineOptions({ name: 'portalLayout' });
const widgetCofig = getRightWidgetConfig();
const configRef = ref(widgetCofig);
const layoutIDRef = ref('portalLayout');
//获取服务此Layout的layoutManager
function loadedHandler(evt: any) {
  if (evt.layoutID === layoutIDRef.value) {
    Global.Logger().debug(evt, 'loadedHandler');
    //服务Cesium大屏的
    if (!Global.LayoutMap) {
      Global.LayoutMap = new Map<string, any>();
    }
    Global.LayoutMap.set(evt.layoutID, evt.layoutManager);
  }
}
const appState = appStore();
onMounted(() => {
  Global.Loading('end');
  //是否显示头部栏
  const isShowHeader = appState.headerSetting.show;
  const topheight = isShowHeader ? appState.headerSetting.height : 0;
  H5Tool.setCssVar('--header-top-height', topheight + 'px');
});
</script>

<style lang="scss" scoped>
:deep(.mainContainer) {
  top: var(--header-top-height);
  //  background-color: var(--main-bg-color);
  // height:100%;
  width: unset;
  right: 0px;
  pointer-events: auto;
}

:deep(.topContainer) {
  height: var(--header-top-height);
  border-bottom: solid 2px #eee;
  pointer-events: auto;
}

.rightContainer {
  overflow: hidden;
}

.centerdiv {
  overflow: hidden;
}
</style>
