<template>
  <div class="dc-container">
    <LayoutContainer
      :widgetConfig="configRef"
      :layoutID="layoutIDRef"
      @containerLoaded="loadedHandler"
    />
  </div>
</template>

<script lang="ts">
import { getRightWidgetConfig } from 'src/permission';
import { appStore } from 'src/stores';
import { defineComponent, onMounted, ref } from 'vue';
import { Global, H5Tool,LayoutContainer } from 'xframelib';

export default defineComponent({
  name: 'bigScreenLayout',
  components: {
    LayoutContainer,
  },
  setup(props, { attrs, slots, emit }) {
    const widgetCofig = getRightWidgetConfig();
    const configRef = ref(widgetCofig);
    const layoutIDRef = ref('bigScreenLayout');
    //获取服务此Layout的layoutManager
    function loadedHandler(evt: any) {
      if (evt.layoutID === layoutIDRef.value) {
        //Global.Logger().debug(evt, 'loadedHandler');
        //服务Cesium大屏的
        if (!Global.LayoutMap) {
          Global.LayoutMap = new Map<string, any>();
        }
        Global.LayoutMap.set(evt.layoutID, evt.layoutManager);
      }
    }
    const appState = appStore();
    onMounted(() => {
      Global.Loading('end');
      //是否显示头部栏
      const isShowHeader = appState.headerSetting.show;
      const topheight = isShowHeader ? appState.headerSetting.height : 0;
      H5Tool.setCssVar('--header-top-height', topheight + 'px');
    });

    return {
      configRef,
      layoutIDRef,
      loadedHandler,
    };
  },
});
</script>

<style lang="scss" scoped>
:deep(.mainContainer) {
  top: var(--header-top-height);
}

:deep(.topContainer) {
  height: var(--header-top-height);
  border-bottom: solid 1px #eee;
  pointer-events: auto;
}

:deep(.backContainer)
{
  top: var(--header-top-height);
  bottom:0;
  // height:calc(100vh - 1px);
  pointer-events: auto;
}
</style>
