<template>
  <LayoutContainer
    :widgetConfig="configRef"
    :layoutID="layoutIDRef"
    @containerLoaded="loadedHandler"
  />
</template>

<script lang="ts">
import { getRightWidgetConfig } from 'src/permission';
import { defineComponent, onMounted,ref } from 'vue';
import { Global, LayoutContainer } from 'xframelib';

export default defineComponent({
  name: 'mainLayout',
  components: {
    LayoutContainer,
  },
  setup() {
    const widgetCofig = getRightWidgetConfig();
    const configRef = ref(widgetCofig);
    const layoutIDRef = ref('defaultLayout');
    //获取服务此Layout的layoutManager
    function loadedHandler(evt: any) {
      if (evt.layoutID === layoutIDRef.value) {
        Global.Logger().debug(evt, 'loadedHandler');
        //服务Cesium大屏的
        if (!Global.LayoutMap) {
          Global.LayoutMap = new Map<string, any>();
        }
        Global.LayoutMap.set(evt.layoutID, evt.layoutManager);
      }
    }
    onMounted(() => {
      Global.Loading('end');
    });
    return {
      configRef,
      layoutIDRef,
      loadedHandler,
    };
  },
});
</script>

<style lang="scss">
.rightContainer {
  overflow: hidden;
}

.centerdiv {
  overflow: hidden;
}
</style>
