<template>
  <q-layout view="HHh lpR lff" class="full-height" style="overflow-x: hidden">
    <q-header
      class="q-py-xs header"
      height-hint="48"
      bordered
      style="box-shadow: rgba(0, 0, 0, 0) 0px 2px 12px 0px; padding-bottom: 2px"
    >
      <q-toolbar style="margin-top: -5px">
        <div class="q-pr-md">
          <q-btn
            flat
            dense
            round
            aria-label="Menu"
            :icon="getRightIcon"
            @click="toggleLeftDrawer()"
          />
          <toolbar-title />
        </div>
        <!-- breadcrumbs-->
        <breadcrumbs v-if="$q.screen.gt.sm" :show-icon="false" />
        <q-space />
        <toolbar-item />
      </q-toolbar>

      <!-- breadcrumbs-->
      <breadcrumbs v-if="$q.screen.gt.sm" :show-icon="false" />
    </q-header>

    <!-- drawer start -->
    <q-drawer
      v-model="leftDrawerOpen"
      :width="230"
      show-if-above
      :mini-to-overlay="appState.leftCollapsed"
      :mini="appState.leftCollapsed && !isOverlay"
      bordered
      @mouseover="onmouseover"
      @mouseout="onmouseout"
    >
      <SideMenuBar :top-menu-children="topMenuChildren"> </SideMenuBar>
    </q-drawer>
    <!-- drawer end -->

    <!-- page start -->
    <q-page-container
      class="dc-page-container full-height"
      style="overflow: hidden"
    >
      <!-- 视图切换 -->
      <router-transition />
      <q-page-sticky expand position="top">
        <TabMenu style="border-bottom: 1px solid #e0e0e0" />
      </q-page-sticky>

      <q-page-sticky position="bottom-right" :offset="fabPos">
        <q-page-scroller
          position="bottom-right"
          :scroll-offset="150"
          :offset="[0, -70]"
        >
          <q-btn
            v-touch-pan.prevent.mouse="moveFab"
            dense
            glossy
            rounded
            icon="keyboard_arrow_up"
          />
        </q-page-scroller>
      </q-page-sticky>
      <PageFooter />
    </q-page-container>
    <!-- page end -->
  </q-layout>
</template>

<script lang="ts" setup>
import SideMenuBar from 'components/Menu/SideMenuBar/index.vue';
import TabMenu from 'components/Menu/TabMenu.vue';
import PageFooter from 'components/PageFooter.vue';
import Breadcrumbs from 'components/Quasar/Breadcrumbs.vue';
import ToolbarItem from 'components/Quasar/Toolbar/ToolbarItem.vue';
import ToolbarTitle from 'components/Quasar/Toolbar/ToolbarTitle.vue';
import RouterTransition from 'components/RouterTransition/index.vue';
import { getRightRoutes } from 'src/permission';
import { appStore } from 'src/stores';
import { onMounted,ref } from 'vue';
import { computed } from 'vue';
import { Global } from 'xframelib';

defineOptions({ name: 'DefaultLayout' });
const fabPos = ref([3, 80]);
const leftDrawerOpen = ref<boolean>(false);

const appState = appStore();
const toggleLeftDrawer = () => {
  if (!leftDrawerOpen.value) {
    leftDrawerOpen.value = !leftDrawerOpen.value;
    appState.leftCollapsed = false;
  } else {
    if (!appState.leftCollapsed) {
      appState.leftCollapsed = true;
    } else leftDrawerOpen.value = false;
  }
}; //useToggle(leftDrawerOpen);

const topMenuChildren = computed(() => {
  const rightRoutes = getRightRoutes();
  if (!rightRoutes) {
    Global.Message?.warn('无法获取路由列表！');
    return [];
  }
  const resultItems = rightRoutes.find(
    (item) => item.name === 'DefaultLayout'
  )?.children; //routes.find((item) => item.name === "BackLayout")!.children;
  // console.log(resultItems, 'RightRoutest0001111');
  return resultItems;
});
const getRightIcon = computed(() => {
  if (!leftDrawerOpen.value) {
    return 'menu';
  } else {
    if (appState.leftCollapsed) {
      return 'o_align_horizontal_right';
    }
    return 'menu_open';
  }
});

const isOverlay = computed(() => appState.overlayMenu);
function onmouseover() {
  appState.overlayMenu = true;
}
function onmouseout() {
  appState.overlayMenu = false;
}
const moveFab = (ev) => {
  fabPos.value = [fabPos.value[0] - ev.delta.x, fabPos.value[1] - ev.delta.y];
};
onMounted(() => {
  Global.Loading('DefaultLayout布局');
  //加载完
  Global.Loading('end');
  Global.Message?.success('加载成功！');
});
</script>
<style lang="scss" scoped>
.body--light {
  .header {
    color: black;
    background-color: white;
  }
}

.body--dark {
  .header {
    color: white;
    background-color: $dark;
  }
}

/* fade-slide */
.fade-slide-leave-active,
.fade-slide-enter-active {
  transition: all 0.25s;
}

.fade-slide-enter-from {
  opacity: 0;
  transform: translateX(-30px);
}

.fade-slide-leave-to {
  opacity: 0;
  transform: translateX(30px);
}
</style>
