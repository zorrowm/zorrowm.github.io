<template>
  <q-layout view="hHh lpR fFf">
    <q-page-container>
      <LocationWeather class="absolute-top-right q-mr-sm shadow-1 " style="font-size:12px"/>
      <LayoutContainer
        :widgetConfig="configRef"
        :layoutID="layoutIDRef"
        @containerLoaded="loadedHandler"
      />
    </q-page-container>
  </q-layout>
</template>

<script lang="ts" setup>
// import FeiDoEvent from 'src/events/modules/FeiDoEvent';
// import {OffEventHandler,OnEventHandler} from 'src/events/index';
import LocationWeather from 'components/LocationWeather.vue';
import { getRightWidgetConfig } from 'src/permission';
import { appStore } from 'src/stores';
import { computed, onMounted, onUnmounted,ref } from 'vue';
import { Global, H5Tool, LayoutContainer, LayoutContainerEnum,LayoutManager } from 'xframelib';

defineOptions({ name: 'productLayout' });
const widgetCofig = getRightWidgetConfig();
const configRef = ref(widgetCofig);
const layoutIDRef = ref('productLayout');
let layoutManager:LayoutManager;
//获取服务此Layout的layoutManager
function loadedHandler(evt: any) {
  if (evt.layoutID === layoutIDRef.value) {
    //Global.Logger().debug(evt, 'loadedHandler');
    //服务Cesium大屏的
    if (!Global.LayoutMap) {
      Global.LayoutMap = new Map<string, any>();
    }
    layoutManager=evt.layoutManager;
    Global.LayoutMap.set(evt.layoutID, evt.layoutManager);
  }
}
const appState = appStore();
const  topHeaderHeight=computed(()=>{
  //是否显示头部栏
  const isShowHeader = appState.headerSetting.show;
  const topheight = isShowHeader ? appState.headerSetting.height : 0;
  return topheight;
})
onMounted(() => {
  Global.Loading('end');
  H5Tool.setCssVar('--center-pointer-events', 'none');
  H5Tool.setCssVar('--header-top-height', topHeaderHeight.value + 'px');
  // OnEventHandler(FeiDoEvent.FeiDo_ChangeContainerWidgetVisible,changeLayoutWidgetVisible);
});
onUnmounted(()=>{
  // OffEventHandler(FeiDoEvent.FeiDo_ChangeContainerWidgetVisible,changeLayoutWidgetVisible);
})
function changeLayoutWidgetVisible(visible:boolean=false)
{
  if(!layoutManager)
  {
    layoutManager=Global.LayoutMap.get('productLayout');
  }
  console.log('改变可见性000',visible);
  // layoutManager.changeContainerVisible(LayoutContainerEnum.centerFront);

  // layoutManager.unloadWidget('frontLayoutWidget');
  layoutManager?.changeWidgetVisible('frontLayoutWidget',visible);
  console.log('改变了widget可见性')
  // setTimeout(() => {
  //   console.log('3秒后改为可见！');
  //   layoutManager.getWidgetComponent('frontLayoutWidget').changeVisible(true);
  // }, 3000);
}
</script>
<style lang="scss" scoped>
.body--light {
  .header {
    color: black;
    background-color: white;
  }
}

.body--dark {
  .header {
    color: white;
    background-color: $dark;
  }
}

:deep(.centerFrontContainer)
{
  pointer-events:var(--center-pointer-events);
}
:deep(.mainContainer) {
  top: var(--header-top-height);
  // height:100vh;

}

:deep(.topContainer) {
  height: var(--header-top-height);
  pointer-events: auto;
}
:deep(.backContainer)
{
  bottom:0;
  height:calc(100vh - 1px);
}
</style>
