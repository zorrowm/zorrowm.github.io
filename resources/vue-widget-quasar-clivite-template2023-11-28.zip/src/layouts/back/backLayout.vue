<template>
  <LayoutContainer
    id="backLayoutContainer"
    :widgetConfig="configRef"
    :layoutID="layoutIDRef"
    @containerLoaded="loadedHandler"
  />
</template>

<script lang="ts">
import { storeToRefs } from 'pinia';
import { getRightWidgetConfig } from 'src/permission';
import { appStore } from 'src/stores';
import { defineComponent, onMounted, ref, watch } from 'vue';
import { Global, H5Tool, LayoutContainer, LayoutManager } from 'xframelib';

export default defineComponent({
  name: 'backLayout',
  components: {
    LayoutContainer,
  },
  setup(props, { attrs, slots, emit }) {
    const configRef = ref(getRightWidgetConfig());
    const layoutIDRef = ref('backLayout');
    //获取服务此Layout的layoutManager
    function loadedHandler(evt: any) {
      if (evt.layoutID === layoutIDRef.value) {
        Global.Logger().info(evt, 'loadedHandler');
        //服务Cesium大屏的
        if (!Global.LayoutMap) {
          Global.LayoutMap = new Map<string, any>();
        }
        Global.LayoutMap.set(evt.layoutID, evt.layoutManager);
        //判断加载
        loadInitWidgets(evt.layoutManager);
      }
    }
    const appState = appStore();
    const { leftCollapsed } = storeToRefs(appState);
    watch(
      () => leftCollapsed.value,
      () => {
        computeLeftMenuWidth();
      }
    );

    function computeLeftMenuWidth() {
      const sideWidth = leftCollapsed.value
        ? appState.menuSetting?.minWidth
        : appState.menuSetting?.menuWidth;
      H5Tool.setCssVar('--leftSideWidth', sideWidth + 'px');
    }
    //必须先计算宽度
    computeLeftMenuWidth();
    function loadInitWidgets(layoutManager: LayoutManager) {
      const isShowFooter = appState.showFooter;
      if (isShowFooter) {
        //加载底部栏版权组件
        layoutManager.loadWidget('FooterCopyrightWidget');
      }
    }
    onMounted(() => {
      Global.Loading('end');
      //是否显示头部栏
      const isShowHeader = appState.headerSetting.show;
      const topheight = isShowHeader ? appState.headerSetting.height : 0;
      const divElem = document.getElementById('backLayoutContainer');
      if (divElem) {
        H5Tool.setCssVar('--header-top-height', topheight + 'px', divElem);
      }
      // setTimeout(() => {
      //   H5Tool.setCssVar('--test-color', '#ff0');
      // }, 3000);
    });

    return {
      configRef,
      layoutIDRef,
      loadedHandler,
    };
  },
});
</script>

<style scoped lang="scss">
:deep(.mainContainer) {
  top: var(--header-top-height);
  left: var(--leftSideWidth);
  width: calc(100% - var(--leftSideWidth));
  right: 0px;
  pointer-events: auto;
  overflow-y: auto;
  background-color: var(--main-bg-color);
  // @if ($test == light) {
  //   background-color: $main-bg-color-light;
  // } @else {
  //   background-color: $main-bg-color-dark;
  // }
}
// .body--light {
//   .mainContainer {
//     top: var(--header-top-height);
//     left: var(--leftSideWidth);
//     width: calc(100% - var(--leftSideWidth));
//     right: 0px;
//     pointer-events: auto;
//     overflow-y: auto;
//     background-color: $main-bg-color-light !important;
//   }
// }

// :deep(.body--light .mainContainer) {
//   top: var(--header-top-height);
//   left: var(--leftSideWidth);
//   width: calc(100% - var(--leftSideWidth));
//   right: 0px;
//   pointer-events: auto;
//   overflow-y: auto;
//   background-color: $main-bg-color-light;
// }

// :deep(.body--dark .mainContainer) {
//   top: var(--header-top-height);
//   left: var(--leftSideWidth);
//   width: calc(100% - var(--leftSideWidth));
//   right: 0px;
//   pointer-events: auto;
//   overflow-y: auto;
//   background-color: $main-bg-color-dark;
// }

:deep(.leftContainer) {
  top: var(--header-top-height);
  width: var(--leftSideWidth);
  height: unset;
  bottom: 0px;
  pointer-events: unset;
}
:deep(.topContainer) {
  height: var(--header-top-height);
  pointer-events: auto;
}
</style>
