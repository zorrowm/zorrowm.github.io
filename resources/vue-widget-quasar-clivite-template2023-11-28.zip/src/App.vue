<template>
  <router-view />
</template>

<script lang="ts">
import { OffEventHandler, OnEventHandler } from 'src/events';
import { defineComponent, onBeforeMount, onMounted, onUnmounted } from 'vue';
import { Global, onLockListener, SysEvents, unLockListener } from 'xframelib';
// import {getIPAddress} from 'src/netAPI/IPSearch';


export default defineComponent({
  name: 'App',
  setup() {
    // console.log(import.meta.url,'99999')
    function requestErrorHandler(errData: any) {
      if (!errData.isExceptionInfo) {
        const errInfo = `${errData.message}\n$${errData.result}`;
        Global.Message?.warn(errInfo);
      }
      Global.Logger().warn(errData, '请求错误');
    }
    onBeforeMount(() => {
      Global.Loading('App.vue');
    });
    onMounted(() => {
      onLockListener(); //长时间不操作退出
      //统一捕捉处理Axios请求异常
      OnEventHandler(SysEvents.AxiosRequestErrorEvent, requestErrorHandler);
      //IP查询
      // getIPAddress();
    });

    onUnmounted(() => {
      unLockListener();
      OffEventHandler(SysEvents.AxiosRequestErrorEvent, requestErrorHandler);
    });
  },
});
</script>
