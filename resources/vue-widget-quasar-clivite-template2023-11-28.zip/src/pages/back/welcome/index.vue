<template>
  <Icon icon="mdi:home" />
  <div class="q-pa-md" style="max-width: 350px">
    <q-list>
      <q-item v-for="(value, key) in browserInfo" :key="key" :label="key">
        <q-item-label> {{ value }}</q-item-label>
        <q-item-label caption>{{ key }}</q-item-label>
      </q-item>
    </q-list>
  </div>
  <q-btn color="primary" label="Primary" @click="doClick" />
</template>

<script lang="ts">
import BrowserType from 'src/utils/browser-type';
import { defineComponent, ref } from 'vue';
import { Global } from 'xframelib';
export default defineComponent({
  name: 'Welcome',
  components: {},
  setup() {
    // 获取浏览器信息
    const browserInfo = ref(BrowserType('zh-cn'));

    // watchEffect(() => {
    //   Object.assign(browserInfo.value, {
    //     距离电池充满需要:
    //       Number.isFinite(battery.value.chargingTime) && battery.value.chargingTime != 0
    //         ? calcDischargingTime.value
    //         : '未知',
    //     剩余可使用时间:
    //       Number.isFinite(battery.value.dischargingTime) && battery.value.dischargingTime != 0
    //         ? calcDischargingTime.value
    //         : '未知',
    //     电池状态: batteryStatus.value,
    //     当前电量: battery.value.level + '%'
    //   })
    // })

    // Global.Logger().debug(performanceMonitor.getPerformanceData(), 'performanceMonitor')
    function doClick() {
      Global.Message?.info('OOK测试一下');
    }
    return {
      browserInfo,
      doClick,
    };
  },
});
</script>

<style lang="scss" scoped>
.box {
  display: flex;
  width: 100%;
  height: calc(100vh - 280px);
  flex-direction: column;

  img {
    min-height: 0;
    flex: 1;
  }

  .ant-form {
    flex: 2;
  }
}
</style>
