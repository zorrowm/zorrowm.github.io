<template>
  <section class="scrollSection column justify-center">
    <q-card style="background-color: #1e1d32">
      <q-card-section>
        <div
          class="text-center q-mt-xl text-white text-h4 text-weight-bolder q-mb-md"
        >
          团队成员
        </div>
        <div class="row q-mt-xl">
          <div class="col-lg-12 col-sm-12 col-xs-12 col-md-12">
            <q-carousel
              v-model="slide"
              transition-prev="slide-right"
              transition-next="slide-left"
              swipeable
              animated
              auto-play
              control-color="primary"
              padding
              arrows
              autoplay=""
              height="100%"
              class="rounded-borders bg-transparent"
            >
              <q-carousel-slide :name="1" class="column no-wrap">
                <div
                  class="row fit justify-start items-center q-gutter-sm q-col-gutter no-wrap"
                >
                  <card></card>
                  <card v-if="!$q.screen.lt.sm"></card>
                </div>
              </q-carousel-slide>
              <q-carousel-slide :name="2" class="column no-wrap">
                <div
                  class="row fit justify-start items-center q-gutter-sm q-col-gutter no-wrap"
                >
                  <card></card>
                  <card v-if="!$q.screen.lt.sm"></card>
                </div>
              </q-carousel-slide>
              <q-carousel-slide :name="3" class="column no-wrap">
                <div
                  class="row fit justify-start items-center q-gutter-sm q-col-gutter no-wrap"
                >
                  <card></card>
                  <card v-if="!$q.screen.lt.sm"></card>
                </div>
              </q-carousel-slide>
              <q-carousel-slide :name="4" class="column no-wrap">
                <div
                  class="row fit justify-start items-center q-gutter-sm q-col-gutter no-wrap"
                >
                  <card></card>
                  <card v-if="!$q.screen.lt.sm"></card>
                </div>
              </q-carousel-slide>
            </q-carousel>
          </div>
        </div>
      </q-card-section>
    </q-card>
  </section>
</template>

<script setup lang="ts">
import {ref} from 'vue';

import card from './Card.vue';
const slide=ref('1')
</script>

<style scoped></style>
