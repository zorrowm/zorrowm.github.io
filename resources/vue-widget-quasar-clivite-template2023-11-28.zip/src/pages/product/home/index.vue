<template>
  <ScrollSnapContainer :height="containerHeight">
    <VideoPanel v-wow="{ 'animation-name': 'slideInDown' }"> </VideoPanel>
    <!-- <CarouselPanel v-wow="{ 'animation-name': 'slideInRight','animation-duration': '4s'}">
    </CarouselPanel>
    <MultigridEchartPanel v-wow="{ 'animation-name': 'slideInRight','animation-duration': '4s'}">
    </MultigridEchartPanel> -->
    <component
      :is="markRaw(defineAsyncComponent(item))"
      v-for="(item, index) in sectionArray"
      :key="index"
    ></component>
  </ScrollSnapContainer>

  <!-- <component
      :is="markRaw(defineAsyncComponent(item))"
      v-for="(item, index) in sectionArray"
      :key="index"
    ></component> -->
</template>

<script setup lang="ts">
import ScrollSnapContainer from 'components/ScrollSnapContainer/index.vue';
import LayoutTool from 'src/utils/layoutTool';
import { computed, defineAsyncComponent, markRaw, onMounted } from 'vue';

import CarouselPanel from './CarouselPanel.vue';
import MultigridEchartPanel from './MultigridEchartPanel.vue';
import VideoPanel from './VideoPanel.vue';
const containerHeight = computed(() => {
  return LayoutTool.getContentHeight();
});
const sectionArray = [
  () => import('./ProductTabPanel.vue'),
  () => import('./TeamPanel.vue'),
  () => import('./ProductPricePanel.vue'),
  () => import('./ProductDemoPanel.vue'),
];
</script>
