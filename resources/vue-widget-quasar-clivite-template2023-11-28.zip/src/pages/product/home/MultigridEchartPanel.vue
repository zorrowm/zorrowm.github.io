<template>
  <!-- 多Grid表格 -->
  <section class="scrollSection">
  <div ref="chartRef" class="echarts"></div>
  </section>

</template>

<script lang="ts" setup>
import { type ECOption, useEcharts } from 'src/composables/useECharts';
import { ref } from 'vue';
defineOptions({ name: 'multiGridEchartPanel' });
// 初始化 charts参数
const arr01=[Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1))
                    , Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1))
                    , Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1))
                    , Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1))
                    , Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1))];
const arr02=[Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1))
                    , Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1))
                    , Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1))
                    , Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1))
                    , Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1))];
const arr03=[Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1))
                    , Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1))
                    , Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1))
                    , Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1))
                    , Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1)), Math.floor(Math.random() * (100 + 1))];
const arr04=[Math.random(), Math.random(), Math.random()
                    , Math.random(), Math.random(), Math.random()
                    , Math.random(), Math.random(), Math.random()
                    , Math.random(), Math.random(), Math.random()
                    , Math.random(), Math.random(), Math.random()];
const option: ECOption = {
                        tooltip: {  //本坐标系特定的工具设定
                            trigger: 'axis'//坐标轴触发，主要在柱状图，折线图等会使用类目轴的图表
                        },
                        color: ['#f00', '#0f0', '#00f', '#ff0'],//配置颜色
                        legend: {
                            data: ['水位', '流量', '降雨量', '实测流量']//配置正上方显示的标签
                        },
                        grid: [
                        {//定义两个绘图网格 编号0开始
                            bottom: '70%',  //第一个绘图网格,离容器下侧的距离
                        },
                         {
                            top: '71%'  //第二个绘图网格离容器上侧的距离。
                        },
                        {
                           bottom: '50%', //第3个绘图网格离容器上侧的距离。
                           top: '30%'
                        },
                        {
                           bottom: '30%', //第4个绘图网格离容器上侧的距离。
                           top: '50%'
                        }
                      ],
                        toolbox: {  //图形右上角工具栏
                            feature: {//工具配置项
                                saveAsImage: {}//配置一个保存图片
                            }
                        },
                        xAxis: [{ //横轴,本例中有两个横轴
                            type: 'category',//坐标轴类型,当前表示[类目轴，适用于离散的类目数据]。
                            gridIndex: 0, //关联的网格图标序号
                            position: 'top', //文字显示在图的上方
                            data: ['', '', '', '', '',
                                '', '', '', '', '',
                                '', '', '', '', ''
                            ]//显示字段内容
                        }, {
                            type: 'category',//同上
                            gridIndex: 1,
                            data: [
                                '2020-07-31 06:00', '2020-07-31 18:00', '2020-08-01 06:00', '2020-08-01 18:00', '2020-08-02 06:00',
                                '2020-08-03 18:00', '2020-07-04 06:00', '2020-08-05 18:00', '2020-08-06 06:00', '2020-08-07 18:00',
                                '2020-08-08 06:00', '2020-07-09 18:00', '2020-08-10 06:00', '2020-08-11 18:00', '2020-08-12 06:00'
                            ]
                        },
                        { //横轴,本例中有两个横轴
                            type: 'category',//坐标轴类型,当前表示[类目轴，适用于离散的类目数据]。
                            gridIndex: 2, //关联的网格图标序号
                            position: 'top', //文字显示在图的上方
                            data: [
                            '', '', '', '', '',
                                '', '', '', '', '',
                                '', '', '', '', '','', '', '', '',
                            ]
                        },
                        { //横轴,本例中有两个横轴
                            type: 'category',//坐标轴类型,当前表示[类目轴，适用于离散的类目数据]。
                            gridIndex: 3, //关联的网格图标序号
                            position: 'top', //文字显示在图的上方
                            data: [
                            '', '', '', '', '',
                                '', '', '', '', '',
                                '', '', '', '', '','', '', '', '',
                            ]
                        },
                       ],
                        yAxis: [{//纵轴设定/当前示例中有三个纵轴
                            gridIndex: 0, //绑定网格的标号
                            type: 'value',//类型[数值轴，适用于连续数据]。
                            name: '降雨量(mm)', //名称
                            position: 'left',//显示在图的左边
                            nameRotate:90,//旋转90度
                            nameLocation : 'middle',//显示在周的侧面
                            nameGap : 30//与轴的距离
                        }, {
                            gridIndex: 1,
                            type: 'value',
                            name: '水位(m)',
                            position: 'left',
                            nameRotate:90,
                            nameLocation : 'middle',
                            nameGap : 30
                        },
                         {
                            gridIndex: 2,
                            type: 'value',
                            name: '流量(m³/s)',
                            position: 'left',//显示在图的右侧
                            nameRotate:90,
                            nameLocation : 'middle',
                            nameGap : 30
                        },
                        {
                            gridIndex: 3,
                            type: 'value',
                            name: '测试(m³/s)',
                            position: 'left',
                            nameRotate:90,
                            nameLocation : 'middle',
                            nameGap : 30,
                            max:100,
                            min :0,
                            splitNumber:3,
                            scale:true
                        }
                      ],
                        series: [  //图中的数据
                            {
                                name: '水位',  //数据名称
                                type: 'line',  //类型
                                showSymbol: false, //是否显示 symbol, 如果 false 则只有在 tooltip hover 的时候显示。
                                data: arr01,  //数据来源,这里是获取vue中定义的数组
                                xAxisIndex: 1, //关联在那个横轴上,横轴的序号,从0开始
                                yAxisIndex: 1  //关联在那个纵轴上,横轴的序号,从0开始
                            },
                            {
                                name: '流量',
                                type: 'line',
                                showSymbol: false,
                                data: arr02,
                                xAxisIndex: 2,
                                yAxisIndex: 2
                            },

                            {
                                name: '降雨量',
                                type: 'line',
                                showSymbol: false,
                                data: arr04,
                                xAxisIndex: 0,
                                yAxisIndex: 0
                            },
                            {
                                name: '实测流量',
                                type: 'line',
                                showSymbol: false,
                                data: arr03,
                                xAxisIndex: 3,
                                yAxisIndex: 3
                            },

                        ]
                    };
const chartRef = ref<HTMLElement | null>(null);
const chartsOption = ref<ECOption>(option);
useEcharts(chartRef, chartsOption);
</script>

<style lang="scss" scoped>
.echarts {
  width: 100%;
  height: 100%;
}
</style>
