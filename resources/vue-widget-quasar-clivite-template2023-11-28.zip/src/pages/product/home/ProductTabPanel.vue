<template>
  <section
    class="scrollSection column justify-center"
    style="background-color: #ff0"
  >
    <q-card style="background-color: #1e1d32; height: 80%">
      <q-card-section class="q-mx-xl">
        <div
          class="text-center q-mt-xl text-white text-h4 text-weight-bolder q-mb-md"
        >
          <q-tabs
            v-model="tab"
            dense
            align="justify"
            class="bg-transparent text-white rounded-borders"
            :breakpoint="0"
          >
            <q-tab name="p1" label="时空矢量云平台" />
            <q-tab name="p2" label="时空影像云平台" />
            <q-tab name="p3" label="产品3" />
          </q-tabs>
        </div>
        <q-tab-panels v-model="tab" animated class="bg-transparent text-white">
          <q-tab-panel name="p1" class="q-pa-none">
            <q-card class="q-pa-none bg-transparent row">
              <q-card-section
                horizontal
                class="col-lg-6 col-md-6 col-sm-12 col-xs-12"
              >
                <q-img src="/product/vector1.png" />
              </q-card-section>

              <q-card-section
                class="q-px-lg col-lg-6 col-md-6 col-sm-12 col-xs-12 text-justify"
              >
                <div class="text-h6">时空矢量云平台</div>

                <div class="q-mt-sm">
                  时空矢量云平台提供海量、多源矢量数据的存储管理、快速发布、渲染配图、应用扩展的一体化解决方案，提供海量、多源矢量数据的存储管理、快速发布、渲染配图、应用扩展的一体化解决方案，支持用户快速构建云端一体化的时空大数据应用平台。
                </div>
                <div class="q-mt-md">
                  <q-btn
                    label="申请试用"
                    style="
                      background-image: linear-gradient(
                        to right,
                        #89f7fe 0%,
                        #66a6ff 100%
                      ) !important;
                    "
                  ></q-btn>
                </div>
              </q-card-section>
            </q-card>
          </q-tab-panel>

          <q-tab-panel name="p2" class="q-pa-none">
            <q-card class="q-pa-none bg-transparent row">
              <q-card-section
                class="q-px-lg col-lg-6 col-md-6 col-sm-12 col-xs-12 text-justify"
              >
                <div class="text-h6">时空影像云平台</div>

                <div class="q-mt-sm">
                  时空影像云平台（简称：影像平台）是一款先进的轻量级、跨平台、高性能的影像瓦片化服务发布平台。采用高效空间索引及算法、多线程并行计算模型和微服务架构设计研发，重点提升影像数据的入库存储、数据管理、服务发布、应用扩展的核心业务效率。针对PB级多源异构影像提供从入库到应用的全流程、全自动化、全在线、全平台支撑。具有高速、高效、易用、稳定、易拓展、自动化等特点。支持国内外不同类型不同投影影像的OGC标准化服务发布，也可用于支撑影像生产和质检、成果影像管理和发布、历史影像归档和管理等应用场景。
                </div>
                <div class="q-mt-md">
                  <q-btn
                    label="申请试用"
                    style="
                      background-image: linear-gradient(
                        to right,
                        #89f7fe 0%,
                        #66a6ff 100%
                      ) !important;
                    "
                  ></q-btn>
                </div>
              </q-card-section>
              <q-card-section
                horizontal
                class="col-lg-6 col-md-6 col-sm-12 col-xs-12"
              >
                <q-img src="/product/image1.png" />
              </q-card-section>

            </q-card>
          </q-tab-panel>

          <q-tab-panel name="p3" class="q-pa-none">
            <q-card class="q-pa-none bg-transparent row">
              <q-card-section
                horizontal
                class="col-lg-6 col-md-6 col-sm-12 col-xs-12"
              >
                <q-img src="/product/download.jpg" />
              </q-card-section>

              <q-card-section
                class="q-pa-none col-lg-6 col-md-6 col-sm-12 col-xs-12 text-justify"
              >
                <div class="text-h6">
                  <q-list class="full-width">
                    <q-item class="full-width">
                      <q-item-section top avatar>
                        <q-avatar rounded size="60px">
                          <img
                            src="https://cdn.quasar.dev/img/boy-avatar.png"
                          />
                        </q-avatar>
                      </q-item-section>

                      <q-item-section>
                        <q-item-label class="text-weight-bolder"
                          >SHANKLE RIBEYE BACON</q-item-label
                        >
                        <q-item-label caption class="text-white"
                          >267 347 participants
                        </q-item-label>
                      </q-item-section>
                    </q-item>
                    <q-separator color="white" inset="item"></q-separator>
                    <q-item class="full-width">
                      <q-item-section top avatar>
                        <q-avatar rounded size="60px">
                          <img
                            src="https://cdn.quasar.dev/img/boy-avatar.png"
                          />
                        </q-avatar>
                      </q-item-section>

                      <q-item-section>
                        <q-item-label class="text-weight-bolder"
                          >BACON TENDERLOIN DRUMSTICK MEATBALL</q-item-label
                        >
                        <q-item-label caption class="text-white"
                          >267 347 participants
                        </q-item-label>
                      </q-item-section>
                    </q-item>
                    <q-separator color="white" inset="item"></q-separator>
                    <q-item class="full-width">
                      <q-item-section top avatar>
                        <q-avatar rounded size="60px">
                          <img
                            src="https://cdn.quasar.dev/img/boy-avatar.png"
                          />
                        </q-avatar>
                      </q-item-section>

                      <q-item-section>
                        <q-item-label class="text-weight-bolder"
                          >DONER BRESAOLA PORK KIELBASA</q-item-label
                        >
                        <q-item-label caption class="text-white"
                          >267 347 participants
                        </q-item-label>
                      </q-item-section>
                    </q-item>
                    <q-separator color="white" inset="item"></q-separator>
                    <q-item class="full-width">
                      <q-item-section top avatar>
                        <q-avatar rounded size="60px">
                          <img
                            src="https://cdn.quasar.dev/img/boy-avatar.png"
                          />
                        </q-avatar>
                      </q-item-section>

                      <q-item-section>
                        <q-item-label class="text-weight-bolder"
                          >KIELBASA FATBACK ALCATR</q-item-label
                        >
                        <q-item-label caption class="text-white"
                          >267 347 participants
                        </q-item-label>
                      </q-item-section>
                    </q-item>
                  </q-list>
                </div>
              </q-card-section>
            </q-card>
          </q-tab-panel>
        </q-tab-panels>
      </q-card-section>
    </q-card>
  </section>
</template>

<script>
import { ref } from 'vue';

export default {
  setup() {
    return {
      tab: ref('p1'),
    };
  },
};
</script>
<style>
.q-carousel__slide,
.q-carousel .q-carousel--padding {
  padding: 0px;
}
</style>
