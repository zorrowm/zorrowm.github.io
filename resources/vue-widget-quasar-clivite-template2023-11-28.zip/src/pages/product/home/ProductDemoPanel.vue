<template>
  <section
    class="scrollSection   column justify-center"
  >
  <q-card style="background-color: #1e1d32">
  <q-card-section class="q-mx-xl">
        <div class="text-center q-mt-md text-white text-h4 text-weight-bolder q-mb-sm">
         应用案例
        </div>
        <div class="row q-mt-md q-col-gutter-lg">
          <div v-for="(data,index) in post_data" :key="index" class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
            <q-card style="background-color: #292845" class="text-white">
              <q-img
                :src="data.img"
              />
              <!-- <q-separator></q-separator> -->
              <!-- <q-card-section class="text-subtitle1 q-px-xl">
                Bar XYZ
                <div class="float-right">
                  MAR 12 2020
                </div>
              </q-card-section> -->
              <q-card-section class="text-h5 q-px-lg">
                {{ data.title }}
              </q-card-section>
              <q-card-section class="q-px-xl">
                <div>
                  {{text}}
                </div>
              </q-card-section>
              <q-card-section class="text-subtitle1  q-px-lg">
                <q-btn color="" icon="person" class="bg-transparent text-capitalize" flat label="By Admin"/>
                <div class="float-right">
                  <q-btn color="" icon="chat_bubble" class="bg-transparent" flat label="56"/>
                </div>
              </q-card-section>
            </q-card>
          </div>
        </div>
      </q-card-section>
</q-card>
  </section>
</template>

<script setup lang="ts">
const post_data= [
  {
  title:'机场净空限制面三维管理系统',
  img:'/product/img-1.png'
},
 {
  title:'税源户籍管理系统',
  img: '/product/img-2.png'
 },
{
  title:'重庆市农业生产智能化分析平台',
  img: '/product/img-3.png'
}];
const  text= '产品稳定高效地支撑了项目实施。高效的影像不切片服务快速发布平台，支持百PB级遥感卫星影像数据 极速分发、在线处理、实时更新、智能应用';
</script>

<style scoped>

</style>
