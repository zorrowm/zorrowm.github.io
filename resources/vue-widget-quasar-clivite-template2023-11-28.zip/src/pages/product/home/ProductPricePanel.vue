<template>
  <section
    class="scrollSection   column justify-center"
  >
    <q-card style="background-color: #1e1d32">
      <q-card-section>
        <div
          class="text-center q-mt-xl text-white text-h4 text-weight-bolder q-mb-md"
        >
          产品销售方案
        </div>
        <div class="row justify-center q-col-gutter-lg q-pa-lg">
          <div class="col-lg-4 col-sm-12 col-xs-12 col-md-4">
            <q-intersection once transition="scale">
              <q-card style="background-color: #181728" class="text-white">
                <q-card-section class="text-center text-h6 q-pa-lg">
                  单机版
                </q-card-section>
                <q-card-section
                  class="text-center"
                  style="
                    background-image: linear-gradient(
                      to top,
                      #a8edea 0%,
                      #fed6e3 100%
                    );
                  "
                >
                  <div class="text-weight-bolder">
                    <span class="text-h6">￥</span
                    ><span class="text-h3">1999.</span
                    ><span class="text-h6">00</span>
                  </div>
                </q-card-section>

                <q-card-section class="text-center">
                  <q-item class="text-center">
                    <q-item-section> 单机安装部署 </q-item-section>
                  </q-item>
                  <q-separator color="white" />
                  <q-item>
                    <q-item-section>
                      单用户使用
                    </q-item-section>
                  </q-item>
                  <q-separator color="white" />
                  <q-item>
                    <q-item-section> 数据量限制100G </q-item-section>
                  </q-item>
                </q-card-section>

                <q-card-actions vertical align="center">
                  <q-btn
                    class="text-capitalize q-mb-md q-pa-xs"
                    style="background-color: #181728"
                    outline
                    color=""
                    >联系购买
                  </q-btn>
                </q-card-actions>
              </q-card>
            </q-intersection>
          </div>
          <div class="col-lg-4 col-sm-12 col-xs-12 col-md-4">
            <q-intersection once transition="scale">
              <q-card style="background-color: #181728" class="text-white">
                <q-card-section class="text-center text-h6 q-pa-lg">
                  标准版
                </q-card-section>

                <q-card-section
                  class="text-center"
                  style="
                    background-image: linear-gradient(
                      to right,
                      #74ebd5 0%,
                      #9face6 100%
                    );
                  "
                >
                  <div class="text-weight-bolder">
                    <span class="text-h6">￥</span
                    ><span class="text-h3">5999.</span
                    ><span class="text-h6">00</span>
                  </div>
                </q-card-section>

                <q-card-section class="text-center">
                  <q-item class="text-center">
                    <q-item-section> 服务器部署 </q-item-section>
                  </q-item>
                  <q-separator color="white" />
                  <q-item>
                    <q-item-section> 多用户并行 </q-item-section>
                  </q-item>
                  <q-separator color="white" />
                  <q-item>
                    <q-item-section> 不限数据量 </q-item-section>
                  </q-item>
                </q-card-section>
                <q-card-actions vertical align="center">
                  <q-btn
                    class="text-capitalize q-mb-md q-pa-xs"
                    style="background-color: #181728"
                    outline
                    color=""
                    >联系购买
                  </q-btn>
                </q-card-actions>
              </q-card>
            </q-intersection>
          </div>
          <div class="col-lg-4 col-sm-12 col-xs-12 col-md-4">
            <q-intersection once transition="scale">
              <q-card style="background-color: #181728" class="text-white">
                <q-card-section class="text-center text-h6 q-pa-lg">
                  专业版
                </q-card-section>

                <q-card-section
                  class="text-center"
                  style="
                    background-image: linear-gradient(
                      135deg,
                      #667eea 0%,
                      #764ba2 100%
                    );
                  "
                >
                  <div class="text-weight-bolder">
                    <span class="text-h6">￥</span
                    ><span class="text-h3">9999.</span
                    ><span class="text-h6">00</span>
                  </div>
                </q-card-section>

                <q-card-section class="text-center">
                  <q-item class="text-center">
                    <q-item-section> 云端服务器集群化部署</q-item-section>
                  </q-item>
                  <q-separator color="white" />
                  <q-item>
                    <q-item-section>
                      多用户弹性高并发
                    </q-item-section>
                  </q-item>
                  <q-separator color="white" />
                  <q-item>
                    <q-item-section>
                      不限数据量
                    </q-item-section>
                  </q-item>
                </q-card-section>
                <q-card-actions vertical align="center">
                  <q-btn
                    class="text-capitalize q-mb-md q-pa-xs"
                    size="md"
                    style="background-color: #181728"
                    outline
                    color=""
                  >
                    联系购买
                  </q-btn>
                </q-card-actions>
              </q-card>
            </q-intersection>
          </div>
        </div>
      </q-card-section>
    </q-card>
  </section>
</template>

<script>
</script>
