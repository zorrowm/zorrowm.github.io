<template>
    <q-intersection
      once
      transition="scale"
    >
    <q-card
      :class="$q.screen.lt.sm?'rounded-borders full-height text-white col-lg-6 col-md-6 col-xs-12 col-sm-12':'rounded-borders text-white col-lg-12 col-md-12 col-xs-12 col-sm-12'"
      style="background-color: #181728">
      <q-card-section class="text-center">
        <q-avatar size="100px" class="shadow-10">
          <img src="https://cdn.quasar.dev/img/boy-avatar.png">
        </q-avatar>
      </q-card-section>

      <q-card-section class="q-pt-none  ">
        <div class="text-h6 text-center ">
          小王
        </div>
        <div :class="!$q.screen.lt.sm?'text-caption q-mt-md text-justify q-px-xl':'text-caption q-mt-md text-justify'">
          {{text}}
        </div>
      </q-card-section>
    </q-card>
    </q-intersection>

</template>

<script>
    export default {
        name: 'Card',
        data() {
            return {
                text: '专业的前端WebGIS研发工程师，擅长二三维GIS开发。参与产品的前端开发，与后端工程师协作，高质高效完成产品的数据交互、动态信息展现；3.提升产品的用户体验、前端性能以及团队的开发效率；'
            }
        }
    }
</script>

<style scoped>

</style>
