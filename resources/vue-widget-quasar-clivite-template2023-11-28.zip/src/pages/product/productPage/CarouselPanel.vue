<template>
    <div class="scrollSection">
        <q-carousel
v-model="slide" :autoplay="false" animated arrows navigation infinite style="height:100%"
            control-color="white" class="bg-primary text-white">
            <q-carousel-slide
:name="1" img-src="/productImg/slide1.png"
                class="column no-wrap flex justify-center items-end">
                <div class="flex column justify-center items-start" style="width:50%;">
                    <div v-media="'text-h2.md text-h3.lt.lg'" class="q-mt-md text-h1 font_shadow ">{{ carouselText1_title1 }}</div>
                    <div v-media="'text-h2.gt.md text-h3.md text-h4.lt.md'" class="q-mt-md text-h2 font_shadow">{{ carouselText1_title2 }}</div>
                </div>
                <div class="flex column justify-center items-end" style="width:50%;">
                    <div class="q-mt-md ">{{ carouselText1 }}</div>
                    <div class="q-mt-md ">{{ carouselText1_2 }}</div>
                </div>
            </q-carousel-slide>
            <q-carousel-slide
:name="2" img-src="/productImg/slide2.png"
                class="column no-wrap flex justify-center items-start">
                <div style="width:80%;margin:0 auto;">
                    <div class="q-mt-md text-h2 font_shadow">
                        {{ carouselText2_1 }}
                    </div>
                    <div class="q-mt-md">
                        {{ carouselText2_2 }}
                    </div>
                </div>

            </q-carousel-slide>
            <q-carousel-slide
:name="3" img-src="/productImg/slide3.png"
                class="column no-wrap flex justify-center items-start">
                <div style="width:55%;margin-left: 10%;" >
                    <div class="q-mt-md text-h2 font_shadow">
                        {{ carouselText3_1 }}
                    </div>
                    <div class="q-mt-md">
                        {{ carouselText3_2 }}
                    </div>
                </div>
            </q-carousel-slide>
            <q-carousel-slide :name="4" img-src="/productImg/slide4.png" class="column no-wrap flex-center">
                <div style="width:80%;margin:0 auto;">
                    <div class="q-mt-md text-h2 font_shadow text-center">
                        {{ carouselText4_1 }}
                    </div>
                    <div class="q-mt-md">
                        {{ carouselText4_2 }}
                    </div>
                </div>
            </q-carousel-slide>
        </q-carousel>
    </div>
</template>
<script setup lang ='ts'>
import { ref } from 'vue';

const slide = ref(2);
const carouselText1_title1 = '帝测';
const carouselText1_title2 = '时空云平台';
const carouselText1 = '帝测时空云平台是面向测绘地理信息行业大数据的管理、发布、应用与服务的云平台，是针对基础时空数据建设的解决方案，突破性解决了海量时空矢量、影像及三维数据的入库管理和服务发布时性能瓶颈，整体提升了地理信息在线服务的效率和价值，具有传统GIS应用平台无法比拟的优势。 ';
const carouselText1_2 = '帝测GIS时空云平台是高效的地理信息(栅格、矢量、影像、三维等)海量数据发布应用平台，运用地理信息、大数据、云计算、微服务、容器化等先进成熟技术，实现基于云GIS技术架构的地理信息服务功能，解决海量数据在实际GIS应用中受系统性能制约的瓶颈问题，提升在线地图服务中海量地理信息数据的价值，优化各类GIS应用系统的整体性能，助力于解决地理信息行业用户的基础性问题。 ';
const carouselText2_1 = '时空矢量云平台';
const carouselText2_2 = ' 包括矢量数据切片系统和矢量切片在线配图系统，提供海量、多源矢量数据的储存管理、快速发布、渲染配图、应用拓展的一体化解决方案，支持用户快速构建云端一体化的时空大数据应用平台。';
const carouselText3_1 = '时空影像云平台';
const carouselText3_2 = ' 时空影像云平台是先进的轻量级、跨平台、高性能的影像瓦片化服务发布平台。采用高效空间索引及算法、多线程并行计算模型和微服务架构设计研发，重点提升影像数据的入库存储、数据管理、服务发布、应用扩展的核心业务效率。针对PB级多源异构影像提供从入库到应用的全流程、全自动化、全在线、全平台支撑。具有高速、高效、易用稳定、易拓展、自动化等特点。支持国内外不同类型不同投影影像的OGC标准化服务发布，也可用于支撑影像生产和质检、成果影像管理和发布、历史影像归档和管理等应用场景。';

const carouselText4_1 = '地图瓦片服务发布系统';
const carouselText4_2 = '地图瓦片服务发布系统是一款先进的轻量级、跨平台、高性能的地图切片服务快速发布和应用管理的平台。配合专有的高校地图配图切图桌面程序，形成从数据管理、地图配图、服务发布、应用管理的一体化解决方案。系统基于Web的地图图块服务接口标准（WMTS）';
</script>
<style scoped>
.font_shadow {
    font-weight: 800;
    opacity: 0.95;
    text-shadow: 0px 5px 5px rgb(8, 8, 8, .3);
    /* color: white; */
}</style>
