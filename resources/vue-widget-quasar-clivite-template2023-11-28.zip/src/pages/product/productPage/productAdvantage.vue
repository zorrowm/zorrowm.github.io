<template>
    <div class="scrollSection ">
        <div class="column flex-center produceAdvantage" style="width:100%;height: 100%;">
            <div class="column col-3 relative-position  flex-center">
                <div v-media="'text-h2.gt.lg text-h3.lg text-h4.md text-h5.sm text-h6.xs'" class="text-blue-9 ">{{ titleEn }}</div>
                <div v-media="'text-h2.gt.lg text-h3.lg text-h4.md text-h5.sm text-h6.xs'" class="text-grey-1 absolute" style="bottom:20%;">{{ titleCh }}</div>
            </div>
            <div class="row col-5 justify-around" style="width:80%">
                <div class="col-4 column flex-center">
                    <div style="width:200px;">
                        <div class="radio1">
                            <div class="radio2"><img src="/productImg/ad1.png" /></div>
                        </div>
                    </div>
                </div>
                <div class="col-4 column flex-center">
                    <div style="width:200px;">
                        <div class="radio1">
                            <div class="radio2"><img src="/productImg/ad2.png" /></div>
                        </div>
                    </div>
                </div>
                <div class="col-4 column flex-center">
                    <div style="width:200px;">
                        <div class="radio1">
                            <div class="radio2"><img src="/productImg/ad3.png" /></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row col-4 justify-around" style="width:80%">
                <div class="col-4 column justify-start items-center text-grey-1">
                    <div>{{ text1_1 }}</div>
                    <div>{{ text1_2 }}</div>
                    <div>{{ text1_3 }}</div>
                    <div>{{ text1_4 }}</div>
                </div>
                <div class="col-4 column justify-start items-center text-grey-1">
                    <div>{{ text2_1 }}</div>
                    <div>{{ text2_2 }}</div>
                    <div>{{ text2_3 }}</div>
                    <div>{{ text2_4 }}</div>
                </div>
                <div class="col-4 column justify-start items-center text-grey-1">
                    <div>{{ text3_1 }}</div>
                    <div>{{ text3_2 }}</div>
                </div>
            </div>
        </div>
    </div>
</template>
<script lang='ts' setup>
const titleCh = '产品优势';
const titleEn = 'PRODUCT ADVANTAGES';
const text1_1 = '支撑大数据量发布';
const text1_2 = '有效防止大数据量请求压垮服务节点';
const text1_3 = '微服务单元分布式部署与灵活配置';
const text1_4 = '分页任务包均匀';

const text2_1 = '服务标准化';
const text2_2 = '支持规范地实现OGC的WMTS标准，重构规范WMTS';
const text2_3 = 'REST、KVP等服务方式调用影像服务；';
const text2_4 = '支持ArcGIS、QGIS、Openlayers、Leaflet、MapBox、Cesium等平台调用；';

const text3_1 = '平台性能强大';
const text3_2 = '大数据量服务发布，数据量可达60T。';
</script>
<style scoped>
.produceAdvantage {
    width: 100%;
    height: 100%;
    background-image: url('/productImg/advantageBack.png');
    background-repeat: no-repeat;
    background-size: 100% 100%;
}

.radio1 {
    background-color: #e6edfa;
    border-radius: 50%;
    width: 20vmin;
    height: 20vmin;
    display: flex;
    justify-content: center;
    align-items: center;
}

.radio2 {
    background-color: rgba(240, 245, 255, 1);
    border-radius: 50%;
    width: 15vmin;
    height: 15vmin;
    display: flex;
    justify-content: center;
    align-items: center;
}

.radio1 .radio2 img {
    width: 50%;
    height: auto;
}
</style>
