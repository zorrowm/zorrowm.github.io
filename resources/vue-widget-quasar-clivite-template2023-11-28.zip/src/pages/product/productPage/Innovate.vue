<template>
    <div class="scrollSection">
        <div class="column justify-evenly items-center useType" style="width:100%;height: 100%;">
            <div class="column flex-center col-3 relative-position">
                <div v-media="'text-h2.gt.lg text-h3.lg text-h4.md text-h5.sm text-h6.xs'" class="text-grey-12"> {{ titleEn }}</div>
                <div v-media="'text-h2.gt.lg text-h3.lg text-h4.md text-h5.sm text-h6.xs'" class="text-blue-10 absolute" style="bottom:20%;"> {{ titleCh }}</div>
            </div>
            <div class="row q-gutter-x-md" style="width:80%;">
                <div class="col column flex-center q-gutter-y-md shadow-1 rounded-borders" style="padding:30px;">
                    <div class="innovateImg "><img src="/productImg/relationImg/1.png" /></div>
                    <div class="text-h6 ">{{ title1 }}</div>
                </div>
                <div class="col column flex-center q-gutter-y-md shadow-1 rounded-borders">
                    <div class="innovateImg"><img src="/productImg/relationImg/2.png" /></div>
                    <div class="text-h6">{{ title2 }}</div>
                </div>
                <div class="col column flex-center q-gutter-y-md shadow-1 rounded-borders">
                    <div class="innovateImg"><img src="/productImg/relationImg/3.png" /></div>
                    <div class="text-h6">{{ title3 }}</div>
                </div>
                <div class="col column flex-center q-gutter-y-md shadow-1 rounded-borders">
                    <div class="innovateImg"><img src="/productImg/relationImg/4.png" /></div>
                    <div class="text-h6">{{ title4 }}</div>
                </div>
                <div class="col column flex-center q-gutter-y-md shadow-1 rounded-borders">
                    <div class="innovateImg"><img src="/productImg/relationImg/5.png" /></div>
                    <div class="text-h6">{{ title5 }}</div>
                </div>
            </div>
        </div>
    </div>
</template>
<script lang='ts' setup>
const titleEn = 'FIVE INNOVATION DIRECTIONS';
const titleCh = '五大创新方向';
const title1 = '时空大数据平台研发';
const title2 = '区域可持续发展研究';
const title3 = '多源时空数据智能处理研究';
const title4 = '文物数字化保护研究';
const title5 = '自然资源调查监测研究';
</script>
<style scoped></style>