<template>
    <div class="scrollSection">
        <div class="column justify-evenly items-center useType" style="width:100%;height: 100%;">
            <div class="column flex-center col-3 relative-position">
                <!-- <div v-media="'text-h2.gt.lg text-h4.md text-h6.sm test.sm'">时空影像云平台</div> -->
                <div v-media="'text-h2.gt.lg text-h3.lg text-h4.md text-h5.sm text-h6.xs'" class="text-grey-12"> {{ titleEn }}</div>
                <div v-media="'text-h2.gt.lg text-h3.lg text-h4.md text-h5.sm text-h6.xs'" class="text-blue-10 absolute" style="bottom:20%;"> {{ titleCh }}</div>
            </div>
            <div class="row q-gutter-x-md" style="width:80%;">
                <div class="col shadow-5 rounded-borders q-pa-lg relative-position">
                    <div class="text-h5 q-mb-md">{{ card1_title }}</div>
                    <div class=" casesecondTitle">
                        <a
href="http://211.103.133.129:480/#/mapguestview?mapname=China_DuShiHei&ruleid=W"
                            target="_blank">{{ card1_name1 }}</a>
                    </div>
                    <div class="casesecondTitle"><a
                            href="http://211.103.133.129:480/#/mapguestview?mapname=China_TianDiTu&ruleid=W"
                            target="_blank">{{ card1_name2 }}</a></div>
                    <div class="casesecondTitle"><a
                            href="http://211.103.133.129:480/#/mapguestview?mapname=China_Blue_new1&ruleid=W"
                            target="_blank">{{ card1_name3 }}</a></div>
                    <div class="casesecondTitle"><a
                            href="http://211.103.133.129:480/#/mapguestview?mapname=MaKaLong&ruleid=W" target="_blank">{{
                                card1_name4 }}</a></div>
                    <div class="casesecondTitle"><a
href="http://211.103.133.129:480/#/mapguestview?mapname=World&ruleid=W"
                            target="_blank">{{ card1_name5 }}</a></div>
                    <div class="casesecondTitle"><a
                            href="http://211.103.133.129:480/#/mapguestview?mapname=china_new1&ruleid=W" target="_blank">{{
                                card1_name6 }}</a></div>
                    <div class="casesecondTitle"><a
                            href="http://211.103.133.129:480/#/mapguestview?mapname=LiaoNing_Pro&ruleid=W"
                            target="_blank">{{ card1_name7 }}</a></div>
                    <div class="casesecondTitle"><a
href="http://211.103.133.129:480/#/mapguestview?mapname=BJ_YEY&ruleid=W"
                            target="_blank">{{ card1_name8 }}</a></div>
                    <div class="casesecondTitle"><a
                            href="http://211.103.133.129:480/#/mapguestview?mapname=RLT_test&ruleid=W" target="_blank">{{
                                card1_name9 }}</a></div>
                    <div class="caseimg absolute flex justify-end"><img src="/productImg/caseimg1.png" /></div>
                </div>
                <div class="col shadow-5 rounded-borders q-pa-lg relative-position">
                    <div class="text-h5 q-mb-md">{{ card2_title }}</div>
                    <div class="casesecondTitle">
                        <a href="http://211.103.133.129:280/#/mapguestview?id=qqrk_lambert&type=s" target="_blank">{{
                            card2_name1 }}</a>
                    </div>
                    <div class="casesecondTitle">
                        <a href="http://211.103.133.129:280/#/mapguestview?id=qqren_albers&type=s" target="_blank">{{
                            card2_name2 }}</a>
                    </div>
                    <div class="casesecondTitle">
                        <a href="http://211.103.133.129:280/#/mapguestview?id=qqren_W&type=s" target="_blank">{{ card2_name3
                        }}</a>
                    </div>
                    <div class="casesecondTitle">
                        <a
href="http://211.103.133.129:280/#/mapguestview?id=%E5%85%A8%E7%90%83%E5%9C%B0%E5%BD%A2%E5%9B%BE&type=s"
                            target="_blank">{{ card2_name4 }}</a>
                    </div>
                    <div class="casesecondTitle">
                        <a href="http://211.103.133.129:280/#/guestmultimap?id=WLKXC" target="_blank">{{ card2_name5 }}</a>
                    </div>
                    <div class="casesecondTitle">
                        <a href="http://211.103.133.129:280/#/mapguestview?id=DEM&type=r" target="_blank">{{ card2_name6
                        }}</a>
                    </div>
                     <div class="caseimg absolute flex justify-end"><img src="/productImg/caseimg2.png" /></div>
                </div>
            </div>
        </div>

       
    </div>


   
</template>
<script lang='ts' setup>
const titleEn = 'CASE EFFECT DEMONSTRATION';
const titleCh = '案例效果展示';
const card1_title = '时空矢量云平台案例';
const card1_name1 = '中国电子地图（都市黑风格）';
const card1_name2 = '中国电子地图（天地图标准样式）';
const card1_name3 = '中国电子地图（极夜蓝风格）';
const card1_name4 = '中国电子地图（马卡龙风格）';
const card1_name5 = '全球行政区划图';
const card1_name6 = '全国行政区划图';
const card1_name7 = '省级行政区划图';
const card1_name8 = '北京市学校分布专题图';
const card1_name9 = '热力图';

const card2_title = '时空影像云平台案例';
const card2_name1 = '全球人口密度图兰伯特投影坐标系';
const card2_name2 = '全球人口密度图阿伯斯投影坐标系';
const card2_name3 = '全球人口密度图墨卡托投影坐标系';
const card2_name4 = '全球地形图';
const card2_name5 = '未来科学城多时相服务';
const card2_name6 = '北京市地形图';
</script>
<style scoped>
.casesecondTitle a{
    text-decoration:none;
    color:black;
}
.caseimg{
    right:0;
    bottom:0;
    margin-right:4px;
}
.caseimg img{
    width:50%;
    height:auto;
}
</style>