<!-- v-media="'text-h2.gt.lg text-h4.md text-h6.sm test.sm'" -->
<template>
    <div class="scrollSection ">
        <div class="column flex-center produceService" style="width:100%;height: 100%;">
            <div class="column flex-center col-4 col-sm-2 gt-xs relative-position">
                <div v-media="'text-h2.gt.lg text-h3.lg text-h4.md text-h5.sm text-h6.xs'" class=" text-grey-12">{{ titleEn }}</div>
                <div v-media="'text-h2.gt.lg text-h3.lg text-h4.md text-h5.sm text-h6.xs'" class="text-blue-10 absolute" style="bottom:20%;">{{ titleCh }}</div>
            </div>
            <div class="row   q-gutter-y-md justify-center col-8 col-sm-10 col-xs-12">
              <div class="row justify-center q-gutter-x-xl ">
                <q-card class="my-card col-5  flex content-center">
                    <q-card-section class="row">
                        <div class="col-3 col-sm-2"><img class="proviceImg" src="/productImg/proservice1.png" /></div>
                        <div class="col-9 col-sm-10 coulum">
                            <div class="content row text-h5">{{ cardTitle1 }}</div>
                            <div v-media="'text-body2.lt.md text-body1.gt.md'" class="content row">{{ cardContent1 }}</div>
                        </div>
                    </q-card-section>
                </q-card>
                <q-card class="my-card col-5 flex content-center">
                    <q-card-section class="row">
                        <div class="col-3 col-sm-2"><img class="proviceImg" src="/productImg/proservice2.png" /></div>
                        <div class="col-9 col-sm-10 coulum">
                            <div class="content row text-h5" >{{ cardTitle2 }}</div>
                            <div v-media="'text-body2.lt.md text-body1.gt.md'" class="content row">{{ cardContent2 }}</div>
                        </div>
                    </q-card-section>
                </q-card>
              </div>
              <div class="row justify-center q-gutter-x-xl">
                <q-card class="my-card col-5  flex content-center">
                    <q-card-section class="row ">
                        <div class="col-3 col-sm-2"><img class="proviceImg col-3" src="/productImg/proservice3.png" /></div>
                        <div class="col-9 col-sm-10 coulum">
                            <div class="content row text-h5">{{ cardTitle3 }}</div>
                            <div v-media="'text-body2.lt.md text-body1.gt.md'" class="content row">{{ cardContent3 }}</div>
                        </div>
                    </q-card-section>
                </q-card>
                <q-card class="my-card col-5  flex content-center">
                    <q-card-section class="row ">
                        <div class="col-3 col-sm-2"><img class="proviceImg col-3" src="/productImg/proservice4.png" /></div>
                        <div class="col-9 col-sm-10 coulum">
                            <div class="content row text-h5">{{ cardTitle4 }}</div>
                            <div v-media="'text-body2.lt.md text-body1.gt.md'" class="content row">{{ cardContent4 }}</div>
                        </div>
                    </q-card-section>
                </q-card>
             </div>
            </div>
        </div>
    </div>
</template>
<script lang='ts' setup>
const titleCh = '产品服务';
const titleEn = 'PRODUCTS AND SERVICES';
const cardTitle1 = '时空矢量云平台';
const cardContent1 = '时空矢量云平台包括矢量数据切片系统和矢量切片在线配图系统，提供海量、多源矢量数据的存储管理、快速发布、渲染配图、应用扩展的一体化解决方案，支持用户...';
const cardTitle2 = '时空影像云平台';
const cardContent2 = '时空影像云平台是一款先进的轻量级、跨平台、高性能的影像瓦片化服务发布平台。采用高效空间索引及算法、多线程并行计算模型和微服务架构设计研发，重点...';
const cardTitle3 = '地图瓦片服务发布系统';
const cardContent3 = '地图瓦片服务发布系统是一款先进的轻量级、跨平台、高性能的地图切片服务快速发布和应用管理的平台。配合专有的高效地图瓦片配图切图桌面...';
const cardTitle4 = '三维模型应用系统';
const cardContent4 = '三维模型应用系统是一款先进的、轻量级、高性能的三维模型瓦片话服务发布平台。';
</script>
<style scoped>
.proviceImg {
    width: 100%;
    height: auto;
}

.produceService {
    width: 100%;
    height: 100%;
    background-image: url('/productImg/whiteBack.png');
    background-repeat: no-repeat;
    background-size: 100% 100%;
}
</style>
