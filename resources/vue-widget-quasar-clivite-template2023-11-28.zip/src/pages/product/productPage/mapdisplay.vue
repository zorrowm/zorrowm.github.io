<template>
    <div class="scrollSection ">
        <div class="column justify-around items-center produceService" style="width:100%;height: 100%;">
            <div class="column flex-center col-3 relative-position">
                <div v-media="'text-h2.gt.lg text-h3.lg text-h4.md text-h5.sm text-h6.xs'" class="text-grey-12">{{ titleEn }}</div>
                <div v-media="'text-h2.gt.lg text-h3.lg text-h4.md text-h5.sm text-h6.xs'" class="text-blue-10 absolute" style="bottom:20%;">{{ titleCh }}</div>
            </div>
            <div class="row flex-center" style="width:80%">
                <div class="col-9"><img src="/productImg/map.png" style="width:90%; height: auto;"/></div>
                <div class="col-3 q-gutter-y-md">
                    <div class="text-h5">{{ content_1 }}</div>
                    <div class="text-h5 ">{{ content_2 }}</div>
                </div>

            </div>
        </div>
    </div>
</template>
<script lang='ts' setup>
const titleEn = 'MAP PUBLISHING AND DISPLAY';
const titleCh = '地图发布与展示';
const content_1 = '标准二三维地图数据';
const content_2 = '发布和展示';
</script>
<style scoped></style>
