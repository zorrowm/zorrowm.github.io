<template>
  <ScrollSnapContainer :height="containerHeight">
    <CarouselPanel />
    <ProductService />
    <productAdvantage />
    <MapDisplay />
    <userType />
    <Effect />
    <Resolve />
    <Innovate />
    <chaoqing1 />
    <Introduce />
  </ScrollSnapContainer>
</template>

<script setup lang="ts">
import ScrollSnapContainer from 'components/ScrollSnapContainer/index.vue';
import LayoutTool from 'src/utils/layoutTool';
import { computed } from 'vue';

import CarouselPanel from './CarouselPanel.vue';
import chaoqing1 from './chaoqing1.vue';
import Effect from './effect.vue';
import Innovate from './Innovate.vue';
import Introduce from './introduce.vue';
import MapDisplay from './mapdisplay.vue';
import productAdvantage from './productAdvantage.vue';
import ProductService from './productService.vue';
import Resolve from './resolve.vue';
import userType from './userType.vue';
const containerHeight = computed(() => {
  return LayoutTool.getContentHeight();
});
</script>

<style scoped></style>
