<template>
    <div class="scrollSection">
        <div class="column justify-evenly items-center useType" style="width:100%;height: 100%;">
            <div class="row-1  q-gutter-x-xs q-gutter-y-lg">
                <div class="text-h3">{{ title }}</div>
            </div>
            <div class="row-11 row flex-center" style="width:80%;">
                <div class="col column q-gutter-x-xs q-gutter-y-lg">
                    <div class="text-h4 text-weight-light"> {{ left_title }}</div>
                    <div class="text-h6 text-weight-light"> {{ left_content1 }}</div>
                    <ul>
                        <li class="text-weight-thin"> {{ left_content2 }}</li>
                        <li class="text-weight-thin"> {{ left_content3 }}</li>
                        <li class="text-weight-thin"> {{ left_content4 }}</li>
                        <li class="text-weight-thin"> {{ left_content5 }}</li>
                    </ul>
                </div>
                <div class="col chaoqingimg"><img src="/productImg/超擎.png" /></div>
            </div>
        </div>
    </div>
</template>
<script lang='ts' setup>
const title = '精选案例';
const left_title = '全国地理国情普查成果数据管理与服务';
const left_content1 = '全国地理国情普查项目全面汇聚了我国陆地全域范围内全覆盖、无缝隙、高精度的“山水林田湖草”地理国情信息，形成了海量的矢量、影像等数据成果。超擎实现百TB级-百GB级的全国地理国情普查成果数据无需预切片即可实时发布、实时浏览、实时更新与实时分析，实现无需预切片的全国一张图服务能力。';
const left_content2 = '500GB 量级矢量国情普查数据，其中单图层数据量超过100GB，5天入库';
const left_content3 = '300TB 量级的0.5米分辨率高精度卫星影像数据，实时发布';
const left_content4 = '实时从单图层2.6亿图斑中筛选500万耕地图斑';
const left_content5 = '用户任选多类型矢量要素图层组合统计';
</script>
<style scoped>
.chaoqingimg img {
    width: 95%;
    height: auto;
}
</style>
