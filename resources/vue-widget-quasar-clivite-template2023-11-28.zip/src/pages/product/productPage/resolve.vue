<template>
    <div class="scrollSection">
        <div class="flex flex-center" style="width:100%;height: 100%;">
            <div style="width:80%;" class="row flex-center q-gutter-x-xs q-gutter-y-xs relative-position">
                <!-- <div class="absolute" style="left:0px;width:10px;border:1px solid black;padding:40px;">{{ titleleft }}</div> -->
                <div class="col-2" style="left:0px;width:20px;border:1px solid black;">{{ titleleft }}</div>
                <div class="col-5 column items-end q-gutter-x-lg q-gutter-y-md">
                    <div class="text-h6">{{ title1 }}</div>
                    <div class="text-subtitle1">{{ content1 }}</div>
                    <div class="text-h6">{{ title2 }}</div>
                    <div class="text-subtitle1">{{ content2 }}</div>
                    <div class="text-h6">{{ title3 }}</div>
                    <div class="text-subtitle1">{{ content3 }}</div>
                    <div class="text-h6">{{ title4 }}</div>
                    <div class="text-subtitle1">{{ content4 }}</div>
                </div>
                <div class="col-5 relative-position">
                    <div class="resolveImg"><img src="/productImg/resolve2.png" /></div>
                    <div class="text-h6 absolute" style="bottom:20px;left:20px;">北京SDGs知识服务系统</div>
                </div>
            </div>


            <!-- <div class="note">
                <div class="left">
                    <div class="borderContent">区域可持续发展</div>
                </div>
                <div class="right">
                    <div class="Title">对标联合国SDGs</div>
                    <div class="Content">以联合国SDGs全球指标框架体系等为指导，构建区域可持续发展指标体系</div>
                    <div class="Title">讲中国故事</div>
                    <div class="Content">采用国际化语言描述中国发展、讲中国故事</div>
                    <div class="Title">知识服务</div>
                    <div class="Content">建立区域SDGs知识图谱，建设灵活开放可扩展的空间型知识服务框架体系</div>
                    <div class="Title">政府决策</div>
                    <div class="Content">可为区域总结践行SDGs经验、发现存在问题、制定改进方案提供重要科学依据</div>
                </div>
            </div> -->



        </div>
    </div>
</template>
<script lang='ts' setup>
const titleleft='区域可持续发展';
const title1 = '对标联合国SDGs';
const content1 = '以联合国SDGs全球指标框架体系等为指导，构建区域可持续发展指标体系';
const title2 = '讲中国故事';
const content2 = '采用国际化语言描述中国发展、讲中国故事';
const title3 = '知识服务';
const content3 = '建立区域SDGs知识图谱，建设灵活开放可扩展的空间型知识服务框架体系';
const title4 = '政府决策';
const content4 = '可为区域总结践行SDGs经验、发现存在问题、制定改进方案提供重要科学依据';
</script>
<style scoped>
.resolveImg img {
    width: 95%;
    height: auto;
}
</style>