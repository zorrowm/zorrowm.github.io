<template>
  <TransitionSlide enter="fadeInUp" leave="fadeOutUp">
    <APIExamplePanel v-if="apiExamplesList" :data="apiExamplesList" @contentItemClicked="doItemClickHandler" />
  </TransitionSlide>

</template>

<script setup lang="ts">
import APIExamplePanel from 'components/Quasar/APIExample/index.vue';
import TransitionSlide from 'components/TransitionSlide.vue';
import {ref} from 'vue';
import { Global, LayoutManager } from 'xframelib';
const apiExamplesList=ref<any[]>();
//异步加载数据
import('src/settings/apiExampleSetting/FeiDo/index').then(p=>{
  apiExamplesList.value=p.default;
})
function doItemClickHandler(it) {
  //主页面的LayoutManager
  const mainlayoutManager: LayoutManager =
    Global.LayoutMap.get('productLayout');
  //新的容器widget
  const layoutWidgetID = 'frontLayoutWidget';
  let layoutManagerExamples: LayoutManager;
  if (!mainlayoutManager.isWidgetLoaded(layoutWidgetID)) {
    mainlayoutManager.loadWidget(layoutWidgetID).then(() => {
      //首次直接加载
      setTimeout(() => {
        layoutManagerExamples = Global.LayoutMap.get(layoutWidgetID);
        layoutManagerExamples.loadWidget(it.path);
      }, 300);
    });
  } else {
    layoutManagerExamples = Global.LayoutMap.get(layoutWidgetID);
    if (layoutManagerExamples) {
      let isExist = false;
      const excludeWidgetIDs = ['FeidoPlayerWidget',it.path]; //飞渡浏览器
      layoutManagerExamples.unloadAllWidgets(excludeWidgetIDs);
      isExist = layoutManagerExamples.isWidgetLoaded(it.path);

      // widgetConfArray.forEach((p) => {
      //   if (p.id === it.path) {
      //     isExist = layoutManagerExamples.isWidgetLoaded(p.id);
      //   } else {
      //     if (excludeWidgetIDs.findIndex((id) => id === p.id) < 0)
      //       layoutManagerExamples.unloadWidget(p.id);
      //   }
      // });
      if (!isExist) {
        //没有加载，则加载
        layoutManagerExamples.loadWidget(it.path);
      }
      else
      {
         console.log('让widget可见');
        layoutManagerExamples.changeWidgetVisible(it.path,true);
      }
    }

    mainlayoutManager.getWidgetComponent(layoutWidgetID).changeVisible(true);
  }
}
</script>
