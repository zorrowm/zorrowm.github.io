<template>门户-API接口页</template>

<script setup lang="ts">
import { onMounted,ref } from 'vue';
import { Global } from 'xframelib';
</script>
