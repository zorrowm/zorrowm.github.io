import { reactive } from 'vue';
 interface ILocation {
  lat: number;
  lng: number;
  addr?: string;
  city?: string;
  nation?: string;
  accuracy?:number;
  adcode?:number;
}
//参考：https://blog.csdn.net/qq_36131788/article/details/117560902
/**
 * 当前位置
 */
const current=reactive<ILocation>({
        // 当前位置
        lat: 39.9087,
        lng: 116.3974,
        city: '北京市',
        addr: '天安门',
});
let geolocation:any;
declare const qq: { maps: { Geolocation: any } };
/**
 * 获取当前位置
 * @returns
 */
function getAddressInfo(): Promise<ILocation> {
  return new Promise((resolve, reject) => {
    if(!geolocation)
    {
      geolocation= new qq.maps.Geolocation(
        'TR5BZ-6UY64-Z66UV-DUU4Q-2HNOZ-LCFES',
        '小冰天气'
      );
    }
    geolocation?.getLocation(
      (res) => {
        console.log(res,'定位服务*****')

        current.addr=res.addr;
        current.city=res.city;
        current.lat=res.lat;
        current.lng=res.lng;

        resolve(res);
      },
      () => {
        reject();
      },
      {
        timeout: 20000,
        failTipFlag: true, // 重新授权
      }
    );
  });
}
export {current,getAddressInfo}
