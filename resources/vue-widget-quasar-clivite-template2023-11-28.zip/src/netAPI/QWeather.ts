import { exportSystemRights,requestGet } from 'xframelib';

//示例数据
// {"code":"200","location":[{"name":"乳山","id":"101121304","lat":"36.91962","lon":"121.53635","adm2":"威海","adm1":"山东省","country":"中国","tz":"Asia/Shanghai","utcOffset":"+08:00","isDst":"0","type":"city","rank":"35","fxLink":"https://www.qweather.com/weather/rushan-101121304.html"}],"refer":{"sources":["QWeather"],"license":["QWeather Developers License"]}}

interface ILocation{
  name :string;
  id:string;
  lat:string;
  lon:string;
  adm2?:string;
  adm1?:string;
  tz:string;
  type:string;
  rank:string;
}

async function getLocationByName(cityName:string):Promise<ILocation|undefined>
{
  if(!cityName)
  return undefined;
  const baseUrl='https://geoapi.qweather.com';
  const url=`/v2/city/lookup?location=${cityName}&key=c9ababc26a504434b6fc709c2005e503`
  const res= await requestGet(url,baseUrl,{
    location:cityName,
    key:'c9ababc26a504434b6fc709c2005e503'
  });
  if(res.code==='200')
  {
    const result=res.location as ILocation;
    return result;
  }
  else
  {
    console.warn(res,'获取地理位置');
    return undefined;
  }

}


export interface IWeatherNow{
obsTime:string;
temp:string;
feelsLike:string;
icon:string;
text:string;
wind360:string;
windDir:string;
windScale:string;
windSpeed:string;
humidity:string;
precip:string;
pressure:string;
vis:string;
cloud:string;
dew:string;
}
//成功示例数据：
//{"code":"200","updateTime":"2023-06-19T11:17+08:00","fxLink":"https://www.qweather.com/weather/chaoyang-101010300.html","now":{"obsTime":"2023-06-19T11:10+08:00","temp":"26","feelsLike":"27","icon":"305","text":"小雨","wind360":"82","windDir":"东风","windScale":"2","windSpeed":"7","humidity":"67","precip":"0.0","pressure":"1000","vis":"5","cloud":"100","dew":"22"},"refer":{"sources":["QWeather","NMC","ECMWF"],"license":["CC BY-SA 4.0"]}}
/**
 * 根据经纬度获取现在的天气
 * @param lon 经度
 * @param lat 纬度
 */
export async function getWeatherNow(lon:number,lat:number):Promise<IWeatherNow|undefined>
{
  // const isdefault=Math.random()<0.5;
  // let url=`https://devapi.qweather.com/v7/weather/now?lang=zh&location=${lon},${lat}&t=1687140485&publicid=HE2108291237361722&sign=7528a1fba96233eda66c0933b75a6a15`;
  // if(!isdefault)
  const url=`https://devapi.qweather.com/v7/weather/now?lang=zh&location=${lon},${lat}&key=c9ababc26a504434b6fc709c2005e503`;
  const res= await requestGet('',url);
  if(res&&res.data&&res.data?.code==='200')
  {
    const result=res.data.now as IWeatherNow;
    return result;
  }
  else
  {
    console.warn(res,url,'获取现在天气');
    return undefined;
  }
}

export async function getWeatherNowByID(cityID:string):Promise<IWeatherNow|undefined>
{
 // const isdefault=Math.random()<0.5;
  // let url=`https://devapi.qweather.com/v7/weather/now?lang=zh&location=${lon},${lat}&t=1687140485&publicid=HE2108291237361722&sign=7528a1fba96233eda66c0933b75a6a15`;
  // if(!isdefault)
  const url=`https://devapi.qweather.com/v7/weather/now?lang=zh&location=${cityID}&key=c9ababc26a504434b6fc709c2005e503`;
  const res= await requestGet('',url);
  if(res&&res.data&&res.data?.code==='200')
  {
    const result=res.data.now as IWeatherNow;
    return result;
  }
  else
  {
    return undefined;
  }
}
interface IAirNow
{
pubTime:string;
aqi:string;
level:string;
category:string;
primary:string;
pm10:string;
pm2p5:string;
no2:string;
so2:string;
co:string;
o3:string;
}
//示例结果数据：
//{"code":"200","updateTime":"2023-06-19T13:42+08:00","fxLink":"https://www.qweather.com/air/wendeng-101121302.html","now":{"pubTime":"2023-06-19T13:00+08:00","aqi":"40","level":"1","category":"优","primary":"NA","pm10":"17","pm2p5":"12","no2":"7","so2":"5","co":"0.2","o3":"126"},"station":[{"pubTime":"2023-06-19T13:00+08:00","name":"文登市丝绸公司","id":"CNA1982","aqi":"40","level":"1","category":"优","primary":"NA","pm10":"17","pm2p5":"12","no2":"7","so2":"5","co":"0.2","o3":"126"}],"refer":{"sources":["QWeather","CNEMC"],"license":["CC BY-SA 4.0"]}}
/**
 * 获取空气的PM2.5值
 * @param pLocation cityid或 lon,lat的字符串
 * @returns
 */
export async function getAirNow(pLocation:string):Promise<IAirNow|undefined>
{
  const isdefault=Math.random()<0.5;
  let url=`https://devapi.qweather.com/v7/air/now?lang=zh&location=${pLocation}&t=1687140485&publicid=HE2108291237361722&sign=7528a1fba96233eda66c0933b75a6a15`;
  if(!isdefault)
  url=`https://devapi.qweather.com/v7/air/now?lang=zh&location==${pLocation}&key=c9ababc26a504434b6fc709c2005e503`;
  const res= await requestGet('',url);
  if(res.code==='200')
  {
    const result=res.now as IAirNow;
    return result;
  }
  else
  {
    console.warn(res,url,'获取现在空气质量');
    return undefined;
  }
}
