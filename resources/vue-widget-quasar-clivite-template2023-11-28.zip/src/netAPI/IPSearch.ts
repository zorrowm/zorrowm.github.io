import {ref} from 'vue';
import {requestGet} from 'xframelib';

const myIP=ref('');
function getIPAddress()
{
  const url='https://www.taobao.com/help/getip.php';
  requestGet('',url,undefined,{
    // ':Authority':'www.taobao.com',
    ':Method':'GET',
    ':Path':'/help/getip.php',
    ':Scheme':'https',
    'Referer':'',
  }).then(res=>{
    console.log(res,'查询IP地址');
  })

}

export {getIPAddress,myIP};
