import { IExampleItem } from 'src/components/Quasar/APIExample/APIExampleHelper';

const apiExamples: Array<IExampleItem> = [
  {
    index:3,
    name: '图层设置',
    icon: 'bx:bxs-layer',
    description:'分组说明',
    children: [
        {
            label: 'layerBasicSet',
            name: '图层基本设置',
            icon: '',
            description:'分组说明',
            children: [
                {
                    name: '图层树-WindowPanel',
                    path: 'layerTreeWidget0',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                  name: '图层树-animate',
                  path: 'layerTreeWidget1',
                  description:'描述说明',
                  icon: '/apiExampleimg/thumbnail.gif',
              },
              {
                name: '图层树-gsap',
                path: 'layerTreeWidget2',
                description:'描述说明',
                icon: '/apiExampleimg/thumbnail.gif',
               },
               {
                name: '图层树-XWidgetWindow',
                path: 'layerTreeWidget3',
                description:'描述说明',
                icon: '/apiExampleimg/thumbnail.gif',
               },
            ]
        },
        {
          label: 'layerBasicSet',
          name: '图层编辑',
          icon: '',
          description:'分组说明',
          children: [
            {
              label: 'ModelEdit',
              name: '模型编辑',
              //index: 'id_3_2',
              icon: '',
              description:'分组说明',
              path: 'ModelEdit',
          },
          {
              label: 'layerEdit',
              name: '编辑图层',
              //index: 'id_3_3',
              icon: '',
              description:'分组说明',
              path: 'layerEdit',
          },
          ]
        }

    ]
},
];

export default apiExamples;
