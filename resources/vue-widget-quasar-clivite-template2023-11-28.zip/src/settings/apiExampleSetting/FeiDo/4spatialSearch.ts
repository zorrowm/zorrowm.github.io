import { IExampleItem } from 'src/components/Quasar/APIExample/APIExampleHelper';

const apiExamples: Array<IExampleItem> = [
  {
    index:5,
    label: 'spaceSearch',
    name: '空间查询',
    icon: 'fluent:box-search-24-regular',
    description:'分组说明',
},
];

export default apiExamples;
