import { IExampleItem } from 'src/components/Quasar/APIExample/APIExampleHelper';

const apiExamples: Array<IExampleItem> = [
  {
    index:1,
    name: '加载地图数据',
    icon: 'carbon:choropleth-map',
    description:'DTS连接实现三维初始化的相关示例',
    children: [
        {
            name: '加载3DT',
            path: 'load3DTWidget',
            description:'描述说明',
            icon: '/apiExampleimg/thumbnail.gif',
        },
        {
            name: '加载GeoJson',
            path: 'loadGeoJsonWidget',
            description:'描述说明',
            icon: '/apiExampleimg/thumbnail.gif',
        },
        {
            name: '加载KML',
            path: 'loadKMLWidget',
            description:'描述说明',
            icon: '/apiExampleimg/thumbnail.gif',
        },
        {
            name: '加载WFS',
            path: 'loadWFSWidget',
            description:'描述说明',
            icon: '/apiExampleimg/thumbnail.gif',
        },
        {
            name: '加载WMTS',
            path: 'loadWMTS',
            description:'描述说明',
            icon: '/apiExampleimg/thumbnail.gif',
        },
        {
            name: '加载MapBox',
            path: 'loadMapBoxWidget',
            description:'描述说明',
            icon: '/apiExampleimg/thumbnail.gif',

        },
        {
            name: '加载Cesium3Dtiles',
            path: 'loadCesium3Dtiles',
            description:'描述说明',
            icon: '/apiExampleimg/thumbnail.gif',

        },
        {
            name: '加载超图S3M',
            path: 'loadS3M',
            description:'描述说明',
            icon: '/apiExampleimg/thumbnail.gif',

        },
        {
            name: '加载SHPFile',
            path: 'loadShpFile',
            description:'描述说明',
            icon: '/apiExampleimg/thumbnail.gif',

        },
        {
            name: '添加Echarts数据',
            path: 'loadEcharts',
            description:'描述说明',
            icon: '/apiExampleimg/thumbnail.gif',

        },
        {
            name: '加载vtpk',
            path: 'loadVtpk',
            description:'描述说明',
            icon: '/apiExampleimg/thumbnail.gif',

        },
        {
            name: '加载鹰眼图',
            path: 'load_eyemap',
            description:'描述说明',
            icon: '/apiExampleimg/thumbnail.gif',

        },
        {
            name: '加载高德鹰眼图',
            path: 'load_gaode_eyemap',
            description:'描述说明',
            icon: '/apiExampleimg/thumbnail.gif',

        },
    ]
},
];

export default apiExamples;
