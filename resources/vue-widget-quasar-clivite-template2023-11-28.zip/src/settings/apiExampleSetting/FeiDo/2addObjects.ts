import { IExampleItem } from 'src/components/Quasar/APIExample/APIExampleHelper';

const apiExamples: Array<IExampleItem> = [
  {
    index:2,
    name: '添加对象',
    icon: 'gala:add',
    description:'各种动态添加各类对象的相关示例',
    children: [
        {
            label: 'addSampleObject',
            name: '添加简单对象',
            icon: '',
            description:'分组说明',
            children: [
                {
                    name: '创建POI点',
                    path: 'createPoi',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',

                },
                {
                    name: '创建线、曲线、折线',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',

                },
                {
                    name: '创建面',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',

                },
                {
                    name: '创建球体、半球体、椭球体',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',

                },
                {
                    name: '创建锥体',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',

                },
                {
                    name: '创建圆锥',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',

                },
                {
                    name: '创建柱体',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '创建3D箭头',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '创建贴画',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '创建全景图',
                    path: 'panoramagram',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',

                },
                {
                    name: '创建OD线',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
            ]
        },
        {
            name: '添加高级对象',
            icon: '',
            description:'分组说明',
            children: [
                {
                    name: '创建复杂样式的线',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '线贴地',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '创建复杂样式面',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '面贴地',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '创建3DMarker',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '创建CustomTag',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '创建辐射圈',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',

                },
                {
                    name: '创建视频投影',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '创建热力图',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '添加动态水',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '添加点光源',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '聚合光',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',

                },
                {
                    name: '添加平面光源',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',

                },
                {
                    name: '创建管道',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',

                },
                {
                    name: '创建自定义标签1',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_3_14'
                },
                {
                    name: '创建自定义标签2',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '创建自定义标签3',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '创建自定义标签4',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
            ]
        },
        {

            name: '添加复杂对象',
            icon: '',
            description:'分组说明',
            children: [
                {
                    name: '创建态势图',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '创建水流场',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '创建统计柱状图',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '创建热力柱状图',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '创建行政区划',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
            ]
        },
        {
            name: '添加动态对象',
            icon: '',
            description:'分组说明',
            children: [
                {
                    name: '创建车辆',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '创建动态标签',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '创建动物',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '创建人物',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '创建船',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },

            ]
        },
        {
            name: '添加特效对象',
            icon: '',
            description:'分组说明',

            children: [
                {
                    name: '创建水对象',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_6_0'
                },
                {
                    name: '创建火对象',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_6_0'
                },
                {
                    name: '创建烟雾对象',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '创建自然对象',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                },
                {
                    name: '创建雷达范围',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',

                },
                {
                    name: '创建检测点',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',

                },
                {
                    name: '创建定位',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',

                },
            ]
        },
        {

            name: '添加室外对象',

            icon: '',
            description:'分组说明',
            children: [
                {
                    name: '创建交通信号灯',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_7_0'
                },
                {
                    name: '创建交通指示牌',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_7_1'
                },
                {
                    name: '创建充电桩',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_7_2'
                },
                {
                    name: '创建公交站',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_7_3'
                },
                {
                    name: '创建其他',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_7_4'
                },
                {
                    name: '创建垃圾桶',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_7_5'
                },
                {
                    name: '创建摄像头',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_7_6'
                },
                {
                    name: '创建树池',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_7_7'
                },
                {
                    name: '创建椅子',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_7_8'
                },
                {
                    name: '创建消防栓',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_7_9'
                },
                {
                    name: '创建路灯',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_7_10'
                },
                {
                    name: '创建路障',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_7_11'
                },
                {
                    name: '创建道闸',
                    path: '',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_7_12'
                },
            ]
        },
    ]
},
];

export default apiExamples;
