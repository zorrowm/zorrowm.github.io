import { IExampleItem } from 'src/components/Quasar/APIExample/APIExampleHelper';

const apiExamples: Array<IExampleItem> = [
  {
    index:0,
    name: '初始化三维',
    icon: 'ant-design:bank-outlined',
    description:'DTS连接实现三维初始化的相关示例',
    children: [
        {
            name: '直连webRTC服务',
            path: '',
            description:'描述说明,DTS连接实现三维初始化的相关示例,描述说明,DTS连接实现三维初始化的相关示例',
            icon: '/apiExampleimg/thumbnail.gif',
        },
        {
            name: '如何载入动画，断开重连',
            path: '',
            description:'描述说明',
            icon: '/apiExampleimg/thumbnail.gif',
        },
        {
            name: 'cesium与webRTC服务无缝对接',
            path: '',
            description:'描述说明',
            icon: '/apiExampleimg/thumbnail.gif',
        },
        {
            name: '如何获取三维交互回调信息',
            path: '',
            description:'描述说明',
            icon: '/apiExampleimg/thumbnail.gif',
        },
    ]
  }
];

export default apiExamples;
