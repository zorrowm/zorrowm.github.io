import { IExampleItem } from 'src/components/Quasar/APIExample/APIExampleHelper';
import { globFilterObjects } from 'src/utils/sysTool';

const components = import.meta.glob('./*.ts', { eager: true });
const menuCofig: Array<IExampleItem> = globFilterObjects<IExampleItem>(
  components,
  true
);
export default menuCofig;
