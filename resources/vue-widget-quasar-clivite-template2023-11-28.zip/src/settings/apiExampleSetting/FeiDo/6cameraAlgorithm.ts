import { IExampleItem } from 'src/components/Quasar/APIExample/APIExampleHelper';

const apiExamples: Array<IExampleItem> = [
  {
    index:6,
    name: '相机与算法',
    icon: 'material-symbols:android-camera',
    description:'分组说明',
    children: [
        {
            label: 'cameraSet',
            name: '相机设置',
            //index: 'id_6_1',
            icon: '',
            description:'分组说明',
            path: 'cameraSet',
            children: [
                {
                    name: '获取相机位置',
                    path: 'getCameraPosition',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_0_3'
                },
                {
                    name: '设置相机位置',
                    path: 'setCameraPosition',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_0_3'
                },
                {
                    name: '获取导览',
                    path: 'getGuide',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_0_3'
                },
                {
                    name: '播放导览',
                    path: 'playGuide',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_0_3'
                },
                {
                    name: '相机移动',
                    path: 'cameraMove',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_0_3'
                },
                {
                    name: '相机定位',
                    path: 'cameraPosition',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_0_3'
                },
                {
                    name: '设置交互模式',
                    path: 'setInteractiveMode',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_0_3'
                },
            ]
        },
        {
            label: 'commonMethod',
            name: '常用方法',
            //index: 'id_6_2',
            icon: '',
            description:'分组说明',
            path: 'commonMethod',
            children: [
                {
                    name: '坐标转换',
                    path: 'coordinateChange',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_0_3'
                },
                {
                    name: '射线求交',
                    path: 'ray',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_0_3'
                },
                {
                    name: '获取两点欧拉角',
                    path: 'eulerAngle',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_0_3'
                },
                {
                    name: '测量工具',
                    path: 'linePick',
                    description:'描述说明',
                    icon: '/apiExampleimg/thumbnail.gif',
                    //index:'content_0_3'
                },
                // {
                //     name: '坐标点测量',
                //     path: 'coordinatePick',
                //     description:'描述说明',
                //     icon:'/apiExampleimg/thumbnail.gif',
                //     //index:'content_0_3'
                // },
                // {
                //     name: '直线测量',
                //     path: 'linePick',
                //     description:'描述说明',
                //     icon:'/apiExampleimg/thumbnail.gif',
                //     //index:'content_0_3'
                // },
                // {
                //     name: '水平测量',
                //     path: 'horizontalMeasure',
                //     description:'描述说明',
                //     icon:'/apiExampleimg/thumbnail.gif',
                //     //index:'content_0_3'
                // },
                // {
                //     name: '垂直测量',
                //     path: 'verticalMeasure',
                //     description:'描述说明',
                //     icon:'/apiExampleimg/thumbnail.gif',
                //     //index:'content_0_3'
                // },
                // {
                //     name: '投影面积测量',
                //     path: 'ProjAreaMeasure',
                //     description:'描述说明',
                //     icon:'/apiExampleimg/thumbnail.gif',
                //     //index:'content_0_3'
                // },
                // {
                //     name: '地表面积测量',
                //     path: 'planeAreaMeasure',
                //     description:'描述说明',
                //     icon:'/apiExampleimg/thumbnail.gif',
                //     //index:'content_0_3'
                // },
            ]
        },
    ]
},
];

export default apiExamples;
