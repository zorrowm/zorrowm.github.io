import type { IWidgetMenu } from 'src/models/IWidgetMenu';
import { globFilterObjects } from 'src/utils/sysTool';

const components = import.meta.glob('./*.ts', { eager: true });
const menuCofig: Array<IWidgetMenu> = globFilterObjects<IWidgetMenu>(
  components,
  true
);
export default menuCofig;
