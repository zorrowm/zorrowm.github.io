import { MenuItemEnum } from 'src/enums/menuEnum';
import type { IWidgetMenu } from 'src/models/IWidgetMenu';
const menuCofig: Array<IWidgetMenu> = [
  {
    name: '地图工具',
    index: 1,
	icon:'gis:globe-gear',
    path: 'linkMenuWidget',
    type: MenuItemEnum.Widget,
    unload:true,
    children: [
      {
        name: '测量工具',
		icon:'gis:measure',
        path: 'flyMenuWidget',
        type: MenuItemEnum.Widget,
        children: [
          {
            name: 'test1',
            path: 'flyRoamingWidget1',
            type: MenuItemEnum.Widget,
            unload: true,
          },
          {
            name: 'test2',
            path: 'SimulationWidget2',
            type: MenuItemEnum.Widget,
            unload: true,
          },
        ]
      },
      {
        name: '量算工具',
		icon:'gis:measure',
        path: 'measureToolWidget',
        type: MenuItemEnum.Widget,
        unload: true,
      },
      {
        name: '标绘工具',
        path: 'drawToolWidget',
		icon:'material-symbols:draw-outline',
        type: MenuItemEnum.Widget,
        unload: true,
      },
      {
        name: '态势标绘',
        path: 'plotMapWidget',
		icon:'clarity:scatter-plot-outline-alerted',
        type: MenuItemEnum.Widget,
        unload: true,
      },
	  {
        name: '截图/视频',
        path: 'photoVideoWidget',
		icon:'ph:file-video-thin',
        type: MenuItemEnum.Widget,
		unload:true
      },
    ],
  },
];

export default menuCofig;
