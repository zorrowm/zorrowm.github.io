import { MenuItemEnum } from 'src/enums/menuEnum';
import type { IWidgetMenu } from 'src/models/IWidgetMenu';
const menuCofig: Array<IWidgetMenu> = [
  {
        name: '图层树',
		index:2,
		icon:'vaadin:file-tree',
        path: 'layerManagerWidget',
        type: MenuItemEnum.Widget,
  },
  {
        name: '专题地图',
		index:3,
		icon:'gis:map-route',
        path: 'layerManagerWidget',
        type: MenuItemEnum.Widget,
  },
  {
        name: '场景视角',
		index:4,
		icon:'gis:map-play',
        path: 'layerManagerWidget',
        type: MenuItemEnum.Widget,
  },
  {
        name: '地图特效',
		index:5,
		icon:'gis:magnify-map',
        path: 'layerManagerWidget',
        type: MenuItemEnum.Widget,
  },
];

export default menuCofig;
