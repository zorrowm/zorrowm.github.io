import { IModalConfig } from 'src/models/IModalModels';
import { globFilterObjects } from 'src/utils/sysTool';

/**
 * modal窗体配置项
 */
const components = import.meta.glob('./*.ts', { eager: true });
const modalsConfig: Array<IModalConfig> = globFilterObjects<IModalConfig>(
  components,
  false
);
export default modalsConfig;
