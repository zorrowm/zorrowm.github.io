import { IModalConfig } from 'src/models/IModalModels';

/**
 * 组件配置项
 */
const defaultWidgetCofig: Array<IModalConfig> = [
  // {
  //   id: 'editServiceID',
  //   label: '新建/复制/编辑服务',
  //   component: () => import('pages/back/home/modals/editServiceModal.vue')
  // },
  // {
  //   id: 'addServiceData',
  //   label: '新建服务',
  //   component: () => import('pages/back/home/modals/addDataModal.vue')
  // },
  // {
  //   id: 'viewMetaDataID',
  //   label: '查看元数据',
  //   component: () => import('pages/back/home/modals/metaModal.vue')
  // },
  // {
  //   id: 'viewServiceMessageID',
  //   label: '查看服务信息',
  //   component: () => import('pages/back/home/modals/serviceInfo.vue')
  // },
  // {
  //   id: 'editServiceMessageID',
  //   label: '编辑服务信息',
  //   component: () => import('pages/back/home/modals/editServiceInfo.vue')
  // },
];

export default defaultWidgetCofig;
