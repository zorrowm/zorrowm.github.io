import type { IWidgetConfig } from 'xframelib';
import { LayoutContainerEnum } from 'xframelib';

/**
 * 组件配置项
 */
const defaultWidgetCofig: Array<IWidgetConfig> = [
  {
    layoutID: 'productLayout', //归属组
    id: 'LogoTitleWidget',
    label: '头部栏',
    container: LayoutContainerEnum.top,
    component: () => import('src/widgets/back/LogoTitleWidget.vue'),
    preload: true,
  },
  {
    layoutID: 'productLayout', //归属组
    id: 'TopMenuWidget',
    label: '头部菜单栏',
    container: LayoutContainerEnum.top,
    component: () => import('src/widgets/product/TopMenuWidget.vue'),
    preload: true,
  },
  {
    layoutID: 'productLayout', //归属组
    id: 'frontLayoutWidget',
    label: '前端弹框容器',
    container: LayoutContainerEnum.centerFront,
    component: () => import('src/widgets/feido/FrontLayoutWidget.vue'),
    preload: false, //需要根据配置判断是否加载
  },
  // {
  //   layoutID: 'productLayout', //归属组
  //   id: 'ModalContainerWidget',
  //   label: '弹框容器',
  //   container: LayoutContainerEnum.top,
  //   component: () => import('src/widgets/layouts/ModalContainerWidget.vue'),
  //   preload: true,
  // },
];

export default defaultWidgetCofig;
