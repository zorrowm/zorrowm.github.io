import { globFilterObjects } from 'src/utils/sysTool';
import type { IWidgetConfig } from 'xframelib';
/**
 * 组件配置项
 */
const components = import.meta.glob('./*.ts', { eager: true });
const widgetCofig: Array<IWidgetConfig> = globFilterObjects<IWidgetConfig>(
  components,
  false
);
export default widgetCofig;
