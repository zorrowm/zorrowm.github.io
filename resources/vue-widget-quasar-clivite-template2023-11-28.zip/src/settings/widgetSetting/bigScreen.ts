import type { IWidgetConfig } from 'xframelib';
import { LayoutContainerEnum } from 'xframelib';

/**
 * 组件配置项
 */
const defaultWidgetCofig: Array<IWidgetConfig> = [
  {
    layoutID: 'bigScreenLayout', //归属组
    id: 'headerTitleWidget',
    label: '头部栏',
    container: LayoutContainerEnum.top,
    component: () => import('src/widgets/bigScreen/HeaderTitleWidget.vue'),
    preload: true,
  },
  {
    layoutID: 'bigScreenLayout', //归属组
    id: 'bottomMenuWidget',
    container: LayoutContainerEnum.bottom,
    component: () => import('src/widgets/bigScreen/BottomMenuWidget.vue'),
    preload: true,
  },
  {
    layoutID: 'bigScreenLayout', //归属组
    id: 'statusWidget',
    container: LayoutContainerEnum.bottom,
    component: () => import('src/widgets/bigScreen/StatusWidget.vue'),
    preload: true,
  },
  {
    layoutID: 'bigScreenLayout', //归属组
    id: 'cesiumWidget',
    container: LayoutContainerEnum.centerBack,
    component: () => import('src/widgets/bigScreen/CesiumWidget.vue'),
    preload: true,
  },
  //菜单栏widget
  {
    layoutID: 'bigScreenLayout', //归属组
    id: 'menuBarWidget',
    container: LayoutContainerEnum.centerBack,
    component: () => import('src/widgets/bigScreen/MenuBarWidgets/MenuBarWidget.vue'),
    preload: true,
  },
  {
    layoutID: 'bigScreenLayout', //归属组
    id: 'linkMenuWidget',
    container: LayoutContainerEnum.centerBack,
    component: () => import('src/widgets/bigScreen/MenuBarWidgets/linkMenuWidget.vue'),
    preload: false,
  },
  {
    layoutID: 'bigScreenLayout', //归属组
    id: 'templateMenuWidget',
    container: LayoutContainerEnum.centerBack,
    component: () => import('src/widgets/bigScreen/MenuBarWidgets/templateMenuWidget.vue'),
    preload: false,
  },
  {
    layoutID: 'bigScreenLayout', //归属组
    id: 'flyMenuWidget',
    container: LayoutContainerEnum.centerBack,
    component: () => import('src/widgets/bigScreen/MenuBarWidgets/flyMenuWidget.vue'),
    preload: false,
  },
];

export default defaultWidgetCofig;
