/**
 * 用于各个Widget组件相关的事件
 */
export default {
    //#region 与ModalContainer相关的事件
    //加载弹框事件
    ModalContainerWidget_LoadModal: 'ModalContainerWidget_LoadModal',
    ModalContainerWidget_CloseModal: 'ModalContainerWidget_CloseModal',
    //#endregion
  };