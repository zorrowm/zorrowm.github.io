//状态栏消息
export default {
  SatusMessage: 'statusmessage' //状态栏消息
};
