
import BasicDragVerify from './DragVerify.vue';
import RotateDragVerify from './ImgRotate.vue';

export {BasicDragVerify,RotateDragVerify};
export * from './typing';
