# vue-widget-template

全面基于Widget思想的开发模板
积累记录

2023.03.24
APP.VUE增加统一Axios请求异常捕捉处理

2023.02.15 
增加解决图标离线使用代码
遍历生成离线图标文件的工具IconOffline.exe

2023.02.10 
为ModalContainer增加通过事件关闭窗口,调用doCloseModal方法
修改其他小问题

2023.02.7 
基于影像、矢量和大屏等成果，增加多布局模板支持
增加SideBar布局；
ModalContainer支持隐藏底部菜单栏；

2022.11.25 
解决模板开发vite启动页面慢的问题
默认引入xgis-ol  xgis-plot 

2022.8.4 初始版本
去掉原后台布局，使用widget搭建后台管理容器框架

