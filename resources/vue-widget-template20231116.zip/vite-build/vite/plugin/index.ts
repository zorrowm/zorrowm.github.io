import { PluginOption } from 'vite';
import vue from '@vitejs/plugin-vue';
import vueJsx from '@vitejs/plugin-vue-jsx';
import legacy from '@vitejs/plugin-legacy';
import visualizer from 'rollup-plugin-visualizer';
import { configCompressPlugin } from './compress';
import { configVisualizerConfig } from './visualizer';
import { configHmrPlugin } from './hmr';
import { configViteUnplugin } from './unplugin';
// import cesium from 'vite-plugin-cesium';
import pluginFS from "vite-plugin-fs";
// import mkcert from'vite-plugin-mkcert'


export function createVitePlugins(viteEnv: ViteEnv, isBuild: boolean) {
  const {
    // VITE_USE_IMAGEMIN,
    VITE_LEGACY,
    VITE_BUILD_COMPRESS,
    VITE_BUILD_COMPRESS_DELETE_ORIGIN_FILE
  } = viteEnv;

  const vitePlugins: (PluginOption | PluginOption[])[] = [
    //文件输出
    pluginFS(),
    // have to
    vue(),
    // have to
    vueJsx(),
    //三维
    // cesium(),
    //启用https证书
    // mkcert({
    //   source: 'coding',
    // }),
  ];

  //unplugin-vue-components
   vitePlugins.push(configViteUnplugin());
  //unplugin-auto-import
  // vitePlugins.push(pluginAutoImport);

  // TODO
  !isBuild && vitePlugins.push(configHmrPlugin());

  // @vitejs/plugin-legacy
  VITE_LEGACY &&
    isBuild &&
    vitePlugins.push(
      legacy({
        targets: ['chrome >= 70', 'ie >= 11'],
        modernPolyfills: true
      })
    );

  // The following plugins only work in the production environment
  if (isBuild) {
    // rollup-plugin-visualizer
    vitePlugins.push(configVisualizerConfig());

    // rollup-plugin-gzip
    vitePlugins.push(
      configCompressPlugin(VITE_BUILD_COMPRESS, VITE_BUILD_COMPRESS_DELETE_ORIGIN_FILE)
    );
    // 打包依赖展示
    vitePlugins.push(
      visualizer({
        open: true,
        gzipSize: true,
        brotliSize: true
      })
    );
  }

  return vitePlugins;
}
