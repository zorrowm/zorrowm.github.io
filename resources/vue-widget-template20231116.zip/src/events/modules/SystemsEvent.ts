//系统视图相关事件
export default {
  //#region 根据需要注册事件类型
  System_RefreshList: 'System_RefreshList',
  System_Search: 'System_Search',
  System_Detail: 'System_Detail',
  System_ReListAside:"System_ReListAside"
  //#endregion
};
