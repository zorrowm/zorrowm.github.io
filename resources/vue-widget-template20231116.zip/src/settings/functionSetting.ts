import {IRoleFunction} from 'xframelib'
/**
 * 功能点列表
 */
const functionList: Array<IRoleFunction> = [];
export default functionList;
