<template>
  <div id="cesiumContainer" style="width: 100%; height: 100%;background-color: #333;color:#f00">Cesium Widget</div>
</template>
<script setup lang="ts">

</script>
