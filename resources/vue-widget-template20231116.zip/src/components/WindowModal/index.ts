export { default as WindowModal } from './index.vue';
