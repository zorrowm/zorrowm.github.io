<template>
    <div>
      SideLine 右侧视图页面
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>